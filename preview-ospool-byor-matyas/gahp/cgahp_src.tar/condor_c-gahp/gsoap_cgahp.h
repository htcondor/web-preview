//gsoap condor service name: condorCgahp
 
#import "gsoap_daemon_core.h"
