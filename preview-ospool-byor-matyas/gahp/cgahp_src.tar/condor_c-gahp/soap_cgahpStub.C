#include "condorCgahp.nsmap"
   
#include "../condor_daemon_core.V6/soap_daemon_core.cpp"
