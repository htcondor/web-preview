#!/usr/bin/env python
import time
import sys



if(__name__ == '__main__'):
    EXTRA_ATTRS = ('JobState', 'JobPid', 'NumPids', 'JobStartDate', 
                   'RemoteSysCpu', 'RemoteUserCpu', 'ImageSize')
    
    
    # Read the raw ClassAd from STDIN and create a Job instance.
    ad = sys.stdin.read()
    
    # Determine the role of this hook.
    role = None
    if(len(sys.argv) > 1):
        exitReason = sys.argv[1]
        role = 'job_exit'
    else:
        exitReason = None
        n = 0
        for attr in EXTRA_ATTRS:
            if(attr + ' =' in ad):
                n += 1
        if(n > len(EXTRA_ATTRS) / 2.):
            role = 'update_job'
        else:
            role = 'prepare_job'
    
    time.sleep(1)
    
    # Just exit.
    sys.exit(0)
