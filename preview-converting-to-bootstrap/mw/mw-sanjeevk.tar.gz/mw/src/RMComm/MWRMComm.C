#include "MWRMComm.h"

extern int *MW_exec_class_num_workers;

double RMCOMM_bytes_packed = 0;
double RMCOMM_bytes_unpacked = 0;

MWRMComm::MWRMComm()
{
	exec_classes = -1;
	num_arches = -1;
	arch_class_attributes = NULL;
	num_executables = tempnum_executables = -1;
	worker_executables = NULL;
	worker_checkpointing = false;

	target_num_workers = 0;
	exec_class_target_num_workers = NULL;
}


MWRMComm::~MWRMComm()
{
	int i;

	if ( arch_class_attributes )
	{
		for ( i = 0; i < num_arches; i++ )
			if ( arch_class_attributes[i] )
				delete arch_class_attributes[i];
	}

	if ( worker_executables )
	{
		for ( i = 0; i < num_executables; i++ )
			if ( worker_executables[i] )
			{
				delete worker_executables[i]->executable;
				delete worker_executables[i]->executable_name;
				delete worker_executables[i];
			}
	}

	if ( exec_class_target_num_workers )
		delete exec_class_target_num_workers;
}

void MWRMComm::exit( int exitval )
{
	::exit ( exitval );
}

int MWRMComm::write_checkpoint( FILE *fp )
{
	int i;

	MWprintf ( 80, "Writing checkpoint for MWPvmRC layer.\n" );

	fprintf ( fp, "%d \n", exec_classes );
	fprintf ( fp, "%d \n", num_arches );
	for ( i = 0 ; i<num_arches ; i++ ) 
	{
		if ( arch_class_attributes && arch_class_attributes[i] )
			fprintf ( fp, "1 %d %s\n", strlen(arch_class_attributes[i]), arch_class_attributes[i] );
		else
			fprintf ( fp, "0 " );
	}

	fprintf ( fp, "%d \n", num_executables );
	for ( i = 0; i < num_executables; i++ )
	{
		fprintf ( fp, "%d %d %s %s\n", worker_executables[i]->arch_class, 
				worker_executables[i]->exec_class, worker_executables[i]->executable, 
				worker_executables[i]->executable_name );
		if ( worker_executables[i]->attributes != NULL )
			fprintf ( fp, "1 %d %s\n", strlen(worker_executables[i]->attributes), 
								worker_executables[i]->attributes );
		else
			fprintf ( fp, "0 " );
	}

	for ( i = 0; i < exec_classes; i++ )
	{
		fprintf ( fp, "%d ", exec_class_target_num_workers[i] );
	}
	fprintf ( fp, "\n");

	write_RMstate ( fp );
	return 0;
}

int MWRMComm::read_checkpoint( FILE *fp )
{
	int temp;
	int i;
	MWprintf ( 50, "Reading checkpoint in MWPvmRC layer.\n" );
	fscanf ( fp, "%d %d", &exec_classes, &num_arches );
	MWprintf ( 50, "Target num workers: %d    Num arches %d.\n", 
					target_num_workers, num_arches );
	arch_class_attributes = new char*[num_arches];
	target_num_workers = 0;
	for ( i = 0; i < num_arches; i++ )
	{
		fscanf ( fp, "%d ", &temp );
		if ( temp == 1 )
		{
			fscanf ( fp, "%d ", &temp );
			arch_class_attributes[i] = new char[temp+1];
			fgets ( arch_class_attributes[i], temp + 1, fp );
		}
		else
			arch_class_attributes[i] = NULL;
	}

	fscanf ( fp, "%d ", &num_executables );
	MWprintf ( 50, "%d Worker executables:\n", num_executables );
	worker_executables = new struct RMC_executable*[num_executables];
	for ( i = 0 ; i < num_executables; i++ ) 
	{
		worker_executables[i] = new struct RMC_executable;
		worker_executables[i]->executable = new char[_POSIX_PATH_MAX];
		worker_executables[i]->executable_name = new char[_POSIX_PATH_MAX];
		fscanf ( fp, "%d %d %s %s", &worker_executables[i]->arch_class,
				&worker_executables[i]->exec_class, worker_executables[i]->executable,
				worker_executables[i]->executable_name );
		fscanf ( fp, "%d ", &temp );
		if ( temp == 1 )
		{
			fscanf ( fp, "%d ", &temp );
			worker_executables[i]->attributes = new char[temp+1];
			fgets ( worker_executables[i]->attributes, temp + 1, fp );
		}
		else
			worker_executables[i]->attributes = NULL;
	}

	MW_exec_class_num_workers = new int[exec_classes];
	exec_class_target_num_workers = new int[exec_classes];
	for ( i = 0; i < exec_classes; i++ )
	{
		fscanf ( fp, "%d ", &exec_class_target_num_workers[i] );
		target_num_workers += exec_class_target_num_workers[i];
		MW_exec_class_num_workers[i] = 0;
	}

	read_RMstate ( fp );
	return 0;
}

int MWRMComm::read_RMstate( FILE *fp ) 
{ 
	return 0;
}

int MWRMComm::write_RMstate( FILE *fp )
{
	return 0;
}


void
MWRMComm::set_num_exec_classes ( int num )
{
	exec_classes = num;
	exec_class_target_num_workers = new int[num];
	MW_exec_class_num_workers = new int[num];
	for ( int i = 0; i < num; i++ )
	{
		exec_class_target_num_workers[i] = 0;
		MW_exec_class_num_workers[i] = 0;
	}
	
}

int
MWRMComm::get_num_exec_classes ( )
{
	return exec_classes;
}

void
MWRMComm::set_num_arch_classes ( int num )
{
	num_arches = num;
	arch_class_attributes = new char*[num];
	for ( int i = 0; i < num; i++ )
		arch_class_attributes[i] = NULL;
}

void
MWRMComm::set_arch_class_attributes ( int arch_class, char *attr )
{
	if ( arch_class >= num_arches )
		return;

	arch_class_attributes[arch_class] = new char[strlen(attr)+1];
	strcpy ( arch_class_attributes[arch_class], attr );
}

int
MWRMComm::get_num_arch_classes ( )
{
	return num_arches;
}

void
MWRMComm::set_num_executables ( int num )
{
	num_executables = num;
	tempnum_executables = 0;
	worker_executables = new RMC_executable*[num];
	for ( int i = 0; i < num; i++ )
	{
		worker_executables[i] = NULL;
	}
}



void MWRMComm::add_executable( int exec_class, int arch_class, char *exec_name, 
				      char *requirements )
{
	if ( !exec_name )
		return;

	if( arch_class >= num_arches ) 
	{
		MWprintf( 10, "set_worker_attributes(): incrementing num_arches to %d\n", 
							arch_class + 1 );
		num_arches = arch_class + 1;
	}

	worker_executables[tempnum_executables] = new struct RMC_executable;
	worker_executables[tempnum_executables]->arch_class = arch_class;
	worker_executables[tempnum_executables]->exec_class = exec_class;
	worker_executables[tempnum_executables]->executable = new char [ strlen(exec_name) + 1 ];
	strcpy ( worker_executables[tempnum_executables]->executable, exec_name );
	worker_executables[tempnum_executables]->executable_name = process_executable_name ( worker_executables[tempnum_executables]->executable, exec_class, arch_class );
	if ( !requirements )
	{
		worker_executables[tempnum_executables]->attributes = NULL;
	}
	else
	{
		worker_executables[tempnum_executables]->attributes = new char [ strlen(requirements) + 1 ];
		strcpy ( worker_executables[tempnum_executables]->attributes, requirements );
	}
	tempnum_executables++;
}

char* MWRMComm::process_executable_name( char *exec_name, int ex_cl, int ar_cl )
{
	char *newone = new char[strlen(exec_name) + 1];
	strcpy ( newone, exec_name );
	return newone;
}

void
MWRMComm::set_target_num_workers ( int num_workers )
{
	set_target_num_workers ( -1, num_workers );
}

void
MWRMComm::set_target_num_workers ( int exec_class, int num_workers )
{
	if ( exec_classes <= 0 )
	{
		exec_classes = 1;
		exec_class_target_num_workers = new int[exec_classes];
		exec_class_target_num_workers[0] = 0;
	}

	if ( exec_class < 0 )
	{
		exec_class_target_num_workers[0] = num_workers;
		target_num_workers += exec_class_target_num_workers[0];
		return;
	}

	target_num_workers -= exec_class_target_num_workers[exec_class];
	exec_class_target_num_workers[exec_class] = num_workers;
	target_num_workers += exec_class_target_num_workers[exec_class];
	return;
}

void MWRMComm::set_worker_checkpointing( bool wc )
{
  if( wc == true )
    MWprintf( 10, "Warning!  Worker checkpointing not available in this CommRM implementation\n" );
  worker_checkpointing = false;
}
