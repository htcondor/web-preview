
#ifndef MWGROUP_H
#define MWGROUP_H

#include "MW.h"

class MWGroup
{
	private:
		bool *group;
		int maxGroups;

	public:
		MWGroup ( int grp );
		~MWGroup ( );
		void join ( int num );
		void leave ( int num );
		bool belong ( int num );
		bool doesOverlap ( MWGroup *grp );
		void write_checkpoint ( FILE *fp );
		void read_checkpoint ( FILE *fp );
};
#endif /*MWGROUP_H*/
