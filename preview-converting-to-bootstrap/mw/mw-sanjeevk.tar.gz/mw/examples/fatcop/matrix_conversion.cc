#include <iostream.h>


void colmajor_to_rowmajor( int ncols,
			   const int colbeg[], const int colind[],
			   const double colval[],
			   int nrows, int rowbeg[], int rowind[],
			   double rowval[],
			   int rowcnt[], int nvals )
{
  
  int i, j;
  
  /* Count the number of nonzero elements per row */
  for( i = 0; i < nrows; i++ ) rowbeg[ i ] = 0;
  for( i = 0; i < nvals; i++ ) {
    rowbeg[ colind[ i ] ]++;
  }
  
  
  /* Convert the row counts to the starting positions */
  for( i = nrows; i > 0; i-- ) rowbeg[ i ] = rowbeg[ i - 1 ];
  for( rowbeg[ 0 ] = 0, i = 2; i <= nrows; i++ ) rowbeg[ i ] += rowbeg[ i-1 ];
  
  
  /* Insert the nonzero elements */
  for( i = 0; i < ncols; i++ )
    {
      for( j = colbeg[ i ]; j < colbeg[ i+1 ]; j++ )
	{
	  int row, rowfirst;
	  row = colind[ j ];
	  rowfirst = rowbeg[ row ];
	  rowind[ rowfirst ] = i;
	  rowval[ rowfirst ] = colval[ j ];
	  rowbeg[ row ]++;
        }
    }
  
  
  /* Shift back the starting positions */
  for( i = nrows - 1; i > 0; i-- ) rowbeg[ i ] = rowbeg[ i - 1 ];
  rowbeg[ 0 ] = 0;
  
  
  /* Find the row counts */
  for( i = 0; i < nrows; i++ )
    rowcnt[ i ] = rowbeg[ i + 1 ] - rowbeg[  i ];
}


void rowmajor_to_colmajor( int nrows,
			   const int rowbeg[],
			   const int rowind[], const double rowval[],
			   int ncols, int colbeg[], int colind[],
			   double colval[], int colcnt[],
			   int nvals )
{
  
  colmajor_to_rowmajor( nrows, rowbeg, rowind, rowval,
			ncols, colbeg, colind, colval,
			colcnt, nvals );
}

