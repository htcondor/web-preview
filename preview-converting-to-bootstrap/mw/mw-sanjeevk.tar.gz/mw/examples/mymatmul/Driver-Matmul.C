/* Driver-Matmul.C

These methods specific to the matrix multiplication application

*/

int **MatrixA, **MatrixB;

#include "MW.h"
#include "Driver-Matmul.h"
#include "Worker-Matmul.h"
#include "Task-Matmul.h"
extern double RMCOMM_bytes_packed;
extern double RMCOMM_bytes_unpacked;

void
Scanf ( int *m, int i, int j )
{
	*m = j;
}

Driver_Matmul::Driver_Matmul() 
{
	A = B = C = NULL;
	num_rows = 0;
	num_tasks = 0;
}

Driver_Matmul::~Driver_Matmul() 
{
	if ( A ) delete []A;
	if ( B ) delete []B;
	if ( C ) delete []C;
	A = B = C = NULL;
}

MWReturn Driver_Matmul::get_userinfo( int argc, char *argv[] ) 
{
	int i, j, numarches;
	char exec[_POSIX_PATH_MAX];
	int num_exe;

	/* File format of the input file (which is stdin)
	     # arches worker_executables ...

         num_rowsA num_rowsB num_colsB
	 A B C
	*/

	RMC->set_num_exec_classes ( 1 );
	scanf ( "%d", &numarches );
	RMC->set_num_arch_classes( numarches );
	for ( i=0 ; i<numarches ; i++ ) 
	{
		if ( i == 0 )
			RMC->set_arch_class_attributes ( i, "((Arch==\"INTEL\") && (Opsys==\"LINUX\") )" );
		else
			RMC->set_arch_class_attributes ( i, "((Arch==\"INTEL\") && (Opsys==\"SOLARIS26\") )" );
	} 
	
	scanf ( "%d", &num_exe );
	RMC->set_num_executables( num_exe );
	for ( i = 0; i < num_exe; i++ )
	{
		scanf ( "%s %d", exec, &j );
		MWprintf ( 30, " %s\n", exec );
		RMC->add_executable( 0, j, exec, "");
	}
	
	scanf ( "%d", &num_rows );
	scanf ( "%d", &partition_factor );

/*
	A = new int*[num_rows];
	for ( i = 0; i < num_rows; i++ )
		A[i] = new int[num_rows];

	B = new int*[num_rows];
	for ( i = 0; i < num_rows; i++ )
		B[i] = new int[num_rows];

	C = new int*[num_rows];
	for ( i = 0; i < num_rows; i++ )
		C[i] = new int[num_rows];

	for ( i = 0; i < num_rows; i++ )
		for ( j = 0; j < num_rows; j++ )
			Scanf ( &A[i][j], i, j );

	for ( i = 0; i < num_rows; i++ )
		for ( j = 0; j < num_rows; j++ )
			Scanf ( &B[i][j], i, j );

	for ( i = 0; i < num_rows; i++ )
		for ( j = 0; j < num_rows; j++ )
			C[i][j] = 0;
*/

	MatrixA = A;
	MatrixB = B;
	set_checkpoint_frequency ( 10000 );

	RMC->set_target_num_workers( 40 );

	num_tasks = ( num_rows / partition_factor )* ( num_rows / partition_factor) * ( num_rows / partition_factor );

	return OK;
}

MWReturn Driver_Matmul::setup_initial_tasks(int *n_init , MWTask ***init_tasks) 
{

	int i, j, k;
	int index = 0;

/* Basically we have to tell MW Layer of the number of tasks and what they are */

	*n_init = num_tasks;
	*init_tasks = new MWTask *[num_tasks];

/* And now we make the Task_Matmul instances.  They will basically contain the 
   rows to operate upon.
*/

	for ( i = 0 ; i < num_rows / partition_factor; i++ ) 
	{
		for ( j = 0; j < num_rows / partition_factor; j++ )
		{
			for ( k = 0; k < num_rows / partition_factor; k++ )
			{
				(*init_tasks)[index++] = new Task_Matmul ( i, j, k, num_rows, partition_factor );
			}
		}
	}

	return OK;
}


MWReturn Driver_Matmul::act_on_completed_task( MWTask *t ) 
{

	return OK;

	int i, j;

#ifdef NO_DYN_CAST
	Task_Matmul *tf = (Task_Matmul *) t;
#else
	Task_Matmul *tf = dynamic_cast<Task_Matmul *> ( t );
#endif
	int strtR = tf->resultStartR;
	int strtC = tf->resultStartC;
	int indexi = 0, indexj = 0;

	for ( i = strtR; i < strtR + partition_factor; i++ )
	{
		indexj = 0;
		for ( j = strtC; j < strtC + partition_factor; j++ )
		{
			C[i][j] += tf->results[indexi][indexj];
			indexj++;
		}
		indexi++;
	}
	
	return OK;
}

MWReturn Driver_Matmul::pack_worker_init_data( void ) 
{
	RMC->pack ( &partition_factor, 1 );
	return OK;
}

void Driver_Matmul::printresults() 
{
	MWprintf ( 10, "The resulting Matrix is as follows\n");

	/*
	for ( int i = 0; i < num_rows; i++ )
	{
		for ( int j = 0; j < num_rows; j++ )
			MWprintf ( 10, "%d ", C[i][j] );

		MWprintf ( 10, "\n" );
	}
	*/

	MWprintf ( 10, "Bytes Packed %lf\n", RMCOMM_bytes_packed );
	MWprintf ( 10, "Bytes Unpacked %lf\n", RMCOMM_bytes_unpacked );
}

void
Driver_Matmul::write_master_state( FILE *fp ) 
{
	// This is not checkpoint enabled.
}

void 
Driver_Matmul::read_master_state( FILE *fp ) 
{
	// This is not checkpoint enabled.
}

MWTask*
Driver_Matmul::gimme_a_task() 
{
	/* The MWDriver needs this.  Just return a Task_Matmul instance. */
	return new Task_Matmul;
}

MWDriver*
gimme_the_master () 
{
    return new Driver_Matmul;
}
