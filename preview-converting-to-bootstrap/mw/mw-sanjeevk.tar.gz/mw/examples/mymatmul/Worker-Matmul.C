/* Worker-Matmul.C */

#include "Worker-Matmul.h"
#include "Task-Matmul.h"

int **MatrixA, **MatrixB;
void Scanf ( int *m, int i, int j )
{
	return;
}

Worker_Matmul::Worker_Matmul() 
{
	// do this here so that workingtask has type Task_Fib, and not
	// MWTask type.  This class holds info for the task at hand...
	workingTask = new Task_Matmul;
	partition_factor = 0;
}

Worker_Matmul::~Worker_Matmul() 
{
	delete workingTask;
}

MWReturn Worker_Matmul::unpack_init_data( void ) 
{
	RMC->unpack ( &partition_factor, 1 );
	return OK;
}

void Worker_Matmul::execute_task( MWTask *t ) 
{
	int i, j, k;

	Task_Matmul *tf = (Task_Matmul *) t;

	tf->results = new int*[partition_factor];
	for ( i = 0; i < partition_factor; i++ )
	{
		tf->results[i] = new int[partition_factor];
		for ( k = 0; k < partition_factor; k++ )
			tf->results[i][k] = 0;

		for ( j = 0; j < partition_factor; j++ )
			for ( k = 0; k < partition_factor; k++ )
				tf->results[i][k] += tf->A[i][j] * tf->B[j][k];
	}
}

MWWorker*
gimme_a_worker ()
{
    return new Worker_Matmul;
}
