#ifndef TASK_MATMUL_H
#define TASK_MATMUL_H

#include <stdio.h>
#include "MWTask.h"

class Task_Matmul : public MWTask 
{

 public:
    
    Task_Matmul();

    Task_Matmul( int i, int j, int k, int num_rows, int partition_factor );

    ~Task_Matmul();

    void pack_work( void );
    
    void unpack_work( void );
    
    void pack_results( void );
    
    void unpack_results( void );

    void printself( int level = 60 );

    void write_ckpt_info( FILE *fp );
    void read_ckpt_info( FILE *fp );

    int startRowA;
    int startColA;
    int startRowB;
    int startColB;
    int partition_factor;
	int resultStartR;
	int resultStartC;
	int **A, **B;
    int **results;
};

#endif
