/* Task-Matmul.C */

#include "Task-Matmul.h"
#include "MW.h"

#include "MWRMComm.h"
#include <string.h>

extern int **MatrixA, **MatrixB;

extern void Scanf ( int *, int, int );

Task_Matmul::Task_Matmul() 
{
	startRowA = startColA = -1;
	startRowB = startColB = -1;
	resultStartR = resultStartC = -1;
	partition_factor = 0;
	results = NULL;
}

Task_Matmul::Task_Matmul( int i, int j, int k, int num_rows, int prtn_factor )
{
	startRowA = i * prtn_factor;
	startColA = j * prtn_factor;
	startRowB = j * prtn_factor;
	startColB = k * prtn_factor;
	partition_factor = prtn_factor;
	resultStartR = i * prtn_factor;
	resultStartC = k * prtn_factor;
	A = B = results = NULL;
}

Task_Matmul::~Task_Matmul() 
{
    if ( results )
	{
		for ( int i = 0; i < partition_factor; i++ )
			delete [] results[i];
		delete [] results;
	}
	results = NULL;
}

void
Task_Matmul::printself( int level ) 
{
	// Right now nothing
}


void Task_Matmul::pack_work( void ) 
{
	int i, j;
	int packedint;
	RMC->pack( &partition_factor, 1, 1 );

	for ( i = startRowA; i < startRowA + partition_factor; i++ )
	{
		for ( j = startColA; j < startColA + partition_factor; j++ )
		{
			Scanf( &packedint, i, j);
			RMC->pack ( &packedint, 1, 1 );
		}
	}

	for ( i = startRowB; i < startRowB + partition_factor; i++ )
	{
		for ( j = startColB; j < startColB + partition_factor; j++ )
		{
			Scanf( &packedint, i, j );
			RMC->pack ( &packedint, 1, 1 );
		}
	}

}


void Task_Matmul::unpack_work( void ) 
{
	int i, j;
	RMC->unpack( &partition_factor, 1, 1 );

	A = new int*[partition_factor];
	for ( i = 0; i < partition_factor; i++ )
	{
		A[i] = new int[partition_factor];
		for ( j = 0; j < partition_factor; j++ )
			RMC->unpack ( &A[i][j], 1, 1 );
	}

	B = new int*[partition_factor];
	for ( i = 0; i < partition_factor; i++ )
	{
		B[i] = new int[partition_factor];
		for ( j = 0; j < partition_factor; j++ )
			RMC->unpack ( &B[i][j], 1, 1 );
	}
}


void Task_Matmul::pack_results( void ) 
{
	int i;
	for ( i = 0; i < partition_factor; i++ )
		RMC->pack( results[i], partition_factor, 1 );

	for ( i = 0; i < partition_factor; i++ )
	{
		delete [] A[i];
		delete [] B[i];
		delete [] results[i];
	}
	delete [] results;
	delete [] A;
	delete [] B;
	results = A = B = NULL;
}


void Task_Matmul::unpack_results( void ) 
{
	results = new int*[partition_factor];
	for ( int i = 0; i < partition_factor; i++ )
	{
		results[i] = new int[partition_factor];
    	RMC->unpack( results[i], partition_factor, 1 );
	}
}

void Task_Matmul::write_ckpt_info( FILE *fp ) 
{
	// Not checkpoint enabled.
}

void Task_Matmul::read_ckpt_info( FILE *fp ) 
{
	// Not checkpoint enabled.
}
