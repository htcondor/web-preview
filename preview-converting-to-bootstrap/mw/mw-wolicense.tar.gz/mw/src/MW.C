#include "MW.h"
// timing functions 
double 
timeval_to_double( struct timeval t )
{
	return (double) t.tv_sec + ( (double) t.tv_usec * (double) 1e-6 );
}
double 
_measure_cur_wall_time() 
{
        struct timeval tt;
        gettimeofday ( &tt, NULL );
        return timeval_to_double ( tt );
}

double 
_measure_cur_cpu_time()
{
	struct rusage rt;
	getrusage ( RUSAGE_SELF, &rt );
	return timeval_to_double ( rt.ru_utime ) + timeval_to_double ( rt.ru_stime );
}
