/*
 * MW - Master-Worker Library for Condor
 * Copyright (C) 2002 Condor Team
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Attention:
 * Professor Miron Livny
 * 7367 Computer Sciences
 * 1210 W. Dayton St.
 * Madison, WI 53706-1685
 * (608) 262-0856
 * miron@cs.wisc.edu
 */
#ifndef MWFILEWORKER_H
#define MWFILEWORKER_H

enum FileWorkerState
{ 
    FILE_FREE,
    FILE_SUBMITTED,
    FILE_EXECUTE,	// Started executing for the first time.
    FILE_RUNNING, 
    FILE_KILLED, 
    FILE_SUSPENDED,
    FILE_RESUMED,
    FILE_IDLE,
    FILE_TRANSIT,
};


struct FileWorker
{
    int id;

    // What is the message number that I have to look next for.
    int counter;

    // What is the message that the worker is looking for.
    int worker_counter;

    // What is the condor_id of the worker.
    int condorID;

    // What is the proc id.
    int condorprocID;

    FileWorkerState state;

    int arch;

    int event_no;

    /** What was last served */
    int served;

	int exec_class;
};

#endif
