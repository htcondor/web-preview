/*
 * MW - Master-Worker Library for Condor
 * Copyright (C) 2002 Condor Team
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Attention:
 * Professor Miron Livny
 * 7367 Computer Sciences
 * 1210 W. Dayton St.
 * Madison, WI 53706-1685
 * (608) 262-0856
 * miron@cs.wisc.edu
 */

#include "MWGroup.h"

MWGroup::MWGroup ( int grps )
{
	maxGroups = grps;
	group = new bool[maxGroups];
	for ( int i = 0; i < maxGroups; i++ )
		group[i] = FALSE;
}

MWGroup::~MWGroup ( )
{
	delete []group;
}

void
MWGroup::join ( int num )
{
	if ( num >= 0 && num < maxGroups )
		group[num] = TRUE;
}

void
MWGroup::leave ( int num )
{
	if ( num >= 0 && num < maxGroups )
		group[num] = FALSE;
}

bool
MWGroup::belong ( int num )
{
	if ( num >= 0 && num < maxGroups )
		return group[num];

	return FALSE;
}

bool
MWGroup::doesOverlap ( MWGroup *grp )
{
	for ( int i = 0; i < maxGroups; i++ )
	{
		if ( belong ( i ) && grp->belong ( i ) )
			return TRUE;
	}
	return FALSE;
}

void
MWGroup::write_checkpoint ( FILE *fp )
{
	int num = 0;
	int i;
	for ( i = 0; i < maxGroups; i++ )
		if ( belong ( i ) ) num++;
	fprintf ( fp, "%d ", num );

	for ( i = 0; i < maxGroups; i++ )
		if ( belong ( i ) )
			fprintf ( fp, "%d ", i );
	fprintf ( fp, "\n" );
}

void
MWGroup::read_checkpoint ( FILE *fp )
{
	int i, temp;
	int gp;
	fscanf ( fp, "%d ", &temp );
	for ( i = 0; i < temp; i++ )
	{
		fscanf ( fp, "%d ", &gp );
		join ( gp );
	}
}
