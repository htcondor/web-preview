/*
 * MW - Master-Worker Library for Condor
 * Copyright (C) 2002 Condor Team
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Attention:
 * Professor Miron Livny
 * 7367 Computer Sciences
 * 1210 W. Dayton St.
 * Madison, WI 53706-1685
 * (608) 262-0856
 * miron@cs.wisc.edu
 */
#ifndef MWNWSTASK_H
#define MWNWSTASK_H

#include <stdio.h>
#include "MWTask.h"

/** The task class specific to NWS weather monitoring
*/

class MWNWSTask : public MWTask {

 public:
    
    /// Default Constructor
    MWNWSTask();

    /** 
    */
    MWNWSTask( int, double, int, int, char* );

    MWNWSTask( const MWNWSTask& );

    /// Default Destructor
    ~MWNWSTask();

    MWNWSTask& operator = ( const MWNWSTask& );

    /**@name Implemented methods
       
       These are the task methods that must be implemented 
       in order to create an application.
    */
    //@{
    /// Pack the work for this task into the PVM buffer
    void pack_work( void );
    
    /// Unpack the work for this task from the PVM buffer
    void unpack_work( void );
    
    /// Pack the results from this task into the PVM buffer
    void pack_results( void );
    
    /// Unpack the results from this task into the PVM buffer
    void unpack_results( void );
    //@}

        /// dump self to screen:
    void printself( int level = 60 );

    /**@name Checkpointing Implementation 
       These members used when checkpointing. */
    //@{
        /// Write state
    void write_ckpt_info( FILE *fp );
        /// Read state
    void read_ckpt_info( FILE *fp );
    //@}

    /**@name Input Parameters.
       These parameters are sent to the other side */
    //@{
    	/// the number of measurements.
    int iterations;
	/// the interval between measurements
    double timeInterval;
    	/// the port to connect to.
    int portNo;
    	/// the machine name.
    char machineAddress[_POSIX_PATH_MAX];
    //@}

    /**@name Output Parameters.
       These parameters are returned by the workers */
    //@{
    	/// the maximum latency observed.
    double max;
    	/// the minimum latency observed.
    double min ;
    	/// the median latency observed.
    double median ;
    //@}
};

#endif
