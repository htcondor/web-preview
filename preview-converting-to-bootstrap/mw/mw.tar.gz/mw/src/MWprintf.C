/*
 * MW - Master-Worker Library for Condor
 * Copyright (C) 2002 Condor Team
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Attention:
 * Professor Miron Livny
 * 7367 Computer Sciences
 * 1210 W. Dayton St.
 * Madison, WI 53706-1685
 * (608) 262-0856
 * miron@cs.wisc.edu
 */
/* MWprintf.C - The place for the MWPrintf stuff. */

#include "MW.h"
#include <stdarg.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <string.h>

int MWprintf_level = 50;
static int fopen_count = 0;

FILE* Open ( char *filename, char *mode )
{
    FILE *fp;

    fp = fopen ( filename, mode );
    if ( fp ) { 
      fopen_count++;
    }
    else{
      //MWprintf ( 10, "Could not open file %s as errno is %d\n", filename, errno );
    }
    return fp;
}

void Close ( FILE *fp )
{
    int retval;
	fflush(fp);
    retval = fclose ( fp );
    if ( retval != 0 )
    	MWprintf ( 10, "Could not close the file %x as errno is %d\n", fp, errno );
    else
    	fopen_count--;
}

int set_MWprintf_level ( int level ) {
	int foo = MWprintf_level;
	if ( (level<0) || (level>99) ) {
		MWprintf( 10, "Bad arg \"%d\" in set_MWprintf_level().\n", level );
	} else {
		MWprintf_level = level;
	}
	return foo;
}

void MWprintf ( int level, char *fmt, ... ) {

	static int printTime = TRUE;

	if ( level > MWprintf_level ) {
		return;
	}

	if ( printTime ) {
		char *t;
		time_t ct = time(0);
		t = ctime( &ct );
		t[19] = '\0';
		printf( "%s ", &t[11] );
	}

	va_list ap;
	va_start( ap, fmt );
	vprintf( fmt, ap );
	va_end( ap );
	fflush( stdout );
	fsync(fileno(stdout));

	if ( fmt[strlen(fmt)-1] == '\n' ) 
		printTime = TRUE;
	else
		printTime = FALSE;
}
