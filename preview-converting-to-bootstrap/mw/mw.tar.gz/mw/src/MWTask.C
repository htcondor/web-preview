/*
 * MW - Master-Worker Library for Condor
 * Copyright (C) 2002 Condor Team
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Attention:
 * Professor Miron Livny
 * 7367 Computer Sciences
 * 1210 W. Dayton St.
 * Madison, WI 53706-1685
 * (608) 262-0856
 * miron@cs.wisc.edu
 */
/* MWTask.C

   The implementation of the MWTask class

*/

#include "MWTask.h"
#include "MWDriver.h"
#include <stdio.h>

extern int MWworkClasses;
extern int *MWworkClassTasks;

MWTask::MWTask() {
	number = -1;
	worker = NULL;
	taskType = MWNORMAL;
	group = new MWGroup ( MWworkClasses );
}

MWTask::~MWTask() {
  if ( worker )
    if ( worker->runningtask )
      worker->runningtask = NULL;

  delete group;
}

void MWTask::printself( int level ) 
{    
	MWprintf ( level, "  Task %d\n", number);
}

void
MWTask::initGroups ( int num )
{
	// found LEAK_ASSIGN (group probably already allocated!)
	// group = new MWGroup ( num );
	if (group != NULL)
		delete group;
	group = new MWGroup( num );
}

void
MWTask::addGroup ( int num )
{
	if ( doesBelong ( num ) )
		return;
	MWworkClassTasks[num]++;
	group->join ( num );
}

void
MWTask::deleteGroup ( int num )
{
	if ( !doesBelong ( num ) )
		return;
	MWworkClassTasks[num]--;
	group->leave ( num );
}

bool
MWTask::doesBelong ( int num )
{
	return group->belong ( num );
}

MWGroup*
MWTask::getGroup ( )
{
	return group;
}

void
MWTask::write_group_info ( FILE *fp )
{
	group->write_checkpoint ( fp );
}

void
MWTask::read_group_info ( FILE *fp )
{
	// found LEAK_ASSIGN (group probably already allocated!)
        // group = new MWGroup ( num );
	if (group != NULL)
		delete group;
	group = new MWGroup ( MWworkClasses );
	group->read_checkpoint ( fp );
	for ( int i = 0; i < MWworkClasses; i++ )
	{
		if ( doesBelong ( i ) )
			addGroup ( i );
	}
}
