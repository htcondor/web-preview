import java.io.*;
import java.util.*;
import java.net.*;

/** MWWorkerExe is the wrapper around MWWorker and MyWorkerThread. It create
 *  these objects and connect them with each other, it then calls the 
 *  worker.mainloop() function, and give the control to the worker. 
 *  
 *  This is not a nice way to start, I tried this since I once wanted to use 
 *  Java's Thread.suspend() and Thread.resume(), etc, to control the worker
 *  computation. That's why I splitted the worker functionality into two parts
 *  MWWorker (listens to MWDriver), and MWWorkerThread (only execute a task).
 */
public class MWWorkerExe
{
	public static void main(String[] args) {
	   	/* Please change MyWorker into your application worker class name */
	   	MWWorker worker = new MWWorker();
		MyWorkerThread t = new MyWorkerThread(worker);
		worker.templateThread = t;

	   	worker.setup(args);
	   	worker.mainloop();
		
	   	/* won't reach here since we will exit in mainloop */
	}
}
