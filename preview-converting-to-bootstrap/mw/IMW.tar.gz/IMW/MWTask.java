import java.util.*;

/** 
 * <code>MWTask</code> defines the interface of an abstraction of a piece of 
 * work to be executed by a worker. It provides APIs to be filled to pack and 
 * unpack the input (packed by master, unpacked by worker) and output (packed 
 * by worker, unpacked by master) of a piece of work. Assuming for data 
 * analysis, we don't have to move large piece of data to/from workers, we can
 * just use a string to represent the work. 
 *
 * 		<code>String pack_work(String header)</code>
 * 		<code>String unpack_work(String payload)</code>
 * 		<code>String pack_result(String header)</code>
 * 		<code>String unpack_result(String payload)</code>
 */
public class MWTask {
	public static final int T_UNASSIGNED = 1;
	public static final int T_ASSIGNED 	 = 2;
	public static final int T_DONE 		 = 3;
	
	public MWUtil MW;
	public MWTaskCluster tc;
	public int type;		/* corresponding to command type: SCRIPT/HISTO/OTHER */
	public int TCID;		/* task cluster ID */
	public int ID;			/* task ID */
	public List workers;	/* which workers are executing it */
	public int state;		/* state */

	public MWTask(MWUtil MW) {
		this.MW = MW;
		tc = null;
		state  = T_UNASSIGNED;
		workers = new LinkedList();
	}

	/** Pack the input of this task into a String buffer */
	public String pack_work(String header) {
		String str = header 
			+ type + " " + TCID + " " + ID + " " ;
		return str;
	}
	
	/** Pack the result of this task into a String buffer */
	public String pack_result(String header) {
		String str = header 
			+ type + " " + TCID + " " + ID + " ";
		return str;
	}

	/** Unpack the input of a task into local data member */
	public String unpack_work(String str) {
		MW.printf("MWTask unpacking");
		MWMessage msg;
	   
		/* type */
		msg = new MWMessage(str);
		type = MW.parseMessage(msg);
		MW.printf("type = " + type);

		/* TCID */
		msg = new MWMessage(msg.tail);
		TCID = MW.parseMessage(msg);
		MW.printf("TCID = " + TCID);

		/* parse ID */
		msg = new MWMessage(msg.tail);
		ID = MW.parseMessage(msg);
		MW.printf("ID = " + ID);
		
		return msg.tail;
	}

	/** Unpack the result of a task into local result member */
	public String unpack_result(String str) {
		MWMessage msg;
		
		/* parse type */
		msg = new MWMessage(str);
	   	type = MW.parseMessage(msg);
	   
		/* TCID */
	   	msg = new MWMessage(msg.tail);
		TCID = MW.parseMessage(msg);

		/* parse ID */
		msg = new MWMessage(msg.tail);
		ID = MW.parseMessage(msg);
		
		/* sth that MW controls: in case the app forgets */
		if (state != T_DONE) {
			state = T_DONE;
			tc.done ++;
		}

		/* return */
		return msg.tail;
	}
};

