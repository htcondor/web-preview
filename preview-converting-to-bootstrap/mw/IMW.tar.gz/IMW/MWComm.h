#ifndef _MW_COMM
#define _MW_COMM

#include "MWprintf.h"
#define MW_PORT 	9000
#define MWSOCKET_MAX_MSG_SIZE   (64*1024)
#define MWSOCKET_MAX_BUF_SIZE	(MWSOCKET_MAX_MSG_SIZE + 24)

class MWComm
{
	/* private data members */
private:
	int  mode;			/* 0 - socket, 1 - file */
	FILE *file;			/* only valid if using file */
	MWprintf *MW;
	int  id;			/* the worker id */
	int	 send_soc;		/* to send to the master */
    int  recv_soc;		/* to receive from the master */
   	char my_host[128];
   	int  master_port;	/* also my own port */
   	char master_host[128];
	
	/* input buffering */
	char recv_buf[MWSOCKET_MAX_BUF_SIZE * 2];
	/* which half of the recv_buf we are writing to: 1 or 2. Will check 
	 * the tail_pos after a read, and switch buffer when tail reaches the end of current buffer */
	int  which_buf;	
	int  msg_length;
	bool has_header; /* remember whether a header is already in the buffer */
	int  head_pos;	 /* In the recv_buf, where is the pos that we should read from */ 
	int	 tail_pos;	 /* In the recv_buf, where is the pos that we should write to */
	char recv_ret[MWSOCKET_MAX_BUF_SIZE];

	/* output buffering */
	char send_buf[MWSOCKET_MAX_BUF_SIZE];

private:
	/* recv */
	int b_recv(int len, char* buffer);	/** blocking recv */
	int n_recv(int len, char* buffer);	/** non-blocking recv */

public:
	bool has_message();		/* is there any new message (actually message header) received? */
	char* next_message();	/* return the next message body */

public:
	MWComm(MWprintf* out, int id, int serv_port, char* serv_host);
	MWComm(MWprintf *out, int id, char* fname);
	void bind(int port);
	void connect();
		
	/* send */
	int sock_send(int tag, char* buffer);
	int file_send(int tag, char* buffer);
	int sys_send(int socket, void *buffer, size_t len, int flags);
};

#endif
