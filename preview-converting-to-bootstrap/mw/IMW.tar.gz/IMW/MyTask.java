import java.util.*;

/** 
 * <code>MyTask</code> extends the MWTask class. Each MyTask contain two more
 * input fields (range_lower, and range_upper), and one result field (result). 
 *
 * A worker will put the sum of all integers between range_lower and range_upper
 * into result. The following virtual functions are filled in.
 *
 * 		<code>String pack_work(String header)</code>
 * 		<code>int unpack_work(String payload)</code>
 * 		<code>String pack_result(String header)</code>
 * 		<code>int unpack_result(String payload)</code>
 */

public class MyTask extends MWTask {
	/** For ROOT/PROOF: most of the tasks can be specified by a range of data
	 *  to be analyzed, so we will add two fields to denote the beginning and 
	 *  end of the range. Currently we assume that tasks are constructed from 
	 *  a initial command (say, analyze dataset 0-100) initially, and the 
	 *  command is finished when no task is in the queue. We can also 
	 *  create tasks dynamically by chopping a piece of task from the BIG
	 *  initial task incrementally, until there is nothing to be chopped off. 
	 */
	public int range_lower;
	public int range_upper;

	/* the simpliest form of result: a double */
	public int result;

	public MyTask() {
		super(null);
	}

	public MyTask(MWUtil MW, int type, int low, int high) {
		super(MW);
		this.type = type;
		this.range_lower = low;
		this.range_upper = high;
		MW.printf("Task created: low = " + low + ", high = " + high);
	}

	/** Pack the input of this task into a String buffer */
	public String pack_work(String header) {
		/* XXX always put the super().pack_work() ahead of my logic */
		String buf = super.pack_work(header) 
			+ range_lower + " " + range_upper + " ";
		return buf;
	}
	
	/** Pack the result of this task into a String buffer */
	public String pack_result(String header) {
		String buf = super.pack_result(header) + result + " ";
		return buf;
	}

	/** Unpack the input of a task into local data member */
	public String unpack_work(String str) {
		MW.printf("MyTask unpacking");
		String remain = super.unpack_work(str);
		StringTokenizer st = new StringTokenizer(remain);
		range_lower = MWUtil.str2int(st.nextToken());
		range_upper = MWUtil.str2int(st.nextToken());

		MW.printf("lower = " + range_lower);
		MW.printf("upper = " + range_upper);
		return null;
	}

	/** Unpack the result of a task into local result member */
	public String unpack_result(String str) {
		String remain = super.unpack_result(str);
		
		StringTokenizer st = new StringTokenizer(remain);
		result = MWUtil.str2int(st.nextToken());

		return null;
	}
};

