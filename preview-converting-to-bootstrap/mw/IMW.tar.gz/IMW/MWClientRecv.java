import javax.swing.*;
import java.util.*;
import java.io.*;
import java.net.*;

/** <code>MWClientRecv</code> extends the MWRecv class by adding filters
 * so that when an incoming message matches the filters, it will be posted
 * to a GUI JTextArea, and won't be put into the FIFO. 
 */

public class MWClientRecv extends MWRecv
{
	public JTextArea ta;
	public LinkedList filters;
	
	public MWClientRecv (MWUtil MW, Socket soc, List FIFO, JTextArea ta) {
		super(MW, soc, FIFO);
		this.ta = ta;
		this.filters = new LinkedList();
   	}

	/** Install a message filter, so that whenever it receives a 
	 * message of filter type, it will post it onto TextArea ta */
	public void addFilter(int cmd) {
		for (int i=0; i<filters.size(); i++)
			if ( cmd == ((Integer)filters.get(i)).intValue() )
				return;

		filters.add(new Integer(cmd));
	}

	/** match filter */
	public boolean matchFilter(int cmd) {
		for (int i=0; i<filters.size(); i++)
			if ( cmd == ((Integer)filters.get(i)).intValue() )
				return true;
		return false;
	}

	/** Keep receiving messages and append to the FIFO */
	public void run() {
	   	String line;
		boolean open = true;
		while (open) {
		   	line = MW.recv(in);
			if (line != null) {
				MWMessage msg = new MWMessage(line);
				int head = MW.parseMessage(msg);
				if (matchFilter(head) == true) {
					ta.append("\n " + msg.tail + "\n");
					ta.setCaretPosition(ta.getDocument().getLength());
				} else {
			   		synchronized (FIFO) { FIFO.add(line); }
				}
			} else { 
				MW.waitFor(100);
			}
	   	}
   	}
};
