import java.util.*;

/** 
 * <code>MWTaskCluster</code> is a cluster of related tasks. 
 */
public class MWTaskCluster {
	public static int serial = 0;
	public int TID;			/* serial ID for subtasks */
	public int ID;			/* cluster ID */
	public int type;		/* command type */
	public int done;		/* number of done tasks in this group */
	public int assigned;	/* number of assigned tasks in this group */
	public int unassigned;	/* number of unassigned tasks in this group */
	public List tasks;		/* list of sub-tasks */

	public MWTaskCluster() {
		ID = serial++;	
		TID = 0;
		type = MWUtil.CMD_SCRIPT;
		tasks = new LinkedList();
		done = assigned = unassigned = 0;
	}

	public int size() {
		return tasks.size();
	}
	
	public void addTask(MWTask t) {
		tasks.add(t);
		t.ID = TID++;
		t.TCID = ID;
		t.tc = this;
		unassigned ++;
	}
};

