#! /bin/sh
mkdir oldruns

chmod 644 log_file.* output_file.* error_file.* submit.imw*
for i in log_file.* output_file.* error_file.* submit.imw*
do 
	mv -f $i oldruns
done

#foreach i (`ls output_file.* error_file.* log_file.*`) 
#	mv -f $i oldruns
#end

