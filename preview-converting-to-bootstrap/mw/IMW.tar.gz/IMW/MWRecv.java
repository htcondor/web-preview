import java.util.*;
import java.io.*;
import java.net.*;

/** <code>MWRecv</code> implements a Runnable object that can listen
 * to a given reader socket, and append the received message into a message
 * FIFO. It also provides message parsing functions to help separate message
 * header from the payload. 
 */

public class MWRecv implements Runnable 
{
	public MWUtil MW;
	public Socket s;
	public List FIFO;
   	public BufferedReader in;

	/** @param out  The writer to be used as stdout.
	 *  @param in   The reader created based on a incoming socket
	 *  @param FIFO The message queue where the incoming message is enqueued */
	public MWRecv (MWUtil MW, Socket soc, List FIFO) {
		this.MW = MW;
		this.FIFO = FIFO;
		this.s = soc;
	   	try { 
		   	this.in= new BufferedReader(new InputStreamReader(s.getInputStream()));
	   	} catch  (IOException e) {
		   	MW.printf("No I/O");
		   	System.exit(1);
	   	}
   	}

	/** Keep receiving messages and append to the FIFO */
	public void run() {
	   	String line;
		boolean open = true;
		while (open) {
		   	line = MW.recv(in);
			if (line != null) {
				// MW.printf("MWRecv: got |" + line + "|, FIFO len = " + FIFO.size());
			   	synchronized (FIFO) { FIFO.add(line); }
				// MW.printf("MWRecv: appending done!");
			}  else { 
				MW.waitFor(100);
			}
	   	}
   	}
};
