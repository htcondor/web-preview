/** 
 * A <code>MWMessage</code> structure is used to to hold a piece of message, 
 * and it's parsing result. The parser will read the msg field, which is a 
 * String, separate the first token from the rest of string, putting each 
 * into head and tail field. Usually the head token represent a message 
 * type, the value of the type will be stored into type field. 
 */

public class MWMessage {
   	public int type = 0;
   	public String msg = null;
   	public String head = null;
   	public String tail = null;

	/** Create a MWMessage from a string.
	 *  @param line  The original message string. 
	 */
   	public MWMessage(String line) {
	   	this.msg = new String(line);
   	}
};

