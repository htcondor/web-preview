import java.io.*;
import java.util.*;
import java.net.*;

/** <code>MWWorker</code> defines the interface of an IMW worker. 
 * It also implements the default behavior of a worker - init, 
 * wait for work, work, and return results. 
 */
public class MWWorker 
{
	public MWUtil MW;
	public int id;
	public int master_id;
	public int master_port;
	public String master_host;
	public String hostname;
	public Socket socket;
	public PrintWriter out;
	public BufferedReader in;
	public List FIFO = null;
	public boolean paused;
	
	/* The following members are used to work with MWWorkerThread, 
	 * which is created to execute a single task. We use it since it
	 * seems to be easier to pause/resume the thread in Java. 
	 * However since Thread.suspend()/resume() is deprecated, it
	 * is still a HACK. 
	 *
	 * The other way is to just use MWWorker to execute the task, 
	 * and have it check for pause signal periodically. It should
	 * not be too hard to switch to that approach. 
	 */
	public MWWorkerThread templateThread; /* the template Thread */
	public MWWorkerThread curThread; /* the thread that is being executed */

	public MWWorker() {
		try { 
			MW = new MWUtil(new PrintStream(new FileOutputStream("worker.log")));
		} catch (FileNotFoundException e) {
			/* System.exit(1); */
		}
		MW.printf("A worker is created");
		FIFO = new LinkedList();
		paused = false;
	}
	
	/** Virtual function the get a MWWorkerThread */
	public MWWorkerThread newThread() {
		return null;
	}
	
	public void setup(String[] args) {
	   	try {
		   	hostname = InetAddress.getLocalHost().getHostName();
	   	} catch (UnknownHostException e1) {
		   	MW.printf("Can't figure out local host name.");
	   	} catch (SecurityException e2) {
		   	MW.printf("Security problem when getting local host");
	   	}
		this.id = MWUtil.str2int(args[0]);
		this.master_id = MWUtil.str2int(args[1]);
		this.master_port = MWUtil.str2int(args[2]);
		this.master_host = args[3];
		MW.printf("MWWorker " + id + " started on " + hostname);
		
		/* connect back to the master */
	   	try {
		   	socket = new Socket(master_host, master_port);
		   	out = new PrintWriter(socket.getOutputStream(), true);
	   	} catch (UnknownHostException e) {
		   	MW.printf("Unknown host: " + master_host);
		   	System.exit(1);
	   	} catch  (IOException e) {
		   	MW.printf("No I/O: " + master_host + " " + master_port); 
			System.exit(1);
	   	}

	   	MW.printf("MWWorker sending MWUtil.WD_CREATED");
	   	MW.sendMessage(out, MWUtil.WD_CREATED, " " + this.id + " " + hostname);

		/* create a listener for MWDriver events */
	   	MWRecv listener = new MWRecv(MW, socket, FIFO);
	   	Thread t = new Thread(listener);
	   	t.start();
	}

	/** The worker mainloop */
	public void mainloop() {
		int type; 
		MWMessage line;
		
		while (true) {
			if (FIFO.isEmpty() == false) {
				synchronized (FIFO) { line = MW.getMessage(FIFO, 0); }
				MW.printf("MWWorker got message {" + line.msg+ "}");
				type = MW.parseMessage(line);
				MW.printf("type = " + type + ", remain = " + line.tail);
				switch (type) {
					case MWUtil.DW_WORK:
						String cmdline = line.tail;

						curThread = (MWWorkerThread)templateThread.clone();
						MW.printf("Will unpack work");
						MW.printf("task = ");
						MW.printf(curThread.task.toString());
						curThread.task.unpack_work(cmdline);
						MW.printf("Will start WorkerThread with cmdline of " + cmdline);
						curThread.start();
						break;
						
					case MWUtil.DW_PAUSE:
						onPause(line.tail);
						break;
						
					case MWUtil.DW_RESUME:
						onResume(line.tail);
						break;
					
					case MWUtil.DW_QUIT:
						onQuit();
						break;
						
					case MWUtil.DW_RESTART:
						onRestart(line.tail);
						break;

					default:
						MW.printf("MWWorker " + id + " got unknown event " + type);
						break;
				} 
			} else {
				MW.waitFor(1000);
			}
		} /* end of while */
	}

   	public void onPause(String line) {
		if (curThread.isAlive()) {
			paused = true;
			curThread.suspend();
	   		MW.sendMessage(out, MWUtil.WD_PAUSED, " " + this.id + " " + hostname);
		}
	}
	
   	public void onResume(String line) {
		if (paused == true) {
			paused = false;
			curThread.resume();
   			MW.sendMessage(out, MWUtil.WD_RESUMED, " " + this.id + " " + hostname);
		}
	}
	
	public void onRestart(String line) {
	}

   	public void onQuit() {
		MW.printf("Got suicide message, will exit!");
		System.exit(1);
	}

	/** execute a shell script and return the output as a String */
   	public String execScript(String script) {
	   	String ret = new String();
	   	Process p;
	   	BufferedReader stdOutput, stdError;

		MW.overwriteFile("script.exe", script);

		try {
			/* From Marv, if script is a bash script, then use "-c" option */
			p = Runtime.getRuntime().exec("chmod 755 ./script.exe"); 
			p.waitFor();
			
		   	p = Runtime.getRuntime().exec(new String[] { "/bin/sh", "-c", "./script.exe" });
		   	String line = null;
		   	BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
		   	while ( (line = br.readLine()) != null)
			   	ret += line + "\n";
		   	BufferedReader er = new BufferedReader(new InputStreamReader(p.getErrorStream()));
		   	while ( (line = er.readLine()) != null)
			   	ret += line + "\n";
		   	p.waitFor();
	   	} catch (IOException e1) {
		   	MW.printf("IOException starting process!");
	   	} catch (InterruptedException e2) {
		   	MW.printf("InterruptedException waiting for process!");
	   	}

		return ret;
   	}
}
