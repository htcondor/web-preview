#include "MWComm.h"
#include <unistd.h>
#include <assert.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/** setup() will parse the command line arguments, to get maseter
 *  port number and master hostname. */
MWComm::MWComm(MWprintf * out, int id, int port, char* host)
{
	mode = 0;
	file = NULL;
	MW = out;
	this->id = id;
	master_port = port;
	strcpy(master_host, host);
	MW->printf("master_port = %d", master_port);
	MW->printf("master_host = %s", master_host);

	/* init the recv_buf */
	which_buf = 1;
	head_pos = tail_pos = 0;
}

MWComm::MWComm(MWprintf *out, int id, char* fname)
{
	file = fopen(fname, "w");
	if (file != NULL) {
	   	mode = 1;
	   	MW = out;
	   	this->id = id;
	   	MW->printf("MWComm created, will append to file %s", fname);
   	} else {
	   	MW->printf("MWComm creation: can't open file %s to write", fname);
	   	exit(1);
   	}
}

/** helper function: to creat and bind a socket to a given port */
void 
MWComm::bind(int port)
{
	struct sockaddr_in my_addr;

	errno = 0;
	recv_soc = socket ( AF_INET, SOCK_STREAM, 0);
   	if ( recv_soc < 0 ) {
		MW->printf("Can't create socket, port = %d errno = %d", port, errno);
	   	exit(1);
	}

   	bzero(&my_addr, sizeof(my_addr));
   	my_addr.sin_family = AF_INET;
   	(my_addr.sin_addr).s_addr = htonl(INADDR_ANY);
   	my_addr.sin_port = htons(port);

	if( ::bind( recv_soc, (struct sockaddr *) &my_addr, sizeof(my_addr) ) < 0 ) {
	   	MW->printf("Couldn't bind the socket to the requied port: errno %d", errno);
	   	close(recv_soc);
	   	exit(1);
   	}
}

/** connect() will connect with the master for later communication. */
void 
MWComm::connect() 
{
   	struct sockaddr_in my_addr, serv_addr;

	errno = 0;
	send_soc = socket ( AF_INET, SOCK_STREAM, 0 );
   	if ( send_soc  < 0 ) {
		MW->printf("Can't create socket, errno = %d", errno);
	   	exit(1);
	}
   	bzero(&my_addr, sizeof(my_addr));
   	my_addr.sin_family = AF_INET;
   	(my_addr.sin_addr).s_addr = htonl(INADDR_ANY);
   	my_addr.sin_port = htons(0);

	if( ::bind( send_soc, (struct sockaddr *) &my_addr, sizeof(my_addr) ) < 0 ) {
	   	MW->printf("Couldn't bind the socket to the requied port: errno %d", errno);
	   	close(send_soc);
	   	exit(1);
   	}
	
	bzero(&serv_addr, sizeof(serv_addr));
   	serv_addr.sin_family = AF_INET;
	inet_pton(AF_INET, master_host, &serv_addr.sin_addr);
   	serv_addr.sin_port = htons(master_port);
	if ( ::connect ( send_soc, (struct sockaddr *)&serv_addr, sizeof(serv_addr) ) < 0 ) {
	   	MW->printf("Connect failed with the master: sock = %d  errno %d", send_soc, errno );
	   	exit(1);
   	} 

	MW->printf("Connected back with the master!");
}

/** file_send(tag, buffer) will append a message into a file, with strlen as header */
int MWComm::file_send(int tag, char* buffer)
{
	int ret, len, header_len;
	char header[24];

	sprintf(header, "%d %d ", tag, id);
	header_len = strlen(header);

	if (buffer != NULL) {
		len = strlen(buffer) + header_len;
		if (len > MWSOCKET_MAX_MSG_SIZE) {
			MW->printf("MWComm::send(), message length (%d) exceeds MAX (%d)",
					len, MWSOCKET_MAX_MSG_SIZE);
			MW->printf("MWComm::send(), will exit");
			exit(1);
		} else {
			ret = snprintf(send_buf, size_t(MWSOCKET_MAX_BUF_SIZE), "%d\n%d %d %s", len, tag, id, buffer);
		}
	} else {
		len = header_len;
		ret =  snprintf(send_buf, size_t(MWSOCKET_MAX_BUF_SIZE), "%d\n%d %d ", len, tag, id);
	}

	MW->printf("sending %s", send_buf);
	fprintf(file, "%s\n", send_buf);
	fflush(file);

	return ret;
}

/** sock_send(tag, buffer) will send out an array of characters to the master, 
 * 	with the strlen attached at the head */
int
MWComm::sock_send(int tag, char *buffer)
{
	int ret, len, header_len;
	char header[24];
	
	sprintf(header, "%d %d ", tag, id);
	header_len = strlen(header);

	if (buffer != NULL) {
	   	len = strlen(buffer) + header_len;
		if (len > MWSOCKET_MAX_MSG_SIZE) {
			MW->printf("MWComm::send(), message length (%d) exceeds MAX (%d)", 
				len, MWSOCKET_MAX_MSG_SIZE);
			MW->printf("MWComm::send(), will exit");
			exit(1);
		} else {
			ret = snprintf(send_buf, size_t(MWSOCKET_MAX_BUF_SIZE), "%d\n%d %d %s", len, tag, id, buffer);
		}
	} else {
		len = header_len;
		ret = snprintf(send_buf, size_t(MWSOCKET_MAX_BUF_SIZE), "%d\n%d %d ", len, tag, id);
	}

	len = strlen(send_buf);
	MW->printf("sending %s", send_buf);

	return sys_send(send_soc, send_buf, len, 0);
}

int
MWComm::sys_send(int s, void *buf, size_t len, int flags)
{
#ifdef linux
   	int ret;
#else
  #ifdef __svr4__
   	ssize_t ret;
  #else
   	int ret;
  #endif
#endif

	errno = 0;

	do {
#ifdef linux
	   	ret = ::send ( s, buf, len, flags );
#else
  #ifdef __svr4__
	   	ret = ::send ( s, (char *)buf, len, flags );
  #else
	   	ret = ::send ( s, buf, len, flags );
  #endif
#endif
   	} while ( errno == EINTR );

	if ( ret < (int)len ) {
	   	MW->printf ("Couldn't properly send to socket %d: ret = %d, errno = %d", s, ret, errno );
	   	return -1;
   	}

	return ret;
}

/** has_message() */
bool 
MWComm::has_message() 
{
	int i, pos = -1, ret = -1;

	/* first will non-blocking recv, just for header */
	if (has_header)
		return true;
	else {
		assert(head_pos == tail_pos);
		ret = n_recv(8, &(recv_buf[tail_pos]));
		if (ret == -1) {
			return false;
		} else { /* advance the tail_pos pointer */
			tail_pos += ret;
		}
	}

	/* then check if the header is in the buffer */
	for (i = head_pos; i<tail_pos; i++) {
		if (recv_buf[i] == '\n') {
			pos = i;
			break;
		}
	}

	if (pos == -1) {
		return false;
	} else {
		recv_buf[pos] = '\0';
		sscanf(&(recv_buf[head_pos]), "%d", &msg_length);
		assert(msg_length > 0);
		if (msg_length > MWSOCKET_MAX_MSG_SIZE) {
			MW->printf("MWComm got a header saying msg_length exceeds MWSOCKET_MAX_MSG_SIZE!");
			exit(1);
		}
		has_header = true;
		head_pos = pos + 1;
		recv_buf[pos] = '\n';
		return true;
	}
}

/** next_message() will use b_recv, assuming that after receving the header, 
 * the message body is coming soon. */
char*
MWComm::next_message()
{
	int diff = tail_pos - head_pos;

	/* first check if I need to switch buffer */
	if ( (which_buf == 1) && (head_pos > 8) ) {
		strncpy(&(recv_buf[MWSOCKET_MAX_BUF_SIZE]), &(recv_buf[head_pos]), diff);
		head_pos = MWSOCKET_MAX_BUF_SIZE;
		tail_pos = head_pos + diff;
		which_buf = 2;
	} else if ( (which_buf == 2) && (head_pos > MWSOCKET_MAX_BUF_SIZE + 8) ) {
		strncpy(recv_buf, &(recv_buf[head_pos]), diff);
		head_pos = 0;
		tail_pos = head_pos + diff;
		which_buf = 1;
	}
	
	/* then read msg_length characters */
	b_recv(msg_length, &(recv_buf[head_pos]));

	/* then will return a copy of the result, and change head_pos, tail_pos */
	strncpy(recv_ret, &(recv_buf[head_pos]), msg_length);
	head_pos += msg_length;
	tail_pos = head_pos;

	return recv_ret;
}

/** n_recv() will receive a message, if there is no message currently
 *  received. it will return -1, otherwise it will return the length
 *  of the received message. */
int 
MWComm::n_recv(int len, char *buffer) 
{
	int ret;
	errno = 0;
	
	do {
		/* set the MSG_DONTWAIT flag for non-blocking */
		ret = ::recv ( recv_soc, buffer, len, MSG_DONTWAIT);
   	} while ( errno == EINTR );
	
	if (errno == EAGAIN) {
		MW->printf("MWComm::n_recv() gets EAGAIN, will check again later");
		return -1;
	} else if ( (errno != 0) || (ret == -1) ) {
	   	MW->printf ( 10, "Couldn't properly do a recv from socket %d: \
			ret = %d, errno = %d\n", recv_soc, ret, errno );
	   	return -1;
   	} 

	return ret;
}

/** b_recv() will synchronously receive a message - wait until it
 *  get a message and then return. */
int 
MWComm::b_recv(int len, char *buffer) 
{
	int ret, accm = 0;
	errno = 0;
   	
	do {
		ret = ::recv ( recv_soc, buffer, len, 0);
		accm += ret;
	   	if ( (errno != 0) || (ret == -1) ) {
		   	MW->printf ( 10, "Couldn't properly do a recv from socket %d: \
			   	ret = %d, errno = %d\n", recv_soc, ret, errno );
	   	} 
   	} while ( ( errno == EINTR ) || (accm < len) );
	
	return accm;
}
