import java.io.*;
import java.net.*;

/** 
 * A <code>MWWorkerID</code> structure holds the information of a worker, 
 * which is used by the master to manage the workforce.
 */
public class MWWorkerID {
   	/** worker state: 0 - infinity */
   	public static final int W_SUBMITTED     = 0;
   	public static final int W_INITIALIZING  = 1;
   	public static final int W_IDLE          = 2;
   	public static final int W_SUSPENDED     = 3;
   	public static final int W_BUSY          = 4;
   	public static final int W_EXITED        = 5;

	public static String workerState[] = {
	   	"SUBMITTED",
	   	"INITIALIZING",
	   	"IDLE",
	   	"SUSPENDED",
	   	"BUSY",
	   	"EXITED"
   	};

	/* per object members */
	public int id1;  			/* worker id == vid*/
	public int cid;				/* cluster id for condor */
	public int pid;				/* process id inside a cluster */
	public int id2; 	 		/* unused so far */
	public int state;			/* MWUtil.W_??? */
	public String hostName;		/* machine name: v_cpu@host */
	public String OS;			/* LINUX, SUNOS, etc */
	public String arch;			/* INTEL, SPARC, etc */
	public int numCPU;			/* number of CPUs */
	public long memory;			/* i.e. 512 in MB */
	public long disk;			/* i.e. 2048 in MB */
	public long MIPS;			/* i.e. 512 MPIS */
	public long KFlops;			/* i.e. 500 KFlops */

	public MWTask task;			/* the task it's currently working on */
	public double benchmark; 	/* the job-specific benchmark */
	public double totalTime;	/* since started */
	public double upTime;		/* up time since started */
	public double cpuTime;		/* exec time since started */

	/* socket used to send message to the worker  */
	public Socket socket;
	public PrintWriter out;

	/* to maintain propoer worker id, we need to keep track all
	 * workers up and down, across all objects of this class */
	public static boolean [] vid = new boolean[MWUtil.MW_MAX_WORKER];

	/* return -1 if not match */
	int checkIntVal(String line, String name) {
		int pos = line.indexOf('=');
		if (pos == -1)
			return -1;

		String head = line.substring(0, pos-1).trim();
		String tail = line.substring(pos+1).trim();
		if (name.toUpperCase().compareTo(head.toUpperCase()) == 0) {
			return MWUtil.str2int(tail);
		} else return -1;
	}

	/* return -1 if not match */
	long checkLongVal(String line, String name) {
		int pos = line.indexOf('=');
		if (pos == -1)
			return -1;

		String head = line.substring(0, pos-1).trim();
		String tail = line.substring(pos+1).trim();
		if (name.toUpperCase().compareTo(head.toUpperCase()) == 0) {
			return MWUtil.str2long(tail);
		} else return -1;
	}

	/* return null of not match */
	String checkStringVal(String line, String name) {
		int pos = line.indexOf('=');
		if (pos == -1)
			return null;

		String head = line.substring(0, pos-1).trim();
		String tail = line.substring(pos+1).trim();
		if (name.toUpperCase().compareTo(head.toUpperCase()) == 0) {
			return tail;
		} else return null;
	}
	
	/** fill in the machine info, by parsing the condor_status result */
	public void getMachineInfo(MWUtil MW) {
		String line;
		BufferedReader br;

		/* OS, ARCH, Mem, Disk, MIPS, KFlops */
	   	try { 
			Process p = Runtime.getRuntime().exec(new String [] {
				   	MWUtil.CONDOR_DIR + "condor_status", "-l", hostName
		   	});
			MW.printf("Get machine info using condor_status");

		   	br = new BufferedReader(new InputStreamReader(p.getInputStream()));
		   	while ( (line = br.readLine()) != null) {
				/* parse the condor_status return */
				int val;
				long lv;
				String str;
				if ( (val = checkIntVal(line, "Cpus")) != -1)
					numCPU = val;
				else if ( (lv = checkLongVal(line, "MIPS")) != -1)
					MIPS = lv;
				else if ( (lv = checkLongVal(line, "KFlops")) != -1)
					KFlops = lv;
				else if ( (lv = checkLongVal(line, "memory")) != -1)
					memory = lv;
				else if ( (lv = checkLongVal(line, "disk")) != -1)
					disk = lv;
				else if ( (str = checkStringVal(line, "Arch")) != null)
					arch = str;
				else if ( (str = checkStringVal(line, "OpSys")) != null)
					OS = str;

			}
		   	p.waitFor();
		} catch (IOException e1) {
		   	MW.printf("IOException starting process!");
	   	} catch (InterruptedException e2) {
		   	MW.printf("InterruptedException waiting for process!");
	   	}
	}

	/* print itself */
	public String print() {
		String msg = new String("");
		
		msg += "\nID = " + id1;
		msg += "\nName = " + hostName;
		msg += "\nState = " + workerState[state];
		msg += "\nArch = " + arch;
		msg += "\nOS= " + OS;
		msg += "\n#CPU = " + numCPU;
		msg += "\nMemory = " + memory;
		msg += "\nDisk = " + disk;
		msg += "\nKFlops = " + KFlops;
		msg += "\n";

		return msg;
	}
	
	/** init the vid array */
	public static void initVID() {
		for (int i=0; i<MWUtil.MW_MAX_WORKER; i++)
			vid[i] = false;
	}
	
	/** @return -1 means can't find any free vid */
	public static int getVID() {
		for (int i=0; i<MWUtil.MW_MAX_WORKER; i++) {
			if (vid[i] == false) {
				vid[i] = true;
				return i;
			}
		}
		
		return -1;
	}

	/** set the vid[position] to '1' */
	public static void releaseVID(int position) {
		vid[position] = false;
	}
};

