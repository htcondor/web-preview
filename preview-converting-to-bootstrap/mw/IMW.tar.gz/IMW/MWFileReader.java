import java.util.*;
import java.io.*;
import java.net.*;

/** <code>MWFileReader</code> implements a Runnable object that can listen
 * to a given file, and append the new message into a message FIFO. It also 
 * provides message parsing functions to help separate message header from payload.
 */

public class MWFileReader implements Runnable 
{
	public BufferedReader reader;
	public PrintStream out;
	public List fifo;
	private MWUtil MW = null;
	private MWDriver driver;

	/** out and FIFO will be passed to MWRecv objects created later. 
	 *  @param s 	The ServerSocket that MWFileReader will listen to 
	 *  @param out  The writer to be used as stdout.
	 *  @param FIFO The message queue where the incoming message is enqueued */
	public MWFileReader (String fname, PrintStream out, List FIFO, MWDriver driver) {
		this.MW = new MWUtil(out);
		try {
			this.reader = new BufferedReader(new FileReader(fname));
		}  catch (FileNotFoundException e) {
			MW.printf("File not found: " + fname);
			System.exit(1);
		}
		this.fifo = FIFO;
		this.out = out;
		this.driver = driver;
		MW.printf("MWFileReader created, will read file " + fname);
   	}

	/** Keep accepting sockets and create new threads for them */
	public void run() {
		String line;
		boolean open = true;

		while (open) {
			line = MW.recv(reader);
			if (line != null) {
				MW.printf("MWFileReader: got " + line);
				appendMessage(line);
			}
			MW.waitFor(1000);
			// MW.printf("MWFileReader: waiting");
		}
   	}

	/** append onto a queue */
   	public void appendMessage(String msg) {
		synchronized (fifo) {
		   	fifo.add(msg);
		}
		// MW.printf("MWFileReader: append " + msg);
   	}
};
