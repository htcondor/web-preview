import java.util.*;
import java.io.*;
import java.net.*;

/** <code>MWAccept</code> implements (1) a Runnable object that can listen
 * to a given reader socket, to accept new connections. For each newly accepted
 * connection, it will call the newWorker() function implemented in MWDriver
 * for bookkeeping. 
 */

public class MWAccept implements Runnable 
{
	public ServerSocket socket;
	public PrintStream out;
	public List fifo;
	private MWUtil MW = null;
	private MWDriver driver;

	/** out and FIFO will be passed to MWRecv objects created later. 
	 *  @param s 	The ServerSocket that MWAccept will listen to 
	 *  @param out  The writer to be used as stdout.
	 *  @param FIFO The message queue where the incoming message is enqueued */
	public MWAccept (ServerSocket s, PrintStream out, List FIFO, MWDriver driver) {
		this.socket = s;
		this.fifo = FIFO;
		this.out = out;
		this.MW = new MWUtil(out);
		this.driver = driver;
		MW.printf("MWAccept created, will listen to socket \n " + s.toString());
   	}

	/** Keep accepting sockets and create new threads for them */
	public void run() {
		Socket s = null;
		String line;

		while (true) {
			MW.printf("Acceptor is accepting the next connection");
			try {
				s = socket.accept();
				MW.printf("Accepted a new connetion");
				line = MW.recv(new BufferedReader(new InputStreamReader(s.getInputStream())));
				driver.newWorker(s, line);
			} catch (IOException e) {
				MW.printf("IOException: Accept failed");
			}

			(new Thread(new MWRecv(this.MW, s, this.fifo))).start();
			
			MW.printf("Acceptor created a listener thread");
			MW.waitFor(100);
	   	}
   	}
};
