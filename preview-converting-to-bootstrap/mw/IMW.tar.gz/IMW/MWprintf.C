#include <stdarg.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include "MWprintf.h"

MWprintf::MWprintf(char *fname) 
{
	this->share = 0;
	this->level = 30;
	this->f = fopen(fname, "w");
}

MWprintf::MWprintf(FILE *out)
{
	this->share = 1;
	this->level = 30;
	this->f = out;
}


MWprintf::~MWprintf()
{
	if (share == 0)
		fclose(f);
}

int 
MWprintf::set_MWprintf_level(int level) {
	int old = this->level;
	
	if ( (level<0) || (level>99) ) 
		printf(10, "Bad arg \"%d\" in set_MWprintf_level().\n", level );
	else this->level = level;
	
	return old;
}

void 
MWprintf::printf (int level, char *fmt, ...) 
{
	static int printTime = 1;
	if ( level > this->level )
		return;

	if ( printTime ) {
		char *t;
		time_t ct = time(0);
		t = ctime( &ct );
		t[19] = '\0';
		fprintf(f, "%s ", &t[11] );
	}

	va_list ap;
	va_start(ap, fmt);
	vfprintf(f, fmt, ap);
	va_end(ap);
	fflush(f);
	fsync(fileno(f));

	printTime = ( fmt[strlen(fmt)-1] == '\n' ) ? 1 : 0;
}

void 
MWprintf::printf(char *fmt, ...) 
{
	char *t;
	time_t ct = time(0);
	t = ctime( &ct );
	t[19] = '\0';
	fprintf(f, "%s ", &t[11] );

	va_list ap;
	va_start(ap, fmt);
	vfprintf(f, fmt, ap);
	va_end(ap);
	fprintf(f, "\n");

	fflush(f);
	fsync(fileno(f));
}
