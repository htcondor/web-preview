import java.io.*;
import java.util.*;
import java.net.*;

/** <code>MWWorkerThread</code> implements a runnable class that 
 * will be started to execute a task, and store the result into the
 * task. It is thread so that MWWorker can listen to the master for
 * steering command (PAUSE/RESUME), and suspend and kill the thread
 * when it's instructed to do so. 
 *
 * The following virtual functions should be filled in: 
 *   <code>void execute_task(MWTask t);</code>
 *   <code>Object clone();</code>
 */

public class MWWorkerThread extends Thread
							implements Cloneable
{
	public MWWorker worker;
	public MWUtil MW;
	public MWTask task;

	public MWWorkerThread(MWWorker w) {
		this.worker = w;
		if (worker != null) {
			this.MW = w.MW;
		}
	}

	/** clone is used to create a new thread */
	public Object clone() {
		return new MWWorkerThread(this.worker);
	}

	/** run() will exeute the task */
	public void run() {
		/* Template implementation */
		execute_task(task);
		String str = task.pack_result(worker.id + " ");
		MW.sendMessage(worker.out, MWUtil.WD_RESULT, str);

	}
	
	/** The template implementation of execute_task(cmd, taskLine) */
   	public void execute_task(MWTask t) {
		return;
	}
}
