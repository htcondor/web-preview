import java.util.*;

/** 
 * <code>MyTaskCluster</code> is an implementation example for 
 * MWTaskCluster. It's mainly a result accumlator.  
 */
public class MyTaskCluster extends MWTaskCluster {
	public int result;
	
	public MyTaskCluster() {
		super();
		result = 0;
	}
};

