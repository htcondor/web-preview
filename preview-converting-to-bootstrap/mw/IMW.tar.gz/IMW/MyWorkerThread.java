import java.io.*;
import java.util.*;
import java.net.*;

/** <code>MyWorkerThread</code> implements a runnable class that 
 * will be started to execute a task, and store the result into the
 * task. In execute_task(), it sums up integers and put the result 
 * into the task's result field. 
 */

public class MyWorkerThread extends MWWorkerThread
							implements Cloneable 
{
	/** The constructor needs to create a new _MyTask_ */
	public MyWorkerThread(MWWorker w) {
		super(w);
		task = new MyTask();
	}
	
	/** clone is used to create a new thread, must provide a correctly
	 * typde MWTask object.  */
	public Object clone() {
		MyWorkerThread t = new MyWorkerThread(worker);
		t.task = this.task;
		t.task.MW = this.MW;
		return t;
	}

	/** The template implementation of execute_task(cmd, taskLine) */
   	public void execute_task(MWTask t) {
		MW.printf("MyWorkerThread executing task..");

		MyTask mt = (MyTask)t;
		mt.result = 0;
		for (int i=mt.range_lower; i<=mt.range_upper; i++)
			mt.result += i;
		return;
	}
}
