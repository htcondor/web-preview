import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.util.*;

/** <code>MWClient</code> is the frontend GUI for IMW. 
 */

/* the public interface: main() */
public class MWClient {
   	public static void main(String [] args) {
		JFrame frame = new MWGUI();	
	}
};

/* GUI: the main frame for displaying GUI components */
class MWGUI extends JFrame {
	/* model data */
	private static String config = new String("imw.config");
	public MWUtil MW = new MWUtil();
	public static int msgID;	/* unused so far */
	public static MWGUI instance;
	public ServerSocket server;
	public Socket client;
	public BufferedReader in;
	public PrintWriter out;
	private java.util.List messages;

	/* GUI components */
   	JFrame frame = new JFrame("Interactive MW on Condor");
	CmdPanel cmdPane;
	MsgPanel msgPane;
	TxtPanel txtPane;
	
	public MWGUI() {
   		messages = new LinkedList();;
	   	try {
		   	UIManager.setLookAndFeel(
				   	UIManager.getCrossPlatformLookAndFeelClassName());
	   	} catch (Exception e) {}
		
		instance = this;
		
		/* Setup the main window */
		GridBagLayout bag = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		frame.getContentPane().setLayout(bag);

	/* add components */
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.insets = new Insets(2,2,2,2);
	   	gbc.gridx = 0;
	   	gbc.weightx = 1.0;
	   	gbc.weighty = 1.0;

	/* Create the compoments inside the frame */
		cmdPane = new CmdPanel();
		msgPane = new MsgPanel();
		txtPane = new TxtPanel();
	
	   	gbc.gridy = 0;
	   	frame.getContentPane().add(Box.createVerticalStrut(5), gbc);
	   	gbc.gridy = 1;
		frame.getContentPane().add(cmdPane, gbc);
	   	gbc.gridy = 2;
		frame.getContentPane().add(msgPane, gbc);
	   	gbc.gridy = 3;
		frame.getContentPane().add(txtPane, gbc);

	/* add listeners */
		frame.pack();
		frame.setVisible(true);
	}

	/* start the master process */
	public int startMaster( String [] cmdline,  /* local command line */
							String port,		/* port number */
							String config_name) /* config file name */ 
	{
		if (cmdPane.started == false)  {
			/* start the master: currently will exec locally, later can 
			 * be submitted to condor as a scheduler job, or even uses
			 * Condor-G, etc */
			
			/* listen */
			MW.printf("MWClient will create and listen");
			listenSocket(MWUtil.str2int(port));

			/* "cmdline hostname port" */
			MW.printf("MWClient will spawn MWDriver");
			Process p;
		   	try {
			   	p = Runtime.getRuntime().exec(cmdline);
			} catch (IOException e) {
			   	MW.printf("IOException starting process!");
				for (int i=0; i<cmdline.length; i++)
					MW.printf("arg " + i + " = " + cmdline[i]);
				System.exit(1);
		   	}

			/* accept */
			MW.printf("MWClient will accept MWDriver");
			acceptSocket();

			/* wait until the master reply with a DC_CREATED */
			recvMessage(MWUtil.DC_CREATED);
			
			/* send config info to the master */
			sendConfig();
			recvMessage(MWUtil.DC_CONFIGED);

			/* update GUI */
			cmdPane.onMasterStarted();
			return 0;

		} else return -1;
	}

	/* called when the paused button is pressed */
	public int pauseMaster() {
		if ( (cmdPane.started == true) && (cmdPane.paused == false) ) {
			/* tell the master to pause and wait for new command */
			MW.sendMessage(out, MWUtil.CD_PAUSE, null);
			recvMessage(MWUtil.DC_PAUSED);
			MW.printf("Master paused!");
			cmdPane.onMasterPaused();
			return 0;
		} else return -1;
	}

	/* create a worker thread for socket communication */
	public void listenSocket(int port) {
		try { 
			server = new ServerSocket(port);
		} catch (IOException e) {
			MW.printf("IOException: can't listen on port " + port);
			System.exit(1);
		}
	}

	/* accept the client socket from MWDriver */
	public void acceptSocket() {
		MW.printf("MWClient will listen to socket \n " + server.toString());
		try { 
			client = server.accept();
		} catch (IOException e) {
			MW.printf("IOException: Accept failed");
			System.exit(1);
		}
		
		try {
			out = new PrintWriter(client.getOutputStream(), true);
		} catch (IOException e) {
			MW.printf("IOException: in/out creation failed");
			System.exit(1);
		}

		/* create a worker thread to listen incoming message */
		MWClientRecv socketListener = new MWClientRecv(MW, client, messages, txtPane.textArea);
		socketListener.addFilter(MWUtil.DC_CMD_RET);
		socketListener.addFilter(MWUtil.DC_UPDATE);
		Thread t = new Thread(socketListener);
		t.start();
	}
	
	/* send QUIT message to the master and wait it (and all workers) to quit */
	public void cleanAndQuit() {
	   	int ret = JOptionPane.showConfirmDialog(frame, 
				"Really want to quit?",
			   	"Quit confirmation", 
				JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE);

		if (ret == JOptionPane.YES_OPTION) {
			if (cmdPane.started) {
				/* XXX if the master is still there: stop it! */
				MW.sendMessage(out, MWUtil.CD_QUIT, null);
				recvMessage(MWUtil.DC_QUITED);
			}
			MW.printf("\nBye-bye, cruel world...");
		   	System.exit(0);
		}
	}

	/* read config file (fixed name "imw.config") and send it to the master */
	public void sendConfig() {
		String info = MWUtil.readFile(config);
		MW.sendMessage(out, MWUtil.CD_CONFIG, info);
		MW.printf("Sent config info: \n" + info);
	}

	/* called when the resume button is pressed */
	public int resumeMaster() {
		if ( (cmdPane.started == true) && (cmdPane.paused == true ) ) {
			/* tell the master to continue */
			MW.sendMessage(out, MWUtil.CD_RESUME, null);
			String ret = recvMessage(MWUtil.DC_RESUMED);
			cmdPane.onMasterResumed();
			MW.printf("Master resumed!");
			return 0;
		} else return -1;
	}

	/* called when the command button is pressed */
	public int newCommand(int cmd) {
		String ret;
		int opt;
		String cmdline = new String(""); 

		if (cmd == MWUtil.CMD_SCRIPT) { /* read the script file */
			/* FIXME: hard-coded script file name */
			cmdline = MW.readFile("script"); 
		} else if (cmd == MWUtil.CMD_ADDHOST) {
			cmdline = new String("5");
		} else if (cmd == MWUtil.CMD_HISTO) {
			cmdline = MW.readFile("histogram");
		}	
		
		if ( (cmdPane.started == true) && (cmdPane.paused == false) ) {
			MW.sendMessage(out, MWUtil.CD_COMMAND, cmd + " " + cmdline);
			ret = recvMessage(MWUtil.DC_CMD_ACK);
			cmdPane.onMasterCmdRet(ret);
			return 0;
		} else {
		   	opt = JOptionPane.showConfirmDialog(frame, 
					"Want to send the new command to paused master?",
				   	"Confirmation - this will resume master", 
					JOptionPane.YES_NO_OPTION,
				   	JOptionPane.QUESTION_MESSAGE);

			if (opt == JOptionPane.YES_OPTION) {
				cmdPane.onMasterResumed();
			   	MW.sendMessage(out, MWUtil.CD_COMMAND, cmd + " " + cmdline);
			   	ret = recvMessage(MWUtil.DC_CMD_ACK);
			   	cmdPane.onMasterCmdRet(ret);
			   	return 0;
			} else return -1;
		}
	}

	/* recv the next event, wait until get it or timeout */
	public String recvMessage(int event) {
		MWMessage line;
	    int type;

		line = MW.getMessage(messages, 0); 
		while (line == null) {
			MW.waitFor(100);
			line = MW.getMessage(messages, 0);	
		}
		
		type = MW.parseMessage(line);

		if (type == event) {
			return line.tail;
		} else {  /* should not happen! */
			MW.printf("ERROR: recving message of type " + event + " failed!");
			return null;
		}
	}
	
	/* clear the status text and post the new info */
	public void postStatus(String info) {
		msgPane.textArea.setText(info);
		msgPane.textArea.setCaretPosition(msgPane.textArea.getDocument().getLength());
	}

	/* append the new info into the status area */
	public void appendStatus(String info) {
		msgPane.textArea.append(info);
		msgPane.textArea.setCaretPosition(msgPane.textArea.getDocument().getLength());
	}

	/* clear the status text and post the new info */
	public void postResult(String info) {
		txtPane.textArea.setText(info);
		txtPane.textArea.setCaretPosition(txtPane.textArea.getDocument().getLength());
	}

	/* append the new info into the status area */
	public void appendResult(String info) {
		txtPane.textArea.append(info);
		txtPane.textArea.setCaretPosition(txtPane.textArea.getDocument().getLength());
	}

};

/* CmdPanel implements the Command pane of the main interface */
class CmdPanel extends JPanel 
			   implements ActionListener 
{
	/* utili object */
	public MWUtil MW = new MWUtil();
	
	/* current master state */
	public boolean started;
	public boolean paused;
	/* which command was chosen */
	public int command;		/* MWUtil.CMD_???? */
	
	/* possible numbers: 8997 8998 8999 */
	public String port;	
	final int MIN_PORT = 8997;
	final int MAX_PORT = 8999;

	/* GUI components */
	/* line 1 */
	JButton		masterButton 	= new JButton("Start Master");
	JLabel 		usingLabel		= new JLabel(" on port ");
	JComboBox	portCombo		= new JComboBox();	/* select port # */
	/* line 2 */
	JButton		cmdButton		= new JButton("Execute command:");
	JComboBox	cmdCombo		= new JComboBox();	/* which command */
	/* line 3 */
	JButton		pauseButton 	= new JButton("Pause");
	JButton		resumeButton	= new JButton("Resume");
	JButton		quitButton 		= new JButton("Quit");

	/* enabling constraints:
	 * 	started  -> masterButton disabled (can't start again)
	 * 	started  -> cmdButton/pause/resume enabled (can send command now)
	 * 	!started -> masterButton enabled (can start)
	 * 	paused   -> resumeButton enabled
	 * 	!paused  -> resumeButton disabled
	 */

	public CmdPanel() {
		int i;
		
		/* init model data */
		started = false;
		paused = false;
		command = MWUtil.CMD_FIRST;	/* default command: get status */
		port = (new Integer(MIN_PORT)).toString(); /* default port */

		/* init enable/disable */
		masterButton.setEnabled(true);
		masterButton.setActionCommand("start");
		masterButton.addActionListener(this);
		quitButton.setEnabled(true);
		quitButton.setActionCommand("quit");
		quitButton.addActionListener(this);
		cmdButton.setEnabled(false);
		cmdButton.setActionCommand("command");
		cmdButton.addActionListener(this);
		pauseButton.setEnabled(false);
		pauseButton.setActionCommand("pause");
		pauseButton.addActionListener(this);
		resumeButton.setEnabled(false);
		resumeButton.setActionCommand("resume");
		resumeButton.addActionListener(this);
	
		/* init command values */
		for (i=0; i<MWUtil.cmdMessages.length; i++)
			cmdCombo.addItem(MWUtil.cmdMessages[i]);

		for (i=MIN_PORT; i<=MAX_PORT; i++)
			portCombo.addItem((new Integer(i)).toString());

		/* set border */
		setBorder(new CompoundBorder(
					BorderFactory.createTitledBorder("Command Area:"),
					BorderFactory.createEmptyBorder(5, 5, 5, 5) ));

		/* set layout */
		GridBagLayout bag = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		setLayout(bag);

	/* add components */
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.insets = new Insets(2,2,2,2);
	   	gbc.weightx = 1.0;
	   	gbc.weighty = 1.0;

		/* line 1 */
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 1;
		add(masterButton, gbc);
		
		gbc.anchor = GridBagConstraints.CENTER;
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.gridwidth = 1;
		add(usingLabel, gbc);
		
		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.gridwidth = 1;
	   	add(portCombo, gbc);
	   	gbc.weightx = 0;

		/* line 2 */
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 1;
	   	gbc.gridwidth = 1;
		add(cmdButton, gbc);

		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 1;
		gbc.gridy = 1;
	   	gbc.gridwidth = 2;
		add(cmdCombo, gbc);
	   	gbc.weightx = 0;

		/* line 3 */
		gbc.fill = 0;

		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		add(pauseButton, gbc);
		
		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		add(resumeButton, gbc);
		
		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 2;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		add(quitButton, gbc);

	/* add event listeners */
		
		/* 2. combo changed listener */
	   	portCombo.addItemListener(new ItemListener() {
		   	public void itemStateChanged(ItemEvent event) {
				if (event.getStateChange() == ItemEvent.SELECTED) {
					port = (String)portCombo.getSelectedItem();
					MWGUI.instance.postStatus("Post number = " + port);
				}
		   	}
	   	});
	   	cmdCombo.addItemListener(new ItemListener() {
		   	public void itemStateChanged(ItemEvent event) {
				if (event.getStateChange() == ItemEvent.SELECTED) {
					String cmd_str = (String)cmdCombo.getSelectedItem();
					MWGUI.instance.postStatus("Command = " + cmd_str);
					for (int k=0; k<MWUtil.cmdMessages.length; k++) {
						if (cmd_str.equals(MWUtil.cmdMessages[k])) {
							command = MWUtil.CMD_FIRST + k;
						}
					}
				}
		   	}
	   	});

	}

	/* called when the master is started */
	public void onMasterStarted() {
		quitButton.setEnabled(true);
		cmdButton.setEnabled(true);
		pauseButton.setEnabled(true);
		resumeButton.setEnabled(false);
		portCombo.setEnabled(false);
		usingLabel.setEnabled(false);
		started = true;
	}

	/* called when the master is paused */
	public void onMasterPaused() {
		resumeButton.setEnabled(true);
		paused = true;
	}

	/* called when the master is resumed */
	public void onMasterResumed() {
		pauseButton.setEnabled(true);
		resumeButton.setEnabled(false);
		paused = false;
	}

	/* called when the master finished a command */
	public void onMasterCmdRet(String ret) {
		MWGUI.instance.appendResult(ret);
	}
	
	/* action handler */
	public void actionPerformed(ActionEvent e) {
		/* 1. start master */
		if (e.getActionCommand().equals("start")) {
			/* can be changed/configured */
			MWGUI.instance.postStatus("Starting master...");
			try {
				String hostname = InetAddress.getLocalHost().getHostName();
				masterButton.setEnabled(false);
				String cmdline [] = { "java", "-classpath", ".", "MWDriverExe", 
									  hostname, port};
				MWGUI.instance.startMaster(cmdline, port, null);
			} catch (UnknownHostException e1) {
				MW.printf("Can't figure out local host name.");
				System.exit(1);
			} catch (SecurityException e2) {
				MW.printf("Security problem when getting local host");
				System.exit(1);
			}
		} 
		/* 2. quit */
		else if (e.getActionCommand().equals("quit")) {
			MWGUI.instance.postStatus("Quiting...");
			MWGUI.instance.cleanAndQuit();
		}
		/* 3. pause */
		else if (e.getActionCommand().equals("pause")) {
			pauseButton.setEnabled(false);
			MWGUI.instance.postStatus("Pausing master...");
			MWGUI.instance.pauseMaster();
		}
		/* 4. resume */
		else if (e.getActionCommand().equals("resume")) {
			resumeButton.setEnabled(false);
			MWGUI.instance.postStatus("Resuming master...");
			MWGUI.instance.resumeMaster();
		}
		/* 5. command */
		else if (e.getActionCommand().equals("command")) {
			MWGUI.instance.postStatus("Send command to master...");
			MWGUI.instance.newCommand(command);
		}
	}
};

/* displaying the current status and command result */
class MsgPanel extends JPanel {
	/* GUI components */
	JTextArea	textArea	= new JTextArea(6, 48);
	JScrollPane textPane = new JScrollPane(textArea);

	public MsgPanel() {
		/* set border */
		setBorder(new CompoundBorder(
					BorderFactory.createTitledBorder("Status Area:"),
					BorderFactory.createEmptyBorder(5, 5, 5, 5) ));
		
		GridBagLayout bag = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		setLayout(bag);

	/* add components */
		gbc.fill = GridBagConstraints.BOTH;
		gbc.insets = new Insets(2,2,2,2);
		textArea.setEditable(false);
		textArea.setEditable(false);
		textArea.setLineWrap(true);
		textPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		add(textPane, gbc);
	}
};

class TxtPanel extends JPanel 
				implements ActionListener
{
	/* GUI components */
	JTextArea	textArea	= new JTextArea(25, 48);
	JScrollPane textPane = new JScrollPane(textArea);
	JButton		clrButton 	= new JButton("Clear");
	JButton		savButton	= new JButton("Save");
	
	public TxtPanel() {
		/* set border */
		setBorder(new CompoundBorder(
					BorderFactory.createTitledBorder("Result Area:"),
					BorderFactory.createEmptyBorder(5, 5, 5, 5) ));

		GridBagLayout bag = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		setLayout(bag);

	/* add components */
		gbc.fill = 0;
		gbc.insets = new Insets(2,2,2,2);
		gbc.gridwidth = 2;
		textArea.setEditable(false);
	   	textArea.setLineWrap(true);
	   	textArea.setWrapStyleWord(true);
		textPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		add(textPane, gbc);

		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		add(clrButton, gbc);
		
		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		add(savButton, gbc);

		/* init state */
		clrButton.setEnabled(true);
		clrButton.setActionCommand("clear");
		clrButton.addActionListener(this);
		savButton.setEnabled(true);
		savButton.setActionCommand("save");
		savButton.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("clear")) {
			textArea.setText("");
		} 
		else if (e.getActionCommand().equals("save")) {
			System.out.println(textArea.getText());
			MWUtil.overwriteFile("IMWClient.log", textArea.getText());
		}
	}
};
