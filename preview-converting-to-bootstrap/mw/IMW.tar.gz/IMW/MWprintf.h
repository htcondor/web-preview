#ifndef MWPRINTF_H
#define MWPRINTF_H

#include <stdio.h>

/** @name MWPrintf
  This functions control the amount of printed information
  in the MWDriver.  This is controlled through "levels", where
  a level of 0 is the most important and 99 is the least 
  important.  You can set the debug level to only print 
  levels n and below.
*/

class MWprintf 
{
private:
	int share;
	int level;
	FILE * f;
		
public:
	/** life cycle functions */
	MWprintf(char *fname);
	MWprintf(FILE *out);
	~MWprintf();

	/** Set the debug level for the MWprintf function.  The default
	 	upon startup is 50.
	 	@return The old level 
	 */
   	int set_MWprintf_level( int level );

   	/** A regular printf, with debugging level. */
   	void printf(int level, char *fmt, ...);

	/** shortcut to always print out */
	void printf(char *fmt, ...);

};

#endif
