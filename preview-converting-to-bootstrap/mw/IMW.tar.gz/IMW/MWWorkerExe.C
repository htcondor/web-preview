#include <stdio.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char** argv) 
{
	char cmdline[512];
   	char buffer[1024];
   	FILE *f;

	/* start Java */
	sprintf(cmdline, "/s/std/bin/java -classpath . MWWorkerExe %s %s %s %s",
		   	argv[1], argv[2], argv[3], argv[4]);

	if ( (f = popen(cmdline, "r")) != NULL ) {
	   	while (fgets(buffer, 1020, f)) {
		   	printf("%s", buffer);
	   	}

		pclose(f);
   	}

	return 0;
}

