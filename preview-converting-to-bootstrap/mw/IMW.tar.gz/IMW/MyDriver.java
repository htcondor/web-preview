import java.net.*;
import java.io.*;
import java.util.*;

/** 
 * <code>MyDriver</code> implements an example driver class by filling 
 * the following function implementations. 
 *
 * 		<code>int get_userinfo(String config_info)</code>
 *		<code>void set_name_value(name, value);</code>
 *		<code>void act_on_client_command(int cmd, String cmdline);</code>
 * 		<code>int act_on_completed_task(MWTask t)</code>
 *
 * This particular Driver class will parse the command line, and generate
 * new tasks, put onto the tasks list for MW to schedule. It also process
 * completed tasks, accumulate result, and remove the completed task cluster
 * from tasks. 
 */

public class MyDriver extends MWDriver
{
	/** virtual function  get_userinfo() will get config info from 
	 * the MWClient object, parse it and do initial configurations.
	 * @param info  The user-specified config info, to be parse by user. 
	 */
	public void get_userinfo(String info) {
		String name = null; 
		String value = null;
		List strList = parseConfigInfo(info);
		
		while (strList.isEmpty() == false) {
			/* remove the first two strings from the list: name and value */
			name = (String)strList.remove(0);
			value = (String)strList.remove(0);
			set_name_value(name, value);
		}

		MW.sendMessage(out_cli, MWUtil.DC_CONFIGED, null);
	}

	/** set_name_value(name, value) is called to interpret the configuration
	 * setting. The implementation compares name with known config variable names, 
	 * if they match, it will interpret the value string and set the value. 
	 */
	void set_name_value(String name, String value) {
		/* XXX put application specifc-config here */
		
		/* per-defined config information */
	   	if (name.toUpperCase().compareTo(MWUtil.configNames[MWUtil.CFG_DEBUG]) == 0) {
		   	DEBUG = MW.str2int(value);
		   	MW.printf("set " + MWUtil.configNames[MWUtil.CFG_DEBUG] + " = " + value);
		   	return;
	   	}

		if (name.toUpperCase().compareTo(MWUtil.configNames[MWUtil.CFG_EXEC]) == 0) {
			config_exec = value;
			MW.printf("set " + MWUtil.configNames[MWUtil.CFG_EXEC] + " = " + config_exec);
			return;
		}

		if (name.toUpperCase().compareTo(MWUtil.configNames[MWUtil.CFG_REQS]) == 0) {
			config_reqs = value.trim();
			MW.printf("set " + MWUtil.configNames[MWUtil.CFG_REQS] + " = " + config_reqs);
			return;
		}

		if (name.toUpperCase().compareTo(MWUtil.configNames[MWUtil.CFG_INIT_NUM]) == 0) {
			config_initNum = MW.str2int(value);
			targetNum = config_initNum;
			MW.printf("set " + MWUtil.configNames[MWUtil.CFG_INIT_NUM] + " = " + config_initNum);
			return;
		}

		if (name.toUpperCase().compareTo(MWUtil.configNames[MWUtil.CFG_TRANSFER]) == 0) {
			config_transfer = value.trim();
			MW.printf("set " + MWUtil.configNames[MWUtil.CFG_TRANSFER] + " = " + value);
			return;
		}
	}

	/** parse the new command, generate tasks, and return a group of tasks */
	public MWTaskCluster act_on_new_command(int cmd, String cmdline) {
		if (cmd == MWUtil.CMD_HISTO) {
			/** My implementation of CMD_HISTO - search for primary numbers  */
			MWMessage msg;
		   	msg = new MWMessage(cmdline);
			int step = MW.parseMessage(msg);
			msg = new MWMessage(msg.tail);
			int head = MW.parseMessage(msg);
			msg = new MWMessage(msg.tail);
			int tail = MW.parseMessage(msg);

			int total = tail - head + 1;
			int remain = total % step;
			int num = (remain == 0) ? (total / step) : (total / step + 1);

			MyTaskCluster tc = new MyTaskCluster();
			int left = total;
			for (int i=0; i<num; i++) {
				if (left >= step) {
					tc.addTask(new MyTask(MW, MWUtil.CMD_HISTO, head, head + step - 1));
					head += step;
					left -= step;
				} else {
					tc.addTask(new MyTask(MW, MWUtil.CMD_HISTO, head, head + left - 1));
				}
			}
			return tc;
		} else if (cmd == MWUtil.CMD_SCRIPT) {
			MW.printf("MyDriver doesn't support script execution yet.");
			return null;
		} else {
			MW.printf("MyDriver doesn't support command " + cmd + ".");
			return null;
		}
	}

	public int act_on_completed_task(MWTask t) {
		MyTask mt = (MyTask)t;
		MyTaskCluster tc = (MyTaskCluster)t.tc;
		MW.printf("MyDriver processing task result for task " + t.TCID + "." + t.ID);
	
		/* App-specifc: accumulate result */
		tc.result += mt.result;

		/* all done: send our Client a message! */
		if (tc.done == tc.size()) {
			MW.sendMessage(out_cli, MWUtil.DC_CMD_RET, "\nMWDriver finished a HISTOGRAM command:\n" 
					+ "result = " + tc.result);
			tasks.remove(tc);
		}

		return 0;
	}
};
