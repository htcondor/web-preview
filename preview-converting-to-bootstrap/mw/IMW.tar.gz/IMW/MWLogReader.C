#include "MWLogReader.h"

#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <user_log.c++.h>

/** Periodically check the log files and if there is new event, 
 *  send a message via socket to the master. 
 * 
 *  void main(argc, argv) {
 *  	setup(argc, argv);
 *  	while (true) {
 *  		// run forever until explicitly killed 
 *  		sleep(interval);
 *  		check_log_files();
 *  	}
 *  }
 * 
 */

MWLogReader::MWLogReader(char* fname) 
{
	/* init state */
	for (int i=0; i<MAX_WORKER; i++) {
		workers[i] = NULL;
	}

	/* open out file */
	MW = new MWprintf("LogReader.log");
	comm = new MWComm(MW, -1, fname);
	MW->printf("MWLogReader created, will write to file %s", fname);
}

void 
MWLogReader::add_worker(int id) 
{
	WorkerLog *w = new WorkerLog;
	w->event_no = 0;
	w->state = FREE;
	workers[id] = w;
}

/** setup() will parse the command line arguments, to get maseter
 *  port number and master hostname. It will also call connect_master
 *  to connect with the MWDriver object. */
void 
MWLogReader::setup(int argc, char** argv)
{
	/* cmdline: MWLogReader master_port master_host */
	if (argc >= 3) {
		master_port = atoi(argv[1]);
		strcpy(master_host, argv[2]);
		comm = new MWComm(MW, -1, master_port, master_host);
		comm->connect();
		comm->sock_send(WD_CREATED, NULL);
	} else exit(1);
}

/** get the current number of log files, by 'ls log.* | wc' */
int num_log_files() 
{
	FILE *f;
	int num = 0;
	char buf[_POSIX_PATH_MAX];
	char cmdline[_POSIX_PATH_MAX];
	
	sprintf(cmdline, "ls %s.* | wc", PREFIX);
	
	if ( (f = popen(cmdline, "r")) != NULL ) {
		if (fscanf(f, "%s", buf) >= 0) {
			pclose(f);
			num = atoi(buf);
		}
	}
	
	return num;
}

/** check_log_files() will check for all log.id files, for new events. 
 *  If there are new events, it will send a message back to the maseter */
void 
MWLogReader::check_log_files()
{
    char fname[_POSIX_PATH_MAX];
    int i, num_files = num_log_files();

    for (i=0; i<num_files; i++) {
		sprintf(fname, "%s.%d", PREFIX, i );
	   	// MW->printf("will check acess of %s", fname);
		
	   	if ( access ( fname, R_OK ) != 0 ) {
		   	workers[i]->state = IDLE;
		   	workers[i]->event_no = 0;
	   		MW->printf("Couldn't access %s: errno %d", fname, errno);
		   	continue;
	   	} else if (workers[i] == NULL) {
			/* if found new log files, add new worker */
		   	add_worker(i);
	   	}

		/* skip NULL workers */
		if ( workers[i] == NULL) continue;

		ReadUserLog log;
	   	ULogEvent *event;
	   	ULogEventOutcome outcome;
		log.initialize ( fname );
		
		/* count events to skip old ones */
	   	int num_event = 0;
		char msg[12];
		sprintf(msg, "%d", i);
		
		outcome = log.readEvent( event );
	   	for ( ;  outcome == ULOG_OK ; outcome = log.readEvent( event ) ) {
		   	num_event++;
		   	if ( workers[i]->event_no >= num_event ) {
			   	delete event;
			   	continue;
			}

			switch (event->eventNumber) {
				case ULOG_EXECUTABLE_ERROR:
				case ULOG_JOB_TERMINATED:
				case ULOG_JOB_ABORTED:
				// case ULOG_JOB_EVICTED:
					MW->printf("worker %d terminated", i);
					workers[i]->state = KILLED;
					comm->file_send(ED_TERMINATED, msg);
					break;
					
				case ULOG_SHADOW_EXCEPTION:
					MW->printf("worker %d shadow exception", i);
					workers[i]->state = TRANSIT;
					comm->file_send(ED_SHADOWE, msg);
					break;
					
				case ULOG_CHECKPOINTED:
					MW->printf("worker checkpointed? How can this happen in Vanilla universe?");
					break;
					
				case ULOG_SUBMIT:
					MW->printf("worker %d got submitted", i);
					workers[i]->state = SUBMITTED;
					break;
					
				case ULOG_EXECUTE:
					MW->printf("worker %d executing", i);
					comm->file_send(ED_EXECUTE, NULL);
				    break;

				default:
				    break;
		   	} 
			
			/* inc event_no */
			workers[i]->event_no++;
			delete event;
	   	}
   	}
}

/** the main function */
int main(int argc, char** argv) {
   	MWLogReader * reader = new MWLogReader(argv[1]);

   	/* reader->setup(argc, argv); */
   	while (true) {
	   	reader->check_log_files();
	   	sleep(CHECK_LOG_INTERVAL);
   	}

	return 0;
}

