#ifndef _MW_LOGREADER
#define _MW_LOGREADER

#include "MWComm.h"
#include "MWprintf.h"

#define MAX_WORKER		1024
#define PREFIX			"log_file"
#define WD_CREATED		401
#define ED_SUBMITTED	501
#define ED_EXECUTE 		502
#define ED_SUSPEND 		503
#define ED_RESUMED 		504
#define ED_SHADOWE 		504
#define ED_TERMINATED	506
#define CHECK_LOG_INTERVAL	2	

enum WorkerState {
   	FREE,
   	SUBMITTED,
   	EXECUTE,   /* Started executing for the first time */
  	RUNNING,
   	KILLED,
   	SUSPENDED,
   	RESUMED,
   	IDLE,
   	TRANSIT
};

typedef struct WorkerLog_t {
	int event_no;
	enum WorkerState state;
} WorkerLog;

class MWLogReader 
{
private:
	MWprintf* MW;
	MWComm* comm;
   	char my_host[128];
   	int  master_port;
   	char master_host[128];

	/** state information for each worker */
	WorkerLog* workers[MAX_WORKER];

public:
	MWLogReader(char* fname);
	void add_worker(int id);
	void setup(int argc, char** argc);
	void check_log_files();
};

#endif
