import java.net.*;
import java.io.*;
import java.util.*;

/** MWDriverExe is the wrapper around MWDriver 
 */
public class MWDriverExe 
{
/* the main entry point */
   	public static void main(String [] args) 
	{
		/* Please change MyDriver into your application driver class name */
		MyDriver driver = new MyDriver();
		driver.setup(args);
		driver.mainloop();

		/* won't reach here since we will exit in mainloop */
	}
}

