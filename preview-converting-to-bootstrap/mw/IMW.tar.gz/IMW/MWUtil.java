import java.util.*;
import java.io.*;

/** class <code>MWUtil</code> defines the MW-wide constants (i.e. event types, 
 * GUI command string, etc), and implements the command utility functions. 
 */
public class MWUtil
{
  /* constant definitions */
	public static final int MW_MAX_WORKER  = 1024;
	public static final int MW_WORKER_PORT 	= 9000;
	public static final int MW_READER_PORT 	= 9001;
	public static final String CONDOR_DIR  = new String("/unsup/condor/bin/");
	public static final String MW_LOG_NAME = new String("LogReader.out");

	/** MW-wide messages: 1 - 100*/
	public static final int MW_UNKNOWN  = 1;
	public static final int MW_TEXT	 	= 2;
	
	/** event from MWClient to MWDriver: 101 - 200  */
	public static final int CD_PAUSE   	= 101;
	public static final int CD_RESUME  	= 102;
	public static final int CD_QUIT    	= 103;
	public static final int CD_COMMAND 	= 104;
	public static final int CD_CONFIG  	= 105;

	/** event from MWDriver to MWClient: 201 - 300 */
	public static final int DC_CREATED 	= 201;
	public static final int DC_PAUSED  	= 202;
	public static final int DC_RESUMED 	= 203;
	public static final int DC_QUITED  	= 204;
	public static final int DC_CMD_ACK 	= 205;  
	public static final int DC_CMD_RET 	= 206;  
	public static final int DC_CONFIGED = 207;  
	public static final int DC_UPDATE   = 208;  

	/** event from MWDriver to MWWorker: 301 - 400 */
	public static final int DW_WORK		= 301;
	public static final int DW_PAUSE	= 302;
	public static final int DW_RESUME	= 303;
	public static final int DW_QUIT 	= 304;
	public static final int DW_RESTART 	= 305;
	
	/** event from MWWorker to MWDriver: 401 - 500  */
	public static final int WD_CREATED 	= 401;
	public static final int WD_RESULT  	= 402;
	public static final int WD_UPDATE  	= 403;
	public static final int WD_PAUSED   = 404;
	public static final int WD_RESUMED  = 405;

	/** event from environment (Condor) to MWDriver: 501 - 600 */
	public static final int ED_SUBMITTED  = 501;
	public static final int ED_EXECUTE 	= 502;
	public static final int ED_SUSPEND 	= 503;
	public static final int ED_RESUMED 	= 504;
	public static final int ED_SHADOWE 	= 505;
	public static final int ED_TERMINATED = 506;

	/** command index: 1 - infinity */
	public static final int CMD_FIRST   = 1;
	public static final int CMD_STATUS  = 1;
	public static final int CMD_SCRIPT  = 2;
	public static final int CMD_HISTO   = 3;
	public static final int CMD_ADDHOST = 4;

	/** GUI command strings: the order of command line message 
	 * must be consistent with their indices */
	public static String cmdMessages[] = {
		"1. Status",
		"2. Script", 
		"3. Histogram", 
		"4. +5 workers"
	};

	/** Configuration names and indices, MUST match */
	public static final int CFG_FIRST 	= 0;
	public static final int CFG_EXEC 	= 0;
	public static final int CFG_REQS 	= 1;
	public static final int CFG_INIT_NUM = 2;
	public static final int CFG_TRANSFER = 3;
	public static final int CFG_DEBUG 	= 4;

	public static String configNames[] = {
		"EXECUTABLE",
		"REQUIREMENTS",
		"INIT_NUM",
		"TRANSFER_INPUT_FILES",
		"DEBUG"
	};

  /* commonly used functions */
	/** read the content of a file into a returned String */
   	public static String readFile(String filename) {
		int nch;
	   	InputStreamReader reader;
	   	String s = new String();
	   	char[] buf = new char[1024];

		try {
		   	reader = new FileReader(new File(filename));
			while ((nch = reader.read(buf, 0, buf.length)) != -1) {
			   	s = s + new String(buf, 0, nch);
			}
	   	} catch (IOException e) {
		   	s = "Could not load file: " + filename;
	   	}
	   	return s;
   	}

	/** write/overwrite the content of a String into a file */
	public static void overwriteFile(String name, String text) {
		MWUtil MW = new MWUtil();
		
		PrintWriter writer;
		try {
			writer = new PrintWriter(new FileOutputStream(name));
			writer.print(text);
			writer.close();
		} catch (FileNotFoundException e1) {
			MW.printf("FileNotFoundException when writing to a file");
		} catch (IOException e2) {
			MW.printf("IOException when writeing to a file");
		}
	}

	/** convert a String into an int */
	public static int str2int(String str) {
		return Integer.decode(str).intValue();
	}

	/** convert a String into a long value */
	public static long str2long(String str) {
		return Long.decode(str).longValue();
	}

	/** convert a String into a double */
	public static double str2dbl(String str) {
		return Double.parseDouble(str);
	}

	/** return the corrent time value as a long integer */
   	public static long cur_time() {
	   	Calendar c = Calendar.getInstance();
	   	return c.get(Calendar.HOUR_OF_DAY) * 3600
		   	+ c.get(Calendar.MINUTE) * 60
		   	+ c.get(Calendar.SECOND);
   	}

	/** Remove the head message from a queue, if the queue is empty, then 
	 * wait until the head message is available. 
	 * 
	 * @param FIFO  The synchronized list from where to dequeue message. 
	 * @param timeout A timeout limit denoting for how long to wait (in msec), only 
	 * 				   positive value will be used as time-out limit. 
	 * @return A MWMessage constructed from the String message, or null if timeout.
	 */
	public MWMessage getMessage(List FIFO, long timeout) {
		MWMessage line = null;
		long start = MWUtil.cur_time();
	   	boolean more = true;
		int len;

	   	while (more) {
			synchronized (FIFO) { len = FIFO.size(); }
			if (len == 0) {
			   	waitFor(100);
			   	// printf("get message waiting");	

			   	if ( ( MWUtil.cur_time() - start >= timeout ) ) {
				   	more = false;
			   	}
		   	} else {
			   	// printf("removing");	
				synchronized (FIFO) { line = new MWMessage((String)FIFO.remove(0)); }
			}
	   	}

		return line;
	}

	/** parse a message, separate header and trailer into different 
	 * fields of the MWMessage object, return the int value of the
	 * header string. */
   	public int parseMessage(MWMessage line) {
	   	StringTokenizer st = new StringTokenizer(line.msg);
	   	line.head = st.nextToken();
	   	line.tail = line.msg.substring(line.head.length()+1);
	   	line.type = MWUtil.str2int(line.head.trim());
	   	return line.type;
   	}

 /* per object functions */
	public PrintStream out;

	public MWUtil() {
		this.out = null;
	}

	public MWUtil(PrintStream out) {
		if (out != null) {
			this.out = out;
		}
	}
	
	/** send a String via a writer, adding checksum - strlen as header */
	public void send(PrintWriter out, String str) {
		MWUtil MW = new MWUtil();
		String ret = str.length() + "\n" + str;
		out.print(ret);
		out.flush();
		// MW.printf("send() just sent: " + str);
	}

	/** send a message through the given out channel */
	public void sendMessage(PrintWriter out, int event, String message) {
		MWUtil MW = new MWUtil();
	   	// MW.printf("sendMessage: " + event + " " + message);
	   	if (message == null)
		   	MW.send(out, event + " ");
	   	else MW.send(out, event + " " + message);
	}
	
	/** recv a String via a reader, removing the head - strlen */
	public String recv(BufferedReader in) {
		MWUtil MW = new MWUtil();
		String buffer = null; 
		int len;

		try {
			buffer = in.readLine();
			if ((buffer == null) || (buffer.length() == 0))
				return null;

			// MW.printf("MWUtil::recv() got |" + buffer + "|");
		   	len = str2int(buffer);
		   	if (len > 0) {
			   	char cbuf[] = new char[len];
			   	in.read(cbuf, 0, len);
				String ret = new String(cbuf);
			   	return ret;
		   	} else {
			   	MW.printf("Line length <= 0?");
		   	}
	   	} catch (IOException e) {
			MW.printf("IOException when recv");
		}

		return null;
	}
  
	/** level of details to be printed: the smaller the number, the less to be printed  */
   	private int printf_level = 50;

	/** set the level of printf */
	public int set_printf_level(int level) {
	   	if ( (level<0) || (level>99) )
		   	printf(10, "Bad argument \"" + level + "\" for set_printf_level.\n");
	   	else printf_level = level;
	   	return printf_level;
   	}

	/** to print some information into stdout, by adding current time 
	 * at the beginning of each message. 
	 * @param level  The importance level of this message, the message will be printed 
	 * 				  only if it is less than or equal to printf_level.
	 * @param s 	  The message to be printed */
	public void printf(int level, String s) {
		PrintStream fout = out; 
		if (fout == null)
			fout = System.out;

	   	if (level <= printf_level) {
		   	Calendar c = Calendar.getInstance();
		   	fout.println(c.get(Calendar.HOUR_OF_DAY)
				   	+ ":" + c.get(Calendar.MINUTE)
				   	+ ":" + c.get(Calendar.SECOND)
				   	+ " " + s);
			fout.flush();
	   	}
   	}

	/** the shortcut of printf(level, message), will always print message */
	public void printf(String s) {
		printf(printf_level, s);
	}

	public void waitFor(int limit) {
	   	try {
		   	synchronized (this) {
			   	wait(limit);
		   	}
	   	} catch (InterruptedException e) {
			printf("InterruptedException");
	   	}
	}
};
	
