import java.net.*;
import java.io.*;
import java.util.*;

/** 
 * <code>MWDriver</code> defines the interface of an abstraction of 
 * master object: a group of functions to be extended by a user-defined
 * master object. The important APIs to be implemented by application 
 * programmers are: 
 *
 * 		<code>int get_userinfo(String config_info)</code>
 *		<code>void set_name_value(name, value);</code>
 *		<code>void act_on_new_command(int cmd, String cmdline);</code>
 * 		<code>int act_on_completed_task(MWTask t)</code>
 * 		
 * All the virtual functions need to be overloaded is not named in Java 
 * style, but in do_sth(params) style. 
 *
 * A master also implements the default behavior to communicate with 
 * the MWClient and MWWorker objects, to manage the workerforce and tasks, 
 * and to handle pool dynamic changes.  It is created by a user by a GUI
 * command of MWClient, it then connects with MWClient object via socket, 
 * listening for new commands from the user, executing commands, and 
 * return results. Usuaully the commands will be actually carried out by
 * a group of workers, created by the master through the underlying 
 * resource manager (i.e. Condor). These workers will connect to the master
 * via sockets (or other communication methods), receive smaller piece of 
 * a task (sliced by the big command that MWDriver received from the user), 
 * execute it and return result to the master. The master also listens to 
 * the workers to collect results. 
 * 
 * TODO: 
 *  -- not sure whether Vanilla jobs' output can be printed immediately. 
 * 	-- start doing a C++ version.
 *
 * 	@author Jichuan Chang  chang@cs.wisc.edu
 *
 */
public class MWDriver 
{
	/** Config information: refer to MWUtil.java for detailed definition
	 *  of configuration names and indices. Here I assume that only one 
	 *  class of hosts are used (support for multiple arch_class can be 
	 *  added later without too much hacking).
	 *  
	 *  ARCH (target worker host architecture) = INTEL, SPARC, etc
	 *  OPSYS (target worker host OS) = LINUX, SUNOS2, etc
	 *  INIT_NUM (of workers) = how many worker to be collected first
	 *  TRANSFER_INPUT_FILES = which (class) files to transfer
	 *
	 *  <!add user-defined config information here!>
	 */
	int config_initNum;
	String config_transfer;
	String config_exec;
	String config_reqs;

	boolean paused;

	/** Debug process: a local worker */
	Process debug;
	int DEBUG = 0;
	
/* shared message queue */
	static int submitNo;
	/** MW is an helper object with printf, recv/send functions */
	MWUtil MW; 
	/** local host name */
	String hostname = null; 
	/** logReader is a process that reads condor user log and send events */
	Process logReader;
	/** FIFO_client is the queue for messages coming from MWClient */
	List FIFO_client = null; 
	/** FIFO_workers is the queue for messages coming from MWWorker's */
	List FIFO_workers = null;
	/** fout will contain the output for MWDriver */
	PrintStream fout = null; 

/* data structure for client-side messages */
	/** socket_cli, out_cli, in_cli are the data structures used to communicate with MWClient */
   	Socket socket_cli = null;
   	PrintWriter out_cli = null;
   	BufferedReader in_cli = null;

/* data structure for worker-side messages */
	/** The current group of tasks */
	LinkedList tasks;

	/** server socket to accept worker sockets */
	ServerSocket server = null;
	/** workers is the worker queue containing the MWWorkerID objects */
	List workers;
	/** the target number of workers we want to have */
	int targetNum;
	/** the number workers been requested, can be different from the current number of workers
	 *  The number will be increased when after submit, and decreased when a worker is gone. */
	int requestNum;
	
	/* constructor */
	public MWDriver() {
		/* create new FIFO */
		FIFO_client = new LinkedList();
		FIFO_workers = new LinkedList();
		/* reset stdout, stderr */
		try { 
			fout = new PrintStream(new FileOutputStream("Driver.out"));
		} catch (FileNotFoundException e) {
			System.exit(1);
		}
		System.setOut(fout);
		System.setErr(fout);

		MW = new MWUtil(fout);
		MWWorkerID.initVID();
		workers = new LinkedList();
		tasks = new LinkedList();
		targetNum = requestNum = 0;
		submitNo = 0;

		paused = false;
		debug = null;
	}
	
/* the main entry point */
   	public static void main(String [] args) {
		MWDriver driver = new MWDriver();
		driver.setup(args);
		driver.mainloop();

		/* won't reach here since we will exit in mainloop */
	}

	/** called when the master is just started */
	public void setup(String [] args) {
	   	MW.printf("MWDriver started");;
		
		try {
			hostname = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e1) {
			MW.printf("Can't figure out local host name.");
	   	} catch (SecurityException e2) {
		   	MW.printf("Security problem when getting local host");
	   	}

		/* connect back to the client */
		try { 
			socket_cli = new Socket(args[0], MW.str2int(args[1]));
			out_cli = new PrintWriter(socket_cli.getOutputStream(), true);
		} catch (UnknownHostException e) {
		   	MW.printf("Unknown host: " + args[0]);
		   	System.exit(1);
	   	} catch  (IOException e) {
		   	MW.printf("No I/O: " + args[0] + " " + args[1]);
		   	System.exit(1);
	   	}
		
		/* tell the client side that the master is started */
		MW.printf("MWDriver sending MWUtil.DC_CREATED");
		MW.sendMessage(out_cli, MWUtil.DC_CREATED, null);

		/* create a listener to get messages from the client */
	   	MW.printf("MWDriver creating MWRecv for MWClient");
	   	MWRecv socketListener = new MWRecv(MW, socket_cli, FIFO_client);
	   	Thread t = new Thread(socketListener);
	   	t.start();
	}
	
	/** virtual function  get_userinfo() will get config info from 
	 * the MWClient object, parse it and do initial configurations.
	 * @param info  The user-specified config info, to be parse by user. 
	 */
	public void get_userinfo(String info) {
		String name = null; 
		String value = null;
		List strList = parseConfigInfo(info);
		
		while (strList.isEmpty() == false) {
			/* remove the first two strings from the list: name and value */
			name = (String)strList.remove(0);
			value = (String)strList.remove(0);
			set_name_value(name, value);
		}

		MW.sendMessage(out_cli, MWUtil.DC_CONFIGED, null);
	}

	/** parse a cofiguration message: it first separates a configuration into 
	 * many lines, each line representing a <code>name = value </code> pair,
	 * and removes comment lines (starting with '#'). Then each pair is added
	 * into a List with elements of String pairs. The list is returned, and
	 * interpreted by the caller. If a line's format is incorretn, skip it. */
	public List parseConfigInfo(String info) {
		String line = null, name = null, value = null;
		List strList = new LinkedList();
		int middle;
		
		BufferedReader reader = new BufferedReader(new StringReader(info));
		try {
		   	while ( (line = reader.readLine()) != null ) {
			   	/* skip comments and empty lines */
				if ( (line.length() == 0) || (line.charAt(0) == '#') )
				   	continue;

				middle = line.indexOf('=');
			   	if (middle == -1) {
				   	/* skip badly formatted lines */
				   	continue;
			   	} else {
				   	name = line.substring(0, middle-1).trim();
				   	value = line.substring(middle+1).trim();
				   	strList.add(name);
				   	strList.add(value);
				   	// MW.printf("name = " + name + " value = " + value);
			   	}
		   	}
		} catch (IOException e) {
			MW.printf("IOException when reading config information");
		}
		
		return strList;
	}

	/** set_name_value(name, value) is called to interpret the configuration
	 * setting. The implementation compares name with known config variable names, 
	 * if they match, it will interpret the value string and set the value. */
	void set_name_value(String name, String value) {
		/* per-defined config information */
		if (name.toUpperCase().compareTo(MWUtil.configNames[MWUtil.CFG_EXEC]) == 0) {
			config_exec = value;
			MW.printf("set " + MWUtil.configNames[MWUtil.CFG_EXEC] + " = " + config_exec);
			return;
		}

		if (name.toUpperCase().compareTo(MWUtil.configNames[MWUtil.CFG_REQS]) == 0) {
			config_reqs = value.trim();
			MW.printf("set " + MWUtil.configNames[MWUtil.CFG_REQS] + " = " + config_reqs);
			return;
		}

		if (name.toUpperCase().compareTo(MWUtil.configNames[MWUtil.CFG_INIT_NUM]) == 0) {
			config_initNum = MW.str2int(value);
			targetNum = config_initNum;
			MW.printf("set " + MWUtil.configNames[MWUtil.CFG_INIT_NUM] + " = " + config_initNum);
			return;
		}

		if (name.toUpperCase().compareTo(MWUtil.configNames[MWUtil.CFG_TRANSFER]) == 0) {
			config_transfer = value.trim();
			MW.printf("set " + MWUtil.configNames[MWUtil.CFG_TRANSFER] + " = " + value);
			return;
		}

		if (name.toUpperCase().compareTo(MWUtil.configNames[MWUtil.CFG_DEBUG]) == 0) {
			DEBUG = MW.str2int(value);
			MW.printf("set " + MWUtil.configNames[MWUtil.CFG_DEBUG] + " = " + value);
			return;
		}
		/* XXX put application specifc-config here */
	}

	/* the master main loop for recving/handling messages */
	public void mainloop() {
		int type, cmdType;
		MWMessage line;

		MW.printf("MWDriver entered mainloop");
		
		/* I dicide to give client message priority */
		while (true) {
			if (FIFO_client.isEmpty() == false) {
				line = MW.getMessage(FIFO_client, 0); 
				type = MW.parseMessage(line);

				/* the BIG switch */
			   	switch (type) {
					case MWUtil.CD_CONFIG: 
						get_userinfo(line.tail);
						startLogReader();
						addHost();
						break;
						
				   	case MWUtil.CD_PAUSE:
					   	onPause();
					   	break;
						
				   	case MWUtil.CD_RESUME:
					   	onResume();
					   	break;
						
				   	case MWUtil.CD_QUIT:
					   	onQuit();
					   	break;
						
					case MWUtil.CD_COMMAND:
						line.msg = line.tail;
						line.tail = null;
						cmdType = MW.parseMessage(line);
						
						switch (cmdType) {
							/* XXX App-writer, add your command type here */
						   	case MWUtil.CMD_SCRIPT:
						   	case MWUtil.CMD_HISTO:
								MW.printf("MWDriver got new client command " + cmdType);
								MWTaskCluster tc = act_on_new_command(cmdType, line.tail);
								if (tc != null) {
									tasks.add(tc);
									assignTasks();	/* only assign tasks for new commands */
								}
								MW.sendMessage(out_cli, MWUtil.DC_CMD_ACK, "\n\nMWDriver acted on new command\n");
							   	break;
							
							/* ask for more workers */
						   	case MWUtil.CMD_ADDHOST:
							   	onAddHost(line.tail);
							   	break;
								
							/* get Driver status */
						   	case MWUtil.CMD_STATUS:
							   	onStatus(line.tail);
							   	break;

							default:
								MW.printf("Unknown command from client " + cmdType);
						}
						break;
						
				   	default:
						MW.printf("Unknown message from client " + type);
			   	}
		   	} else if (FIFO_workers.isEmpty() == false) {
				MW.printf("fetching message from FIFO_worker");
			   	line = MW.getMessage(FIFO_workers, 0); 
			   	type = MW.parseMessage(line);
				int wid;
				MWMessage msg;
				switch (type) {
					/* XXX put other worker message here */
					case MWUtil.WD_CREATED: 
						MW.printf("Worker started, but this should have been processed!");
						break;
						
					case MWUtil.WD_RESULT:
						MW.printf("Got RESULT from a worker! {" + line.tail + "}");
						
						/* unpack the task result */
						msg = new MWMessage(line.tail);
						wid = MW.parseMessage(msg);
						
						String result = msg.tail;
						msg = new MWMessage(msg.tail);
						int ret = MW.parseMessage(msg);
						msg = new MWMessage(msg.tail);
						int tcid = MW.parseMessage(msg);
						msg = new MWMessage(msg.tail);
						int tid = MW.parseMessage(msg);
						
						MWWorkerID w = findWorker(wid);
						if (w != null) {
							w.state = w.W_IDLE;
						} else {
							MW.printf("Worker " + wid + " returned task " + tcid + "." + tid 
									+ ", but I can't find the WORKER in our worker queue.");
							break;
						}

						MWTask t = findTask(tcid, tid);
						if (t != null) {
							t.unpack_result(result);
							act_on_completed_task(t);
						} else {
							MW.printf("Worker " + wid + " returned task " + tcid + "." + tid 
									+ ", but I can't find the TASK in our task queue.");
						}
						/* assign the next task to the worker */
						assignTaskTo(w);
						break;

					case MWUtil.WD_UPDATE:
						msg = new MWMessage(line.tail);
						wid = MW.parseMessage(msg);
						MW.printf("Got UPDATE from a worker " + wid);
						break;

					case MWUtil.WD_PAUSED:
						msg = new MWMessage(line.tail);
						wid = MW.parseMessage(msg);
						MW.printf("Got PAUSED from a worker " + wid);
						break;

					case MWUtil.WD_RESUMED:
						msg = new MWMessage(line.tail);
						wid = MW.parseMessage(msg);
						MW.printf("Got RESUMED from a worker" + wid);
						break;

					/* LogReader messages here */
					case MWUtil.ED_TERMINATED:
					case MWUtil.ED_SHADOWE:
						MW.printf("From Condor LogReader " + line.tail + ", worker exited");
						onWorkerExit(line.tail);
						break;
						
					case MWUtil.ED_SUBMITTED:
					case MWUtil.ED_SUSPEND:
					case MWUtil.ED_RESUMED:
					case MWUtil.ED_EXECUTE:
						MW.printf("Got message " + type + " from Condor LogReader, ignored");
						break;
					
					default: 
						MW.printf("Unknown message from worker");
						break;
				}
			} else {
				MW.waitFor(100);
			}
		} /* end while true */
	}
	
  /* event handlers */
	public void onPause() {
		for (int i=0; i<workers.size(); i++) {
			MWWorkerID w = (MWWorkerID)(workers.get(i));
			if (w.state == w.W_BUSY)
				MW.sendMessage(w.out, MWUtil.DW_PAUSE, null);
		}
		paused = true;
		MW.sendMessage(out_cli, MWUtil.DC_PAUSED, null);
		MW.printf("MWDriver paused");
	}

	public void onResume() {
		for (int i=0; i<workers.size(); i++) {
			MWWorkerID w = (MWWorkerID)(workers.get(i));
			if (w.state == w.W_BUSY)
				MW.sendMessage(w.out, MWUtil.DW_RESUME, null);
		}

		paused = false;
		MW.sendMessage(out_cli, MWUtil.DC_RESUMED, null);
		assignTasks();
		MW.printf("MWDriver resumed");
	}

	public void onQuit() {
		/* Kill all workers */
		int i, len = workers.size();
		String cmd;
		
		for (i=0; i<len; i++) {
			MWWorkerID w = (MWWorkerID)workers.remove(0);
			killWorker(w);
		}
		
		/* kill LogReader process */
		logReader.destroy();
		if (debug != null) 
			debug.destroy();

		/* quit */
		MW.sendMessage(out_cli, MWUtil.DC_QUITED, null);
		System.exit(0);
	}

	/* Default command implementation */
	public void onAddHost(String req) {
		int num = MWUtil.str2int(req.trim());
		targetNum += num;
		addHost();
		MW.sendMessage(out_cli, MWUtil.DC_CMD_ACK, "MWDriver will add " + num + " workers\n");
	}
	
	/** addHost will compare the target number of workers and the number of 
	 *  request made, it will return how many workers are needed (negative value
	 *  means the need to remove workers). When more workers are needed, and it will
	 *  also generate submit file and ask the underlying platform for more hosts */
	public int addHost() {
		MW.printf("Entered addHost");
		int i, id, masterID = -1;
		String ret = null;
		BufferedReader br;
		String line = null;
		
		int diff = targetNum - requestNum;
		if (diff <= 0)
			return diff;
	
		String submit = new String();
		/* 
	   	submit += "Universe = Java\n";
	   	submit += "Executable = MWWorker.class \n";
	   	submit += "Requirements = ( " +  config_reqs + " ) " + "\n";
		submit += "Transfer_input_files = " + config_transfer + "\n";
	   	submit += "\nGetenv = True\n\n";
		*/

	   	submit += "Universe = Vanilla\n";
	   	submit += "Executable = " +  config_exec + "\n";
	   	submit += "Requirements = ( " +  config_reqs + " ) " + "\n";
		submit += "Transfer_input_files = " + config_transfer + "\n";
		submit += "Transfer_files = ON_EXIT";
	   	submit += "\n\n";

			
		/* for each new worker, get its vid, and write submit file */
		submit += "# Arguments = worker_id master_id master_port master_host \n\n";
		MWWorkerID wrks[] = new MWWorkerID[diff];
		for (i=0; i<diff; i++) 	{
			id = MWWorkerID.getVID();
			
			wrks[i] = new MWWorkerID();
			wrks[i].id1 = id;
			wrks[i].pid = i;
			workers.add(wrks[i]);
			
			/* 
			submit += "Arguments = " 
	                + "MWWorker "
			*/
			
	   		submit += "Arguments = "
		   		+ id 			/* worker id */ + " "
				+ masterID 		/* master id */ + " "
			   	+ MWUtil.MW_READER_PORT 	/* master socket number */ + " "
			   	+ hostname		/* master address */ + " "
			   	+ "\n";
			submit += "Output = output_file." + id /* worker id */ + "\n";
		   	submit += "Error = error_file." + id /* worker id */ + "\n";
			submit += "Log = log_file." + id /* worker id */ + "\n";
		   	submit += "Queue\n\n";
		}

		String sfname = "submit.imw" + submitNo;
		submitNo ++;
		MW.overwriteFile(sfname, submit);
		
		/* call condor_submit */
	   	try { 
			Process p = Runtime.getRuntime().exec(new String [] {
				   	MWUtil.CONDOR_DIR + "condor_submit", 
					sfname
			});
			ret = new String("");
		   	br = new BufferedReader(new InputStreamReader(p.getInputStream()));
		   	while ( (line = br.readLine()) != null)
			   	ret += line + "\n";
			p.waitFor();
			
			int pos = ret.indexOf("submitted to cluster");
			if (pos < 0) {
				MW.printf("condor_submit failed, need to make sure condor is installed!");
				System.exit(1);
			} else {
				pos +=  (new String("submitted to cluster")).length();
			}
			String cid_str = ret.substring(pos, ret.length()-2).trim();
			int cid = MW.str2int(cid_str);
			for (i=0; i<diff; i++) {
				wrks[i].state = MWWorkerID.W_SUBMITTED;
				wrks[i].cid = cid;
			}
			
	   	} catch (IOException e1) {
		   	MW.printf("IOException starting process!");
	   	} catch (InterruptedException e2) {
		   	MW.printf("InterruptedException waiting for process!");
	   	}

		/* update numbers */
		requestNum += diff;
		MW.printf("MWDriver called condor submit: target = " + targetNum + " request = " + requestNum);

		return diff;
	}

	/** create a logReader process and listen from it */
	void startLogReader() {
	   	String ret, line = null;
		BufferedReader br = null, er = null;

	   	try {
			/* first we need to move all the old output, error, and log files 
			 * to a safe place oldruns/ */
			Process p = Runtime.getRuntime().exec(new String [] {
					"/bin/sh", "-c", "./mymv.sh" });
			
			ret = new String("");
		   	br = new BufferedReader(new InputStreamReader(p.getInputStream()));
		   	while ( (line = br.readLine()) != null)
			   	ret += line + "\n";
		   	er = new BufferedReader(new InputStreamReader(p.getErrorStream()));
		   	while ( (line = er.readLine()) != null)
			   	ret += line + "\n";
			p.waitFor();
			MW.printf("MWDriver mv files into oldruns: \n" + ret);
			
			p = Runtime.getRuntime().exec(new String [] {"/bin/rm", "-f", MWUtil.MW_LOG_NAME});
			p.waitFor();

			/* start the server socket */
			try {
			   	server = new ServerSocket(MWUtil.MW_READER_PORT, 24);
		   	} catch (IOException e) {
			   	System.err.println("Could not listen on port: " + MWUtil.MW_READER_PORT);
			   	System.exit(-1);
		   	}

			/* Then we can start MWLogReader process, which won't be
			 * destroyed until before MWDriver exits. */
		   	logReader = Runtime.getRuntime().exec(new String [] {
				   	"./MWLogReader",
					MWUtil.MW_LOG_NAME
			});
	   	} catch (IOException e1) {
		   	MW.printf("IOException starting process!");
	   	} catch (InterruptedException e2) {
			 MW.printf("InterruptedException waiting for process!");
		}
		MW.printf("MWDriver created the MWLogReader process");
		MW.waitFor(100);

		/* TODO: create a MWFileReader and MWAccept thread to accept later connections */
		MWFileReader rr = new MWFileReader(MWUtil.MW_LOG_NAME, fout, FIFO_workers, this);
	   	Thread t1 = new Thread(rr);
	   	t1.start();

		MWAccept ap = new MWAccept(server, fout, FIFO_workers, this);
		Thread t2 = new Thread(ap);
		t2.start();

		/* XXX: start a local debuging worker */
		if (DEBUG == 1) {
			int tid = MWWorkerID.getVID();
			MWWorkerID tw = new MWWorkerID();
			tw.id1 = tid;
			workers.add(tw);
			
			try {
				debug = Runtime.getRuntime().exec(new String [] {
					"./worker.exe", new String(tid + ""), "-1", "9001", "ferdinand" });
		   	} catch (IOException e3) {
			   	MW.printf("IOException starting process!");
			}
		}
	}

	/** to report the current workers info to the client */
	public void onStatus(String req) {
		String msg = new String("\nWorker Status:\n");

		for (int i=0; i<workers.size(); i++) {
			MWWorkerID w = (MWWorkerID)workers.get(i);
			msg += w.print();	
		}
		
		/* summary */
		msg += "\n#Worker = " + workers.size();
		msg += "\ntargetNum = " + workers.size();
		msg += "\nrequested = " + workers.size();
		msg += "\n#TaskCluster = " + tasks.size();
		
		if (tasks.size() != 0) {
			MWTaskCluster tc = (MWTaskCluster)(tasks.get(0));
			msg += "\n\nHead TaskCluster:";
			msg += "\ntotal tasks = " + tc.size();
			msg += "\nfinished tasks = " + tc.done;
			msg += "\nassigned tasks = " + tc.assigned;
			msg += "\nunassigned tasks = " + tc.unassigned;
		}
		
		MW.sendMessage(out_cli, MWUtil.DC_CMD_ACK, msg);
	}

	/** called when the acceptor get a new connection from a worker */
	void newWorker(Socket s, String info) {
		int type;
		
		MWMessage line = new MWMessage(info);
	   	type = MW.parseMessage(line);
		if (type != MWUtil.WD_CREATED) {
			MW.printf("MWDriver get a new connection, but not followed by WD_CREATED event!");
			System.exit(1);
		} else {
		   	line.msg = line.tail;
		   	line.tail = null;
		   	type = MW.parseMessage(line);
			MW.printf("MWDriver got a WD_CREATED event from worker " + type 
					+ ", worker hostname = " + line.tail);
			
			/* update worker info */
			if (type == -1) {
				MW.printf("MWDriver get connection from MWLogReader");
			} else {
				MWWorkerID w = getWorker(type);
				if ( w == null ) {
					/* tell the worker to kill itself */
					MW.printf("But I can't find worker with ID " + type + ", event ignored");
					PrintWriter pr = null;
					try {
						pr = new PrintWriter(s.getOutputStream());
				   		MW.sendMessage(pr, MWUtil.DW_QUIT, null);
					} catch (IOException e) {
						MW.printf("IOException");
					}
			   	} else {
				   	if (w.state == MWWorkerID.W_SUBMITTED) { /* Good */
					   	w.socket = s;
						w.hostName = line.tail.trim();
						MW.printf("Hostname = |" + w.hostName + "|");
						w.getMachineInfo(MW);
					   	w.state = MWWorkerID.W_IDLE;
					   	try {
						   	w.out = new PrintWriter(s.getOutputStream(), true);
					   	} catch (IOException e) {
						   	MW.printf("MWDriver failed in getOutputStream() of " + s.toString());
					   	}

						/* tell MWClient that a new worker appears */
						MW.sendMessage(out_cli, MWUtil.DC_UPDATE, "MWDriver got new worker " + w.hostName);

						MW.waitFor(5000);
						
						/* assign a task for this worker */
						assignTaskTo(w);

				   	} else { /* Bad */
					   	MW.printf("But worker " + type + " is in state " 
							+ w.state + " (should be WD_SUBMITTED), will kill it");
						killWorker(w);
					}
				}
			}
		}
	}

	/** helper func: return the reference of MWWorkerID with the given id */
	public MWWorkerID getWorker(int id) {
		int i, len = workers.size();
		MWWorkerID w = null;
		for (i=0; i<len; i++) {
			w = (MWWorkerID)workers.get(i);
			if (w.id1 == id)
				return w;
		}

		return null;
	}

	/** called when a worker is terminated, and request for new workers if needed */
	public void onWorkerExit(String msg) {
		StringTokenizer st = new StringTokenizer(msg);
		st.nextToken();
		int wid = MWUtil.str2int(st.nextToken());
		workers.remove(getWorker(wid));
		MWWorkerID.releaseVID(wid);
		MW.printf("MWDriver released WID of " + wid);
	   	requestNum --;
	   	addHost();
	}

	/** kill a worker deliberately */
	public void killWorker(MWWorkerID w) {
		MW.printf("Killing worker " + w.id1 +  ": " + w.cid + "." + w.pid);
	   	try {
		   	Process p = Runtime.getRuntime().exec(new String [] {
				   	MWUtil.CONDOR_DIR + "condor_rm", new String(w.cid + "." + w.pid)
		   	});
		   	p.waitFor();
	   	} catch (IOException e1) {
		   	MW.printf("IOException starting process!");
	   	} catch (InterruptedException e2) {
		   	MW.printf("InterruptedException waiting for process!");
	   	}
   	}

	/** find the workerID object with the given id1 */
	public MWWorkerID findWorker(int wid) {
		MWWorkerID w;
		
		for (int i=0; i<workers.size(); i++) {
			w = (MWWorkerID)(workers.get(i));
			if (w.id1 == wid)
				return w;
		}

		return null;
	}
	
	/** find the task cluster with given TCID */
	public MWTaskCluster findTaskCluster(int tcid) {
		if (tasks.size() == 0)
			return null;

		MWTaskCluster tc = (MWTaskCluster)tasks.get(0);
		if (tc.ID > tcid) 
			return null;
		else if (tc.ID < tcid) {
			MW.printf("Looking for task cluster " + tcid 
					+ ", but that task cluster is already finished.");
			return null;
		}
		
		return tc;
	}
	
	/** find the task with given TCID and TID */
	public MWTask findTask(int tcid, int tid) {
		MWTaskCluster tc = findTaskCluster(tcid);
		if (tc == null)
			return null;

		MWTask t;
		for (int i=0; i<tc.size(); i++) {
			t = (MWTask)tc.tasks.get(i);
			if (t.ID == tid) 
				return t;
		}

		return null;
	}
	
	/** find the next IDLE worker */
	public MWWorkerID getNextWorker() {
		MWWorkerID w;
		
		for (int i=0; i<workers.size(); i++) {
			w = (MWWorkerID)(workers.get(i));
			if ( w.state == w.W_IDLE )
				return w;
		}

		return null;
	}

	/** find the next TODO task from the head of tasks */
	public MWTask getNextTask() {
		int i;
		int idle = 0;
		MWTask t;
		MWTaskCluster tc;

		if ( (tasks.size() == 0) || (paused == true) )
			return null;

		tc = (MWTaskCluster) tasks.get(0);
		/* in case the application forget to remove tc */
		if (tc.done == tc.size() ) {
			MW.printf("The head of tasks is finished: #tasks = " + tc.size()
					+ "#tasks_done = " + tc.done + ". Will remove it from tasks!");
			tasks.remove(tc);
		}
		
		if (tc.assigned < tc.size()) {
			for (i=0; i<tc.tasks.size(); i++) {
				t = (MWTask) tc.tasks.get(i);
				if (t.state == t.T_UNASSIGNED)
					return t;
			}
		} else { 
			/* how many workers are IDLE */
			for (i=0; i<workers.size(); i++) {
				if ( ((MWWorkerID)workers.get(i)).state == MWWorkerID.W_IDLE )
					idle ++;
			}
			/* search for the task that other workers are waiting for */
			int remain = tc.size() - tc.done;
			if ( remain <= idle ) {
				MW.printf("Many idle workers (" + idle + ") are waiting for few tasks (" + remain + ")" );
				for (i=0; i<tc.tasks.size(); i++) {
					t = (MWTask) tc.tasks.get(i);
					if ( (t.state != t.T_DONE) && (t.workers.size() == 1) ) {
						MW.printf("Will assign task " + t.TCID + "." + t.ID + " to more workers");
						return t;
					}
				}
			}
		}

		return null;
	}

	
	/** assign TODO tasks to IDLE workers */
	public void assignTasks() {
		/* Currently, only use the simple scheduling policy:
		 * for each idle worker, get a UNASSIGNED task from the first
		 * task cluster, and assign the task to the worker. */
		
		MWTask t;
		MWWorkerID w;
		while(  ( (t = getNextTask()) != null ) && ( (w = getNextWorker()) != null ) ) {
			assignTo(w, t);
		}
	}

	/** find a task to assign to this worker */
	public void assignTaskTo(MWWorkerID w) {
	   	MWTask t = getNextTask();
	   	if (t != null)
		   	assignTo(w, t);
	}

	/** assign a task to a worker, and send the task out */
	public void assignTo(MWWorkerID w, MWTask t) {
		if (w.state != w.W_IDLE) {
			MW.printf("Assigning task to a work (" + w.id1 + ")not in IDLE state");
			return;
		}

		if (t.state != t.T_UNASSIGNED) {
			String str = new String("");
			str += "Task " + t.TCID + "." + t.ID + " assigned to more than one worker:";
			for (int i=0; i<t.workers.size(); i++)
				str += " " + ((MWWorkerID)t.workers.get(i)).id1;
			MW.printf(str);
		}
	
		/* bookkeeping */
		t.workers.add(w);
		if (t.state == t.T_UNASSIGNED) {
			t.state = t.T_ASSIGNED;
			t.tc.assigned ++;
			t.tc.unassigned --;
		}
		w.state = w.W_BUSY;
		w.task = t;

		/* send the task to the worker */
		MW.printf("MWDriver sending task " + t.TCID + "." + t.ID + " to worker " + w.id1);
		MW.sendMessage(w.out, MWUtil.DW_WORK, t.pack_work(""));
	}

	/** Virtual functions to be implemented by application developer */

	/** What to do when MWDriver gets a command from the client: 
	 *  (1) parse the command and generate new tasks
	 *  (2) put the tasks into a new TaskCluster
	 *  (3) add the TaskCluster into the tasks list;
	 *  (4) assgin tasks to current IDLE workers
	 */
	public MWTaskCluster act_on_new_command(int cmd, String cmdline) {
		return null;
	}

	public int act_on_completed_task(MWTask t) {
		return 0;
	}
};

