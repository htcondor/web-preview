/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "domain_name.h"
#include "stringtools.h"
#include "debug.h"

#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/time.h>
#include <sys/utsname.h>
#include <sys/un.h>

#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <netdb.h>
#include <errno.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int domain_name_lookup_reverse( const char *addr, char *name )
{
	struct hostent *h;
	struct hostent result;
	char buffer[32768];
	int herrno;
	struct in_addr iaddr;

	#ifdef linux
		int success;
	#endif

	debug("domain_name: looking up addr %s",addr);

	if(!string_to_ip_address(addr,(unsigned char*)&iaddr)) {
		debug("domain_name: %s is not a valid addr");
		return 0;
	}

	#ifdef linux
		success = gethostbyaddr_r( (char*)&iaddr, sizeof(iaddr), AF_INET, &result, buffer, 32768, &h, &herrno );
	#else
		h = gethostbyaddr_r( (char*)&iaddr, sizeof(iaddr), AF_INET, &result, buffer, 32768, &herrno );
	#endif
	if(h) {
		strcpy(name,result.h_name);
		debug("domain_name: %s is %s",addr,name);
		return 1;
	} else {
		debug("domain_name: couldn't lookup %s: %s",addr,strerror(errno));
		return 0;
	}
}

int domain_name_lookup( const char *name, char *addr )
{
	struct hostent *h;
	struct hostent result;
	char buffer[32768];
	int herrno;

	#ifdef linux
		int success;
	#endif

	debug("domain_name: looking up name %s",name);

	#ifdef linux
		success = gethostbyname_r( name, &result, buffer, 32768, &h, &herrno );
	#else
		h = gethostbyname_r( name, &result, buffer, 32768, &herrno );
	#endif
	if(h) {
		string_from_ip_address(h->h_addr,addr);
		debug("domain_name: %s is %s",name,addr);
		return 1;
	} else {
		debug("domain_name: couldn't look up %s: %s",name,strerror(errno));
		return 0;
	}
}



