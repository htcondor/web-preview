/*
The ClassAd Catalog is Copyright (C) 2002 Douglas Thain and the Condor Team
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "catalog_server.h"
#include "catalog_update.h"
#include "datagram.h"
#include "domain_name_cache.h"

#include <stdlib.h>
#include <string.h>

struct catalog_update {
	struct datagram *dgram;
	char addr[DATAGRAM_ADDRESS_MAX];
	int port;
};

struct catalog_update * catalog_update_create( const char *host, int port )
{
	struct catalog_update *cu;

	cu = malloc(sizeof(*cu));
	if(!cu) return 0;

	cu->dgram = datagram_create(DATAGRAM_PORT_ANY);
	if(!cu->dgram) {
		free(cu);
		return 0;
	}

	if(!domain_name_cache_lookup(host,cu->addr)) {
		datagram_delete(cu->dgram);
		free(cu);
		return 0;
	}

	cu->port = port;

	return cu;
}

int catalog_update_write( struct catalog_update *cu, const char *update )
{
	int result;
	result = datagram_send(cu->dgram,update,strlen(update),cu->addr,cu->port);
	if(result==strlen(update)) {
		return 1;
	} else {
		return 0;
	}
}

void catalog_update_delete( struct catalog_update *cu )
{
	if(cu) {
		datagram_delete(cu->dgram);
		free(cu);
	}
}

