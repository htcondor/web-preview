/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#ifndef HASH_CACHE_H
#define HASH_CACHE_H

#include "hash_table.h"

typedef void (*hash_cache_cleanup_t) ( void *value );

struct hash_cache * hash_cache_create( int size, hash_func_t func, hash_cache_cleanup_t cleanup );
void hash_cache_delete( struct hash_cache *cache );

int hash_cache_insert( struct hash_cache *cache, const char *key, void *value, int lifetime, int max );
void * hash_cache_remove( struct hash_cache *cache, const char *key );
void * hash_cache_lookup( struct hash_cache *cache, const char *key );
int hash_cache_clean( struct hash_cache *cache );

#endif

