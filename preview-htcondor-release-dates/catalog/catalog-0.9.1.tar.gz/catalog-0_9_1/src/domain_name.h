/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/

#ifndef DOMAIN_NAME_H
#define DOMAIN_NAME_H

/* Maximum number of characters in a domain name or address */
#define DOMAIN_NAME_MAX 256

int domain_name_lookup( const char *name, char *addr );
int domain_name_lookup_reverse( const char *addr, char *name );

#endif
