/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#ifndef DEBUG_H
#define DEBUG_H

#include <stdio.h>

#define DEBUG_PORT 9101

void debug( char *fmt, ... );
void error( char *fmt, ... );
void fatal( char *fmt, ... );

void debug_config( char *name );

void debug_config_console( int onoff );
void debug_config_file( const char *file );
void debug_config_file_size( int size );
int  debug_config_host( const char *host );

#endif

