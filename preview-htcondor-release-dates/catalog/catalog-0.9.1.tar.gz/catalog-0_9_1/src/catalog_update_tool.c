/*
The ClassAd Catalog is Copyright (C) 2002 Douglas Thain and the Condor Team
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "catalog_update.h"
#include "cclassad.h"
#include "getopt.h"
#include "debug.h"

#include <stdio.h>
#include <stdlib.h>

static char *catalog_host = "kangaroo.cs.wisc.edu";
static int  catalog_port = 9098;
static int timeout = 30;

static void show_version( char *cmd )
{
	printf("%s %s %s",cmd,__DATE__,__TIME__);
}

static void show_use( char *cmd )
{
	fprintf(stderr,"This program reads a single ClassAd from the standard input,\n");
	fprintf(stderr,"and sends an update message to the named catalog server.\n\n");

	fprintf(stderr,"Use: %s [options]\n",cmd);
	fprintf(stderr,"   -c <host> Catalog server (default is %s)\n",catalog_host);
	fprintf(stderr,"   -p <host> Catalog port (default is %d)\n",catalog_port);
	fprintf(stderr,"   -t <secs> Timeout for network operations (default is %d)\n",timeout);
	fprintf(stderr,"   -d        Turn on debugging output\n");
	fprintf(stderr,"   -v        Show version string\n");
	fprintf(stderr,"   -h        Show this help screen\n");
}

int main( int argc, char *argv[] )
{
	char payload[CATALOG_UPDATE_MAX];
	struct catalog_update *updater;
	struct cclassad *c;
	int actual;
	char ch;
	
	debug_config(argv[0]);

	while((ch=getopt(argc,argv,"c:p:t:dvh"))!=(char)-1) {
		switch(ch) {
			case 'c':
				catalog_host = optarg;
				break;
			case 'p':
				catalog_port = atoi(optarg);
				break;
			case 't':
				timeout = atoi(optarg);
				break;
			case 'd':
				debug_config_console(1);
				break;
			case 'v':
				show_version(argv[0]);
				return 0;
			case 'h':
			default:
				show_use(argv[0]);
				return 0;
		}
	}

	actual = fread(payload,1,sizeof(payload)-1,stdin);
	if(actual<=0) fatal("Couldn't read ClassAd from the standard input!");

	payload[actual] = 0;

	c = cclassad_create(payload);
	if(!c) fatal("That's not a valid ClassAd!");

	updater = catalog_update_create(catalog_host,catalog_port );
	if(!updater) fatal("couldn't communicate with %s port %d",catalog_host,catalog_port);
	catalog_update_write(updater,payload );
	catalog_update_delete(updater);

	return 0;
}
