/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#ifndef HASH_TABLE_H
#define HASH_TABLE_H

typedef int (*hash_func_t) ( const char *key );

struct hash_table * hash_table_create( int buckets, hash_func_t func );
void hash_table_delete( struct hash_table *h );

int hash_table_insert( struct hash_table *h, const char *key, const void *value, void **old );
void * hash_table_lookup( struct hash_table *h, const char *key );
void * hash_table_remove( struct hash_table *h, const char *key );

typedef int (*hash_table_op_t) ( struct hash_table *h, char *key, void *item, void *arg );

int hash_table_iterate( struct hash_table *h, hash_table_op_t, void *arg );
int hash_string( const char *s );

#endif
