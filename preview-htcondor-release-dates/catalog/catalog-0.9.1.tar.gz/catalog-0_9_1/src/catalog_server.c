/*
The ClassAd Catalog is Copyright (C) 2002 Douglas Thain and the Condor Team
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "cclassad.h"

#include "catalog_server.h"
#include "datagram.h"
#include "link.h"
#include "hash_table.h"
#include "debug.h"
#include "getopt.h"

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <alloca.h>
#include <errno.h>

/* This mutex protects all global data. */
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/* The table of classads, hashed on name:updater-address */
static struct hash_table *table=0;

/* The query string is shared, as only one query can hold the mutex at once */
static char query[CATALOG_LINE_MAX];

/* The default timeout for network operations.  Don't be forgiving on
   TCP connections, as one bad client can hold everybody else up. */
static int timeout = 30;

/* The time for which updated data lives before automatic deletion */
static int expires = 900;

/* The port upon which to listen. */
static int port = CATALOG_PORT;

static void * update_thread( void *arg )
{
	struct datagram *dgram = arg;
	struct cclassad *ad, *oldad;
	char *name;

	char data[DATAGRAM_PAYLOAD_MAX];
	char addr[DATAGRAM_ADDRESS_MAX];
	int port;
	int result;

	while(1) {
		result = datagram_recv(dgram,data,sizeof(data),addr,&port,60);
		if(result<=0) continue;

		debug("%s:%d updated via udp",addr,port);

		ad = cclassad_create(data);
		if(!ad) continue;

		if(!cclassad_insert_int(ad,"Timestamp",time(0))) {
			cclassad_delete(ad);
			continue;
		}

		if(!cclassad_insert_string(ad,"UpdateAddress",addr)) {
			cclassad_delete(ad);
			continue;
		}

		if(cclassad_evaluate_to_string(ad,"Name",&name)) {
			char *key = alloca(strlen(name)+strlen(addr)+3);
			sprintf(key,"%s:%s",name,addr);
			free(name);
			pthread_mutex_lock(&mutex);
			if(hash_table_insert(table,key,ad,(void**)&oldad)) {
				if(oldad) cclassad_delete(oldad);
			}
			pthread_mutex_unlock(&mutex);
		} else {
			debug("%s:%d sent an ad without a Name!",addr,port);
		}
	}
}

/*
Consider this classad and send it back along the link
if it meets a variety of criteria.
Notice that the result of this function controls whether
we keep working through the hash table.  "Return 1" means
this ad didn't match, but keep working.  "Return 0" means
something is badly wrong, stop and abort the connection.
*/

static int send_item( struct hash_table *table, char *key, void *item, void *arg )
{
	struct cclassad *c = item;
	struct link *link = arg;
	int result;
	int stamp;
	char *str;
	int match;

	if(!cclassad_evaluate_to_bool(c,query,&match)) return 1;
	if(!match) return 1;
	if(!cclassad_evaluate_to_int(c,"Timestamp",&stamp)) return 1;
	if((stamp+expires)<time(0)) {
		hash_table_remove(table,key);
		cclassad_delete(c);
		return 1;
	}

	str = cclassad_unparse(c);
	if(!str) return 1;

	result = link_write(link,str,strlen(str),timeout);
	if(result<=0) {
		free(str);
		return 0;
	}
	result = link_write(link,"\n",1,timeout);
	if(result<=0) {
		free(str);
		return 0;
	}

	return 1;
}

static void * query_thread( void *arg )
{
	struct link *link = arg;
	char line[CATALOG_LINE_MAX];
	char addr[LINK_ADDRESS_MAX];
	int port;

	link_address_remote(link,addr,&port);
	debug("%s:%d connected via tcp",addr,port);

	if(link_readline(link,line,sizeof(line),timeout)) {
		debug("%s:%d querying for %s",addr,port,line);
		pthread_mutex_lock(&mutex);
		strcpy(query,line);
		hash_table_iterate(table,send_item,link);
		pthread_mutex_unlock(&mutex);
	}

	link_close(link);	
	debug("%s:%d disconnected",addr,port);

	return 0;
}

void show_version( const char *cmd )
{
	printf("%s %s %s\n",cmd,__DATE__,__TIME__);
}

void show_help( const char *cmd )
{
	fprintf(stderr,"Use: %s [options]\n",cmd);
	fprintf(stderr,"   -p <port> Port number to listen on (default is %d)\n",port);
	fprintf(stderr,"   -e <secs> Expiration time of stale data, in seconds (default is %d)\n",expires);
	fprintf(stderr,"   -t <secs> Timeout on hung clients, in seconds (default is %d)\n",timeout); 
	fprintf(stderr,"   -f        For Condor compatibility\n");
	fprintf(stderr,"   -d        Turn on debugging output\n");
	fprintf(stderr,"   -v        Show version string\n");
	fprintf(stderr,"   -h        Show this help screen\n");
}

int main( int argc, char *argv[] )
{
	struct datagram *update_port=0;
	struct link *link, *list_port=0;
	pthread_t list_tid, update_tid;
	int result;
	char ch;

	debug_config(argv[0]);

	while((ch=getopt(argc,argv,"p:e:t:dfhv"))!=(char)-1) {
		switch(ch) {
			case 'd':
				debug_config_console(1);
				break;
			case 'p':
				port = atoi(optarg);
				break;
			case 'e':
				expires = atoi(optarg);
				break;
			case 'f':
				/* do nothing */
				break;
			case 't':
				timeout = atoi(optarg);
				break;
			case 'v':
				show_version(argv[0]);
				return 0;
			case 'h':
			default:
				show_help(argv[0]);
				return 1;
		}
	}

	table = hash_table_create(127,hash_string);
	if(!table) {
		fprintf(stderr,"couldn't make hash table\n");
		return 1;
	}

	update_port = datagram_create( port );
	if(!update_port) {
		fprintf(stderr,"couldn't listen on udp port %d\n",port);
		return 1;
	}

	list_port = link_serve( port );
	if(!list_port) {
		fprintf(stderr,"couldn't listen on tcp port %d\n",port);
		return 1;
	}

	result = pthread_create(&update_tid,0,update_thread,update_port);
	if(result!=0) {
		fprintf(stderr,"couldn't start incoming udp thread!\n");
		return 1;
	}

	while(1) {
		link = link_accept(list_port);
		if(link) {
			result = pthread_create(&list_tid,0,query_thread,link);
			if(result!=0) {
				debug("couldn't start incoming tcp thread: %s",strerror(errno));
				link_close(link);
			} else {
				pthread_detach(list_tid);
			}
		}
	}

	return 1;
}

