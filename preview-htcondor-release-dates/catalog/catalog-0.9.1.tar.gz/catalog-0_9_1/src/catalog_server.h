/*
The ClassAd Catalog is Copyright (C) 2002 Douglas Thain and the Condor Team
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#ifndef CATALOG_SERVER_H
#define CATALOG_SERVER_H

#define CATALOG_LINE_MAX 65536
#define CATALOG_PORT 9098

#endif
