/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "stringtools.h"

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <ctype.h>

#define STRINGTOOLS_BUFFER_SIZE 256
#define METRIC_POWER_COUNT 6

void string_from_ip_address( const unsigned char *bytes, char *str )
{
	sprintf(str,"%u.%u.%u.%u",
		(unsigned)bytes[0],
		(unsigned)bytes[1],
		(unsigned)bytes[2],
		(unsigned)bytes[3]);
}

int  string_to_ip_address( const char * str, unsigned char *bytes )
{
	unsigned a,b,c,d;
	int fields;

	fields = sscanf( str, "%u.%u.%u.%u", &a, &b, &c, &d );
	if(fields!=4) return 0;

	if( a>255 || b>255 || c>255 || d>255 ) return 0;

	bytes[0] = a;
	bytes[1] = b;
	bytes[2] = c;
	bytes[3] = d;

	return 1;
}

void string_chomp( char *s )
{
	if(!s) return;

	while(*s) {
		s++;
	}

	s--;

	while(*s=='\n' || *s=='\r') {
		*s=0;
		s--;
	}
}

int string_match( const char *pattern, const char *text )
{
        char *w;
        int headlen, taillen;

        w = strchr( pattern, '*' );
        if(!w) return !strcmp(pattern,text);

        headlen = w-pattern;
        taillen = strlen(pattern)-headlen-1;

        return !strncmp(pattern,text,headlen) && !strcmp(&pattern[headlen+1],&text[strlen(text)-taillen]);
}

char * string_front( const char *str, int max )
{
	static char buffer[STRINGTOOLS_BUFFER_SIZE];
	int length;

	length = strlen(str);
	if(length<max) {
		strcpy(buffer,str);
	} else {
		strncpy(buffer,str,max);
		buffer[max] = 0;
	}
	return buffer;
}

const char * string_back( const char *str, int max )
{
	int length;

	length = strlen(str);
	if(length<max) {
		return str;
	} else {
		return &str[length-max];
	}
}

void string_metric( int invalue, int power_needed, char *buffer )
{
	static char *suffix[METRIC_POWER_COUNT] =
		{ " ", "K", "M", "G", "T", "P" };

	double value=invalue;
	int power=0;

	if(power_needed==-1) {
		while( (value>=1024.0) && (power<(METRIC_POWER_COUNT-1)) ) {
			value = value / 1024.0;
			power++;
		}
	} else {
		power = power_needed;
		value = value / (pow(2,10*power));
	}

	sprintf( buffer, "%.1f %s", value, suffix[power] );
}

int string_split( char *str, int *argc, char ***argv )
{
	*argc=0;

	*argv = malloc(strlen(str)*sizeof(char*));
	if(!*argv) return 0;

	while(*str) {
		while(isspace((int)*str)) {
			str++;
		}
		(*argv)[(*argc)++] = str;
		while(*str && !isspace((int)*str)) {
			str++;
		}
		if(*str) {
			*str = 0;
			str++;       
		}
	}

	(*argv)[*argc] = 0;

	return 1;
}

char * string_pad_right( char *old, int length )
{
	int i;
	char *s = malloc(length+1);
	if(!s) return 0;

	if( strlen(old) <= length ) {
		strcpy(s,old);
		for(i=strlen(old);i<length;i++) {
			s[i] = ' ';
		}
	} else {
		strncpy(s,old,length);
	}
	s[length] = 0;
	return s;
}

char * string_pad_left( char *old, int length )
{
	int i;
	int slength;
	int offset;
	char *s;

	s = malloc(length+1);
	if(!s) return 0;

	slength = strlen(old);
	offset = length-slength;

	for(i=0;i<length;i++) {
		if(i<offset) {
			s[i] = ' ';
		} else {
			s[i] = old[i-offset];
		}
	}

	s[length]=0;
	return s;
}

