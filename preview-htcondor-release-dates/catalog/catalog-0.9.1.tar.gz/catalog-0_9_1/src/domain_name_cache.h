/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/

#ifndef DOMAIN_NAME_CACHE_H
#define DOMAIN_NAME_CACHE_H

#include "domain_name.h"

int domain_name_cache_guess( char *name );
int domain_name_cache_lookup( const char *name, char *addr );
int domain_name_cache_lookup_reverse( const char *addr, char *name );

#endif
