/*
The ClassAd Catalog is Copyright (C) 2002 Douglas Thain and the Condor Team
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "catalog_server.h"
#include "catalog_query.h"
#include "link.h"
#include "domain_name_cache.h"

#include <string.h>
#include <stdlib.h>

struct catalog_query {
	char addr[LINK_ADDRESS_MAX];
	int port;
	struct link *link;
};

struct catalog_query * catalog_query_create( const char *host, int port )
{
	struct catalog_query *c;

	c = malloc(sizeof(*c));
	if(!c) return 0;

	if(!domain_name_cache_lookup(host,c->addr)) {
		free(c);
		return 0;
	}

	c->port = port;

	return c;
}

int catalog_query_begin( struct catalog_query *c, const char *query, int timeout )
{
	int result;

	c->link = link_connect(c->addr,c->port,timeout);
	if(!c->link) return 0;

	result = link_write(c->link,query,strlen(query),timeout);
	if(!result) {
		link_close(c->link);
		return 0;
	}

	result = link_write(c->link,"\n",1,timeout);
	if(!result) {
		link_close(c->link);
		return 0;
	}

	return 1;
}

char * catalog_query_read( struct catalog_query *c, int timeout )
{
	char line[CATALOG_LINE_MAX];

	if(link_readline(c->link,line,sizeof(line),timeout)) {
		return strdup(line);
	} else {
		return 0;
	}
}

void catalog_query_delete( struct catalog_query *c )
{
	if(c) free(c);
}
