/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#ifndef LINK_H
#define LINK_H

/* Maximum number of characters in a link address */
#define LINK_ADDRESS_MAX 17

/* Value to usewhen any listen port is acceptable */
#define LINK_PORT_ANY 0

struct link * link_serve( int port );
struct link * link_accept( struct link *master );
struct link * link_connect( const char *addr, int port, int timeout );

int  link_read( struct link *link, char *data, int length, int timeout );
int  link_write( struct link *link, const char *data, int length, int timeout );
int  link_sleep( struct link *link, int timeout, int reading, int writing );
void link_close( struct link *link );
int  link_fd( struct link *link );

int  link_readline( struct link *link, char *line, int length, int timeout );

int  link_address_local( struct link *link, char *addr, int *port );
int  link_address_remote( struct link *link, char *addr, int *port );

#endif













