/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "domain_name_cache.h"
#include "hash_cache.h"
#include "debug.h"

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/utsname.h>

/* cache domain names for up to an hour */
#define DOMAIN_NAME_CACHE_LIFETIME 3600

static struct hash_cache *name_to_addr=0;
static struct hash_cache *addr_to_name=0;

static pthread_mutex_t name_to_addr_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t addr_to_name_mutex = PTHREAD_MUTEX_INITIALIZER;

static int domain_name_cache_init()
{
	pthread_mutex_lock(&name_to_addr_mutex);
	if(!name_to_addr) {
		name_to_addr = hash_cache_create(127,hash_string,free);
		if(!name_to_addr) {
			pthread_mutex_unlock(&name_to_addr_mutex);
			return 0;
		}
	}
	pthread_mutex_unlock(&name_to_addr_mutex);

	pthread_mutex_lock(&addr_to_name_mutex);	
	if(!addr_to_name) {
		addr_to_name = hash_cache_create(127,hash_string,free);
		if(!addr_to_name) {
			pthread_mutex_unlock(&addr_to_name_mutex);
			return 0;
		}
	}
	pthread_mutex_unlock(&addr_to_name_mutex);

	return 1;
}

int domain_name_cache_lookup( const char *name, char *addr )
{
	char *found, *copy;
	int success;

	if(!domain_name_cache_init()) return 0;

	pthread_mutex_lock(&name_to_addr_mutex);	

	found = hash_cache_lookup(name_to_addr,name);
	if(found) {
		strcpy(addr,found);
		pthread_mutex_unlock(&name_to_addr_mutex);
		return 1;
	}

	pthread_mutex_unlock(&name_to_addr_mutex);

	debug("domain_name_cache: looking up name %s...",name);

	success = domain_name_lookup(name,addr);
	if(success) {
		debug("domain_name_cache: %s is %s",name,addr);
	} else {
		debug("domain_name_cache: couldn't lookup %s: %s",name,strerror(errno));
		return 0;
	}

	copy = strdup(addr);
	if(!copy) return 1;

	pthread_mutex_lock(&name_to_addr_mutex);
	success = hash_cache_insert(name_to_addr,name,copy,DOMAIN_NAME_CACHE_LIFETIME,1);
	pthread_mutex_unlock(&name_to_addr_mutex);

	return 1;
}

int domain_name_cache_lookup_reverse( const char *addr, char *name )
{
	char *found, *copy;
	int success;

	if(!domain_name_cache_init()) return 0;

	pthread_mutex_lock(&addr_to_name_mutex);	

	found = hash_cache_lookup(addr_to_name,addr);
	if(found) {
		strcpy(name,found);
		pthread_mutex_unlock(&addr_to_name_mutex);
		return 1;
	}

	pthread_mutex_unlock(&addr_to_name_mutex);

	debug("domain_name_cache: looking up address %s...",addr);

	success = domain_name_lookup_reverse(addr,name);
	if(success) {
		debug("domain_name_cache: %s is %s",addr,name);
	} else {
		debug("domain_name_cache: couldn't lookup %s: %s",addr,strerror(errno));
		return 0;
	}

	copy = strdup(name);
	if(!copy) return 1;

	pthread_mutex_lock(&addr_to_name_mutex);
	success = hash_cache_insert(addr_to_name,addr,copy,DOMAIN_NAME_CACHE_LIFETIME,1);
	pthread_mutex_unlock(&addr_to_name_mutex);

	return 1;
}

int domain_name_cache_guess( char *name )
{
	struct utsname n;
	char addr[DOMAIN_NAME_MAX];

	if(uname(&n)<0) return 0;
	if(!domain_name_cache_lookup(n.nodename,addr)) return 0;
	if(!domain_name_cache_lookup_reverse(addr,name)) return 0;

	return 1;
}

