/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#ifndef ROTATING_FILE_H
#define ROTATING_FILE_H

#include <stdarg.h>

int rotating_file_vprintf( const char *path, int maxsize, const char *fmt, va_list args );
int rotating_file_write( const char *path, int maxsize, const char *data, int size );

#endif
