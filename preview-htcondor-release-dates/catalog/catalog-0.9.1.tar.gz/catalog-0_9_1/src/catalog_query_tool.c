/*
The ClassAd Catalog is Copyright (C) 2002 Douglas Thain and the Condor Team
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "catalog_server.h"
#include "catalog_query.h"
#include "cclassad.h"
#include "stringtools.h"
#include "getopt.h"
#include "debug.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

/* The default catalog server */
static char *catalog_server = "kangaroo.cs.wisc.edu";

/* The default catalog port number */
static int catalog_port = CATALOG_PORT;

/* The default catalog query string */
static char *query = "true";

/* Maximum amount of time to sit blocked on TCP. */
static int timeout = 30;

/* If true, turn off warning messages. */
static int suppress_warnings = 0;

struct field {
	char name[1024];
	int width;
};

typedef enum {
	DISPLAY_CLASSAD,
	DISPLAY_ASCII,
	DISPLAY_HTML,
	DISPLAY_XML,
} display_mode_t;

static int display_header( display_mode_t mode, struct field *f, int n )
{
	char *s;
	int i;

	switch(mode) {
		case DISPLAY_ASCII:
			for(i=0;i<n;i++) {
				s = string_pad_left(f[i].name,f[i].width);
				if(!s) return 0;
				printf("%s",s);
			}
			printf("\n");
			break;
		case DISPLAY_HTML:
			printf("<table>\n<tr>\n");
			for(i=0;i<n;i++) {
				printf("<td><b>%s</b></td>\n",f[i].name);
			}
			printf("</tr>\n");
			break;
		case DISPLAY_XML:
			printf("<xml>\n");
			break;
		default:
			break;
	}
	return 1;
}

static void display_footer( display_mode_t mode )
{
	switch(mode) {
		case DISPLAY_HTML:
			printf("</table>\n");
			break;
		case DISPLAY_XML:
			printf("</xml>\n");
			break;
		default:
			break;
	}
}

static int display_classad( struct cclassad *c )
{
	char *s = cclassad_unparse(c);
	if(s) {
		printf("%s\n\n",s);
		free(s);
		return 1;
	} else {
		return 0;
	}
}

static int display_html( struct cclassad *c, struct field *f, int n )
{
	char *s;
	int i;

	printf("<tr>\n");
	for(i=0;i<n;i++) {
		if(cclassad_evaluate_to_expr(c,f[i].name,&s)) {
			printf("<td>%s</td>\n",s);
			free(s);
		} else {
			printf("<td></td>\n");
		}
	}
	printf("</tr>\n");
	return 1;
}

static int display_ascii( struct cclassad *c, struct field *f, int n )
{
	char *s, *t;
	int i;

	for(i=0;i<n;i++) {
		if(cclassad_evaluate_to_expr(c,f[i].name,&s)) {
			t = string_pad_left(s,f[i].width);
			free(s);
		} else {
			t = string_pad_left("???",f[i].width);
		}
		if(!t) return 0;
		printf("%s",t);
		free(t);
	}
	printf("\n");
	return 1;
}

static int display_xml( struct cclassad *c )
{
	char *s = cclassad_unparse_xml(c);
	if(s) {
		printf("%s\n\n",s);
		free(s);
		return 1;
	} else {
		return 0;
	}
}

static int display_ad( struct cclassad *c, display_mode_t mode, struct field *f, int n )
{
	switch(mode) {
		default:
		case DISPLAY_CLASSAD:
			return display_classad(c);
		case DISPLAY_ASCII:
			return display_ascii(c,f,n);
		case DISPLAY_HTML:
			return display_html(c,f,n);
		case DISPLAY_XML:
			return display_xml(c);
	}
}

static int display_catalog( const char *host, int port, display_mode_t mode, const char *query, struct field *f, int n )
{
	struct catalog_query *c;
	struct cclassad *ad;
	int items=0;
	char *s;

	c = catalog_query_create(catalog_server,port);
	if(!c) {
		fprintf(stderr,"Couldn't connect to %s: %s\n",catalog_server,strerror(errno));
		return 0;
	}

	if(!catalog_query_begin(c,query,timeout)) {
		fprintf(stderr,"Couldn't query %s: %s\n",catalog_server,strerror(errno));
		catalog_query_delete(c);
		return 0;
	}

	while( (s=catalog_query_read(c,timeout)) ) {
		ad = cclassad_create(s);
		if(ad) {
			display_ad(ad,mode,f,n);
			cclassad_delete(ad);
		} else {
			if(!suppress_warnings) {
				fprintf(stderr,"Warning: server sent bogus ClassAd!\n");
			}
		}
		free(s);
		items++;
	}

	if(!items && !suppress_warnings) {
		fprintf(stderr,"Warning: Nothing matched your query.\n");
	}

	catalog_query_delete(c);

	return 1;
}

static void show_version( char *cmd )
{
	printf("%s %s %s",cmd,__DATE__,__TIME__);
}

void show_format_use( char *cmd )
{
	fprintf(stderr,"For this display mode, you must give a list of fields to show.\n");
	fprintf(stderr,"For example:\n");
	fprintf(stderr,"   %s -a Name:20 MemTotal:10\n",cmd);
	fprintf(stderr,"   %s -w Name MemTotal\n",cmd);
}

static void show_use( char *cmd )
{
	fprintf(stderr,"Use: %s [options] [attr[:width]] [attr[:width]]...\n",cmd);
	fprintf(stderr,"   -l        Show plain ClassAds (default)\n");
	fprintf(stderr,"   -x        Show plain XML\n");
	fprintf(stderr,"   -a        Show ASCII table of selected data\n");
	fprintf(stderr,"   -w        Show HTML table of selected data\n");
	fprintf(stderr,"   -c <host> Catalog server (default is %s)\n",catalog_server);
	fprintf(stderr,"   -p <port> Catalog server port (default is %d)\n",catalog_port);
	fprintf(stderr,"   -q <expr> A query expression for limiting catalog results (default is '%s')\n",query);
	fprintf(stderr,"   -t <secs> Timeout for network operations (default is %d)\n",timeout);
	fprintf(stderr,"   -s        Suppress warning messages\n");
	fprintf(stderr,"   -d        Turn on debugging output\n");
	fprintf(stderr,"   -v        Show version string\n");
	fprintf(stderr,"   -h        Show this help screen\n");
	fprintf(stderr,"\n");
	fprintf(stderr,"For example:\n");
	fprintf(stderr,"%s -q '(Name==\"George\")' -a Name:20 MemTotal:10\n\n",cmd);
}

int main( int argc, char *argv[] )
{
	display_mode_t display_mode = DISPLAY_CLASSAD;
	struct field *f;
	int i;
	char ch;
	int n;
	
	debug_config(argv[0]);

	while((ch=getopt(argc,argv,"lawxc:p:q:t:sdvh"))!=(char)-1) {
		switch(ch) {
			case 'l':
				display_mode = DISPLAY_CLASSAD;
				break;
			case 'a':
				display_mode = DISPLAY_ASCII;
				break;
			case 'w':
				display_mode = DISPLAY_HTML;
				break;
			case 'x':
				display_mode = DISPLAY_XML;
				break;
			case 'c':
				catalog_server = optarg;
				break;
			case 'p':
				catalog_port = atoi(optarg);
				break;
			case 'q':
				query = optarg;
				break;
			case 's':
				suppress_warnings = 1;
				break;
			case 't':
				timeout = atoi(optarg);
				break;
			case 'd':
				debug_config_console(1);
				break;
			case 'v':
				show_version(argv[0]);
				return 0;
			case 'h':
			default:
				show_use(argv[0]);
				return 0;
		}
	}

	n = argc-optind;
	if(n<=0) {
		switch(display_mode) {
			case DISPLAY_CLASSAD:
			case DISPLAY_XML:
				/* no format needed */
				break;
			default:
				show_format_use(argv[0]);
				return 1;
		}
	} else {
		f = malloc(sizeof(struct field)*n);
		if(!f) fatal("out of memory");
		for(i=0;i<n;i++) {
			int items;
			items = sscanf(argv[optind+i],"%[^:]:%d",f[i].name,&f[i].width);
			if(display_mode==DISPLAY_ASCII && items<2) {
				show_format_use(argv[0]);
				return 1;
			}

			if(display_mode==DISPLAY_HTML && items<1) {
				show_format_use(argv[0]);
				return 1;
			}
		}
	}

	display_header(display_mode,f,n);
	if(!display_catalog(catalog_server,catalog_port,display_mode,query,f,n)) {
		return 1;
	}
	display_footer(display_mode);

	return 0;
}

