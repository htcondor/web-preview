/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#ifndef LIST_H
#define LIST_H

typedef int (*list_op_t) ( void *item, const void *arg );

struct list * list_create();
struct list * list_splice( struct list *top, struct list *bottom );
void          list_delete( struct list *l );
int	      list_size( struct list *l );

int	      list_push_head( struct list *l, void *item );
void *	      list_pop_head( struct list *l );
void *	      list_peek_head( struct list *l );

int	      list_push_tail( struct list *l, void *item );
void *	      list_pop_tail( struct list *l );
void *	      list_peek_tail( struct list *l );

void *        list_find( struct list *l, list_op_t comparator, const void *arg );
void *        list_remove( struct list *l, list_op_t comparator, const void *arg );
int           list_iterate( struct list *l, list_op_t operator, const void *arg );
int           list_iterate_reverse( struct list *l, list_op_t operator, const void *arg );

#endif
