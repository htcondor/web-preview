/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "datagram.h"
#include "debug.h"
#include "domain_name_cache.h"
#include "stringtools.h"
#include "rotating_file.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#include "getopt.h"

void show_use( const char *cmd ) 
{
	fprintf(stderr,
		"Use: %s [options]\n"
		"Where options are:\n"
		" -c        Send messages to console.\n"
		" -f <file> Send messages to this file.\n"
		" -s        Limit file to this size.\n"
		" -n        Do not perform reverse name lookups.\n",
		cmd
	);
}

int main( int argc, char *argv[] )
{
	char buffer[DATAGRAM_PAYLOAD_MAX];
	char addr[DATAGRAM_ADDRESS_MAX];
	char name[DOMAIN_NAME_MAX];
	char  c;

	char *debug_file=0;
	int debug_file_size = 65536;

	struct datagram *d;

	int port = DEBUG_PORT;

	int do_name = 1;
	int do_file = 0;
	int do_console = 0;

	while((c=getopt(argc,argv,"cf:s:n"))!=(char)-1) {
		switch(c) {
			case 'c':
				do_console = 1;
				break;
			case 'f':
				do_file = 1;
				debug_file = optarg;
				break;
			case 's':
				debug_file_size = atoi(optarg);
				break;
			case 'n':
				do_name = 0;
				break;
			default:
				show_use(argv[0]);
				exit(1);
				break;
		}
	}

	if(!do_file && !do_console) {
		fprintf(stderr,"You must give at least one of -c and -f.\n");
		exit(1);
	}

	d = datagram_create( port );
	if(!d) {
	       fprintf(stderr,"couldn't listen on port %d: %s\n",port,strerror(errno));
	       return 1;
	}

	sprintf(buffer,"%s started.",argv[0]);
	datagram_send(d,buffer,strlen(buffer),"0.0.0.0",port);

	while(1) {
		char message[DATAGRAM_PAYLOAD_MAX*2];
		int result;
		int length;
		time_t t;

		result = datagram_recv(d,buffer,sizeof(buffer),addr,&port,60);
		if(result<0) continue;

		buffer[result] = 0;
		string_chomp(buffer);

		message[0] = 0;

		time(&t);
		strftime(message,sizeof(message),"%d-%b-%Y %H:%M:%S ", localtime(&t));

		result = domain_name_cache_lookup_reverse(addr,name);
		if(!result) strcpy(name,addr);

		sprintf(&message[strlen(message)],"%s %s\n",name,buffer);
		length = strlen(message);

		if( do_file ) {
			rotating_file_write( debug_file, debug_file_size, message, length );
		}

		if( do_console ) {
			fwrite(message,length,1,stderr);
		}
	}
}
