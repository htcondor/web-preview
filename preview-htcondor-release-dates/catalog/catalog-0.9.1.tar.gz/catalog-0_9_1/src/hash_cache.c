/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "hash_cache.h"
#include "hash_table.h"
#include "list.h"

#include <time.h>
#include <stdlib.h>

struct hash_cache {
	struct hash_table *table;
	hash_cache_cleanup_t cleanup;
	time_t current;
};

struct entry {
	void *value;
	time_t expires;
};

struct hash_cache * hash_cache_create( int size, hash_func_t func, hash_cache_cleanup_t cleanup )
{
	struct hash_cache *cache;

	cache = malloc(sizeof(*cache));
	if(!cache) return 0;

	cache->table = hash_table_create(size,func);
	if(!cache->table) {
		free(cache);
		return 0;
	}

	cache->cleanup = cleanup;

	return cache;
}

void hash_cache_delete( struct hash_cache *cache )
{
	if(cache) {
		if(cache->table) hash_table_delete(cache->table);
		free(cache);
	}
}

int hash_cache_insert( struct hash_cache *cache, const char *key, void *value, int lifetime, int max )
{
	struct entry *e;
	struct list *list;
	int success;

	list = hash_table_lookup(cache->table,key);
	if(!list) {
		list = list_create();
		if(!list) return 0;

		success = hash_table_insert(cache->table,key,list,0);
		if(!success) {
			list_delete(list);
			return 0;
		}
	}

	e = malloc(sizeof(*e));
	if(!e) return 0;

	e->value = value;
	e->expires = time(0)+lifetime;

	if(!list_push_head(list,e)) {
		free(e);
		return 0;
	} else {
		if(max>0) {
			while(list_size(list)>max) {
				cache->cleanup(list_pop_tail(list));
			}
		}
		return 1;
	}
}

void * hash_cache_remove( struct hash_cache *cache, const char *key )
{
	struct entry *e;
	struct list *list;
	void *result;

	list = hash_table_lookup(cache->table,key);
	if(!list) return 0;

	e = list_pop_tail(list);
	if(e) {
		result = e->value;

		if(e->expires<time(0)) {
			cache->cleanup(result);
			result = 0;
		}

		free(e);
	} else {
		result = 0;
	}

	if(!list_size(list)) {
		hash_table_remove(cache->table,key);
		list_delete(list);
	}

	return result;
}

void * hash_cache_lookup( struct hash_cache *cache, const char *key )
{
	struct entry *e;
	struct list *list;

	list = hash_table_lookup(cache->table,key);
	if(!list) return 0;

	e = list_peek_tail(list);
	if(e) {
		if(e->expires<time(0)) {
			list_pop_tail(list);
			cache->cleanup(e->value);
			free(e);
			return 0;
		} else {
			return e->value;
		}
	} else {
		return 0;
	}
}

static int cleanit( struct hash_table *h, char *key, void *value, void *arg )
{
	struct list *list = value;
	struct hash_cache *cache = arg;
	struct entry *e;
	int i;

	for( i=0; i<list_size(list); i++ ) {
		e = list_pop_tail(list);
		if(e->expires<cache->current) {
			cache->cleanup(e->value);
			free(e);
		} else {
			if(!list_push_head(list,e)) {
				cache->cleanup(e->value);
				free(e);
			}
		}
	}

	return 1;
}

int hash_cache_clean( struct hash_cache *cache )
{
	cache->current = time(0);
	return hash_table_iterate(cache->table,cleanit,cache);
}
