/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "link.h"
#include "domain_name.h"
#include "stringtools.h"

#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/time.h>
#include <sys/utsname.h>
#include <sys/un.h>

#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <netdb.h>
#include <errno.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

struct link {
	int fd;
	int read;
	int written;
	time_t last_used;
};

/*
When a link is dropped, we do not want to deal with a signal,
but we want the current system call to abort.  To accomplish this, we
send SIGPIPE to a dummy function instead of just blocking or ignoring it.
*/

static void signal_swallow( int num )
{
}

static int link_squelch()
{
	signal(SIGPIPE,signal_swallow);
	return 1;
}

static int link_nonblocking( struct link *link )
{
	int result;

	result = fcntl(link->fd,F_GETFL);
	if(result<0) return 0;

	result |= O_NONBLOCK;

	result = fcntl(link->fd,F_SETFL,result);
	if(result<0) return 0;

	return 1;
}

static int errno_is_temporary( int e )
{
	if( e==EINTR || e==EWOULDBLOCK || e==EAGAIN || e==EINPROGRESS || e==EALREADY || e==EISCONN ) {
		return 1;
	} else {
		return 0;
	}
}

int link_sleep( struct link *link, int timeout, int reading, int writing )
{
	int result;
	fd_set rfds, wfds;
	struct timeval tm;

	tm.tv_sec = timeout;
	tm.tv_usec = 0;

	FD_ZERO(&rfds);
	if(reading) FD_SET(link->fd,&rfds);

	FD_ZERO(&wfds);
	if(writing) FD_SET(link->fd,&wfds);

	while(1) {
		result = select(link->fd+1,&rfds,&wfds,0,&tm);
		if(result>0) {
			if( reading && FD_ISSET(link->fd,&rfds)) return 1;
			if( writing && FD_ISSET(link->fd,&wfds)) return 1;
		} else if( result==0 ) {
			return 0;
		} else if( errno_is_temporary(errno) ) {
			continue;
		} else {
			return 0;
		}
	}
}

static struct link * link_create()
{
	struct link *link;

	link = malloc(sizeof(*link));
	if(!link) return 0;

	link->read = link->written = 0;
	link->last_used = time(0);
	link->fd = -1;

	return link;
}

struct link * link_serve( int port )
{
	struct link *link=0;
	struct sockaddr_in address;
	int success;
	int on;

	link = link_create();
	if(!link) goto failure;

	link->fd = socket( PF_INET, SOCK_STREAM, 0 );
	if(link->fd<0) goto failure;

	on = 1;
	setsockopt( link->fd, SOL_SOCKET, SO_REUSEADDR, (void*)&on, sizeof(on) );

	if(port!=LINK_PORT_ANY) {
		address.sin_family = AF_INET;
		address.sin_port = htons( port );
		address.sin_addr.s_addr = htonl(INADDR_ANY);

		success = bind( link->fd, (struct sockaddr *) &address, sizeof(address) );
		if(success<0) goto failure;
	}

	success = listen( link->fd, 5 );
	if(success<0) goto failure;

	return link;

	failure:
	if(link) link_close(link);
	return 0;
}

struct link * link_accept( struct link * master )
{
	struct link *link=0;

	link = link_create();
	if(!link) goto failure;

	link->fd = accept(master->fd,0,0);
	if(link->fd<0) goto failure;

	if(!link_nonblocking(link)) goto failure;

	return link;

	failure:
	if(link) link_close(link);
	return 0;
}

struct link * link_connect( const char *addr, int port, int timeout  )
{
	struct sockaddr_in address;
	struct link *link = 0;
	time_t stoptime;
	int result;
	char temp[LINK_ADDRESS_MAX];
	int save_errno;

	link = link_create();
	if(!link) goto failure;

	link_squelch();

	address.sin_family = AF_INET;
	address.sin_port = htons(port);

	if(!string_to_ip_address(addr,(unsigned char *)&address.sin_addr)) goto failure;

	link->fd = socket( AF_INET, SOCK_STREAM, 0 );
	if(link->fd<0) goto failure;

	if(!link_nonblocking(link)) goto failure;

	stoptime = time(0) + timeout;

	do {
		int port;

		result = connect( link->fd, (struct sockaddr *) &address, sizeof(address) );

		/* On some platforms, errno is not set. */
		/* If the remote address can be found, then we are really connected. */

		if( result>=0 ) return link;
		if( !errno_is_temporary(errno) ) break;
		if(link_address_remote(link,temp,&port)) return link;

		link_sleep( link, stoptime-time(0), 0, 1 );

	} while( stoptime>time(0) );

	failure:
	save_errno = errno;
	if(link) link_close(link);
	errno = save_errno;
	return 0;
}

int link_read( struct link *link, char *data, int count, int timeout )
{
	ssize_t total=0;
	ssize_t chunk=0;
	time_t stoptime = time(0)+timeout;

	while( (count>0) && (stoptime>time(0)) ) {
		chunk = read(link->fd,data,count);
		if(chunk<0) {
			if( errno_is_temporary(errno) ) {
				link_sleep( link, stoptime-time(0), 1, 0 );
				continue;
			} else {
				break;
			}
		} else if(chunk==0) {
			break;
		} else {
			total += chunk;
			count -= chunk;
			data += chunk;
		}
	}

	if(total>0) {
		return total;
	} else {
		if(chunk==0) {
			return 0;
		} else {
			return -1;
		}
	}		
}

int link_readline( struct link *link, char *line, int length, int timeout )
{
	time_t stoptime = time(0)+timeout;
	int result;

	while( (length>0) && (stoptime>time(0)) ) {
		result = link_read( link, line, 1, stoptime-time(0) );
		if(result==1) {
			if( *line==10 ) {
				*line = 0;
				return 1;
			} else if( *line==13 ) {
				/* nothing */
			} else {
				line++;
				length--;
			}
		} else {
			return 0;
		}
	}

	return 0;
}



int link_write( struct link *link, const char *data, int count, int timeout )
{
	ssize_t total=0;
	ssize_t chunk=0;
	time_t stoptime = time(0)+timeout;

	while( (count>0) && (stoptime>time(0)) ) {
		chunk = write(link->fd,data,count);
		if(chunk<0) {
			if( errno_is_temporary(errno) ) {
				link_sleep( link, stoptime-time(0), 0, 1 );
				continue;
			} else {
				break;
			}
		} else if(chunk==0) {
			break;
		} else {
			total += chunk;
			count -= chunk;
			data += chunk;
		}
	}

	if(total>0) {
		return total;
	} else {
		if(chunk==0) {
			return 0;
		} else {
			return -1;
		}
	}		
}

void link_close( struct link *link )
{
	if(link) {
		if(link->fd>=0) close(link->fd);
		free(link);
	}
}

int link_fd( struct link *link )
{
	return link->fd;
}

#ifdef __GLIBC__
	#define SOCKLEN_T socklen_t
#else
	#define SOCKLEN_T int
#endif

int link_address_local( struct link *link, char *addr, int *port )
{
	struct sockaddr_in iaddr;
	SOCKLEN_T length;  
	int result;

	length = sizeof(iaddr);
	result = getsockname( link->fd, (struct sockaddr*) &iaddr, &length );
	if(result!=0) return 0;

	string_from_ip_address((unsigned char *)&iaddr.sin_addr,addr);

	return 1;
}

int link_address_remote( struct link *link, char *addr, int *port )
{
	struct sockaddr_in iaddr;
	SOCKLEN_T length;
	int result;

	length = sizeof(iaddr);
	result = getpeername( link->fd, (struct sockaddr*) &iaddr, &length );
	if(result!=0) return 0;

	*port = ntohs(iaddr.sin_port);
	string_from_ip_address((unsigned char *)&iaddr.sin_addr,addr);

	return 1; 
}
