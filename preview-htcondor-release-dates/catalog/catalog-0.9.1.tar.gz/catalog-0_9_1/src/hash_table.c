/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "hash_table.h"

#include <stdlib.h>
#include <string.h>

struct entry {
	char *key;
	void *value;
	struct entry *next;
};

struct hash_table {
	hash_func_t hash_func;
	int bucket_count;
	struct entry **buckets;
};

struct hash_table * hash_table_create( int bucket_count, hash_func_t func )
{
	struct hash_table *h;
	int i;

	h = (struct hash_table*) malloc(sizeof(struct hash_table));
	if(!h) return 0;

	h->hash_func = func;
	h->bucket_count = bucket_count;
	h->buckets = (struct entry**) malloc( sizeof(struct entry*)*bucket_count );
	if(!h->buckets) {
		free(h);
		return 0;
	}

	for( i=0; i<bucket_count; i++ ) {
		h->buckets[i] = 0;
	}

	return h;
}

void hash_table_delete( struct hash_table *h )
{
	struct entry *e, *f;
	int i;

	for( i=0; i<h->bucket_count; i++ ) {
		e = h->buckets[i];
		while(e) {
			f=e->next;
			free(e->key);
			free(e);
			e=f;
		}
	}

	free(h->buckets);
	free(h);
}


void * hash_table_lookup( struct hash_table *h, const char *key )
{
	struct entry *e;
	int index;

	index = h->hash_func(key) % h->bucket_count;
	e = h->buckets[index];

	while(e) {
		if(!strcmp(key,e->key)) {
			return e->value;
		}
		e=e->next;
	}

	return 0;
}

int hash_table_insert( struct hash_table *h, const char *key, const void *value, void **old )
{
	struct entry *e;
	int index;

	if(old) {
		*old = 0;
	}

	index = h->hash_func(key) % h->bucket_count;
	e = h->buckets[index];

	while(e) {
		if(!strcmp(key,e->key)) {
			if(old) {
				*old = e->value;
			}
			e->value = (void*) value;
			return 1;
		}
		e=e->next;
	}

	e = (struct entry*) malloc(sizeof(struct entry));
	if(!e) return 0;

	e->key = strdup(key);
	if(!e->key) {
		free(e);
		return 0;
	}

	e->value = (void*) value;
	e->next = h->buckets[index];
	h->buckets[index] = e;

	return 1;
}

void * hash_table_remove( struct hash_table *h, const char *key )
{
	struct entry *e,*f;
	void *value;
	int index;

	index = h->hash_func(key) % h->bucket_count;
	e = h->buckets[index];
	f = 0;

	while(e) {
		if(!strcmp(key,e->key)) {
			if(f) {
				f->next = e->next;
			} else {
				h->buckets[index] = e->next;
			}
			value = e->value;
			free(e->key);
			free(e);
			return value;
		}
		f = e;
		e = e->next;
	}

	return 0;
}

int hash_table_iterate( struct hash_table *h, hash_table_op_t iterator, void *arg )
{
	int i;
	int items = 0;
	struct entry *e, *f;

	for( i=0; i<h->bucket_count; i++ ) {
		e = h->buckets[i];
		while(e) {
			f = e->next;
			items++;
			if(!iterator(h,e->key,e->value,arg)) {
				return 0;
			}
			e = f;
		}
	}

	return 1;
}

int hash_string( const char *s )
{
	int r=0;

	for( r=0; *s; s++ ) {
		r = r+*s;
	}

	return r;
}

