/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#ifndef STRINGTOOLS_H
#define STRINGTOOLS_H

void   string_from_ip_address( const unsigned char *ip_addr_bytes, char *str );
int    string_to_ip_address( const char * str, unsigned char *ip_addr_bytes );
void   string_chomp( char *str );
int    string_match( const char *pattern, const char *text );
char * string_front( const char *str, int max );
const char * string_back( const char *str, int max );
void   string_metric( int invalue, int power_needed, char *buffer );
int    string_split( char *str, int *argc, char ***argv );
char * string_pad_right( char *str, int length );
char * string_pad_left( char *str, int length );
char * string_cookie( int length );
 
#endif
