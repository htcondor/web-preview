/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <signal.h>

#include "debug.h"
#include "domain_name_cache.h"
#include "rotating_file.h"
#include "datagram.h"
#include "macros.h"

static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

static int debug_to_console = 0;
static char *debug_file = 0;
static int debug_file_size = 65536;
static char debug_addr[DATAGRAM_ADDRESS_MAX];
static struct datagram *debug_port=0;
static char *program_name = "";

static void do_debug( int is_fatal, char *fmt, va_list args )
{
	char buffer[DATAGRAM_PAYLOAD_MAX];
	int length;

	sprintf(buffer,"%s [%d] ",program_name,(int)getpid());
	if(is_fatal) strcat(buffer,"FATAL ");

	vsprintf(&buffer[strlen(buffer)],fmt,args);
	strcat(buffer,"\n");
	length = strlen(buffer);

	pthread_mutex_lock(&mutex);

	if(debug_file) {
		rotating_file_write(debug_file,debug_file_size,buffer,length);
	}

	if(debug_port) {
		datagram_send(debug_port,buffer,length,debug_addr,DEBUG_PORT);
	}

	if(debug_to_console) {
		fwrite(buffer,length,1,stderr);
		fflush(stderr);
	}

	pthread_mutex_unlock(&mutex);
}

void debug( char *fmt, ... )
{
	va_list args;
	va_start(args,fmt);

	if(debug_to_console || debug_file || debug_port) {
		do_debug(0,fmt,args);
	}

	va_end(args);
}

void fatal( char *fmt, ... ) 
{
	va_list args;
	va_start(args,fmt);

	debug_config_console(1);
	do_debug(1,fmt,args);

	kill(getpid(),SIGKILL);

	va_end(args);
}

void debug_config( char *name )
{
	char *console = getenv("DEBUG_TO_CONSOLE");
	char *host = getenv("DEBUG_TO_HOST");
	char *file = getenv("DEBUG_TO_FILE");
	char *filesize = getenv("DEBUG_TO_FILE_SIZE");

	program_name = strrchr(name,'/');
	if(program_name) {
		program_name++;
	} else {
		program_name = name;
	}

	if(console) debug_config_console(1);
	if(host) debug_config_host(host);
	if(file) debug_config_file(file);
	if(filesize) debug_config_file_size(atoi(filesize));
}

void debug_config_console( int onoff )
{
	debug_to_console = onoff;
}

void debug_config_file( const char *f )
{
	pthread_mutex_lock(&mutex);

	if(debug_file) {
		free(debug_file);
		debug_file = 0;
	}

	if(f) {
		debug_file = strdup(f);
	}

	pthread_mutex_unlock(&mutex);
}

void debug_config_file_size( int size )
{
	debug_file_size = size;
}

int debug_config_host( const char *host )
{
	char addr[DATAGRAM_ADDRESS_MAX];

	if(host) {
		if(!domain_name_cache_lookup(host,addr)) return 0;

		pthread_mutex_lock(&mutex);
		strcpy(debug_addr,addr);
		if(!debug_port) debug_port = datagram_create(DATAGRAM_PORT_ANY);
		pthread_mutex_unlock(&mutex);

		return debug_port!=0;

	} else {
		pthread_mutex_lock(&mutex);
		if(debug_port) {
			datagram_delete(debug_port);
			debug_port = 0;
		}
		pthread_mutex_unlock(&mutex);

		return 1;
	}
}


