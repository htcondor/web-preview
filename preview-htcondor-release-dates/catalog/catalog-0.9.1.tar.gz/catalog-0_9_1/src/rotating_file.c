/*
dttools is Copyright (C) 2002 Douglas Thain
This software is released under the GNU General Public License.
See the file COPYING for details.
*/


#include "rotating_file.h"
#include "macros.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>
#include <alloca.h>

#define BUFFER_SIZE 1024

int rotating_file_vprintf( const char *path, int maxsize, const char *fmt, va_list args )
{
	char buffer[BUFFER_SIZE];
	int length;

	length = vsnprintf(buffer,BUFFER_SIZE,fmt,args);
	buffer[BUFFER_SIZE-1] = 0;
	length = MIN(length,BUFFER_SIZE-1);

	return rotating_file_write(path,maxsize,buffer,length);
}

int rotating_file_write( const char *path, int maxsize, const char *data, int length )
{
	FILE *file;
	long size;

	file = fopen(path,"a");
	if(!file) return 0;

	fwrite(data,1,length,file);

	if(maxsize!=0) {
		size = ftell(file);
		if( size > maxsize ) {
			char *newname = alloca(strlen(path)+5);
			sprintf(newname,"%s.old",path);
			rename(path,newname);
		}
	}

	fclose(file);
	return 1;
}


