Download the related version source code

Process for compiling 

1. Compile on RHEL 5.0/5.1/5.2 or equivalent CentOS only
2. Install byacc, flex, autoconf, automake rpm's
3. Install bison-devel # for gsoap to compile
4. Install ncurses-devel
5. ./build_init
6. export LIBS=" -lncurses" # for krb5 telnet programs to compile
7. ./configure --prefix=/opt/condor-7.2.0 --without-blahp 
		# without BLAHP we will miss only scheduling to PBS/Torque, which we do not need anyways
8. make

from second compile 
	do a make in the respective sub folders and copy the executable to the bin/sbin locations.