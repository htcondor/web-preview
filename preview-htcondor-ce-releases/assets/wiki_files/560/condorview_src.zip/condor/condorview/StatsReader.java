// StatsReader: a thread which reads statistics from a StatsStreamTokenizer.
//
// this is in a separate thread so it does not halt the display
// of the applet.
//
// currently only stored numeric data -- string data (apart
// from group names) is ignored.
//
// data/param combos do not have to persist through the file;
// if they are missing, their vector will be padded with 0s
// appropriately.
//
// -- jmason@iona.com '96.
//
// (c) 1996, Justin Mason <jmason@iona.com>.
// This software is free software. You may use it as you see fit, including
// altering the source and so on, but the existing copyright notices must be
// retained intact in the source code, and the About box and copyright notice
// therein must remain intact and accessible by the user. Additional notices,
// to copyright your own modifications, may be added.

package condor.condorview;
import condor.condorview.StatsStreamTokenizer;

import java.lang.Thread;

import java.util.Date;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.NoSuchElementException;

import java.io.InputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

//======================================================================

class StatsReader extends Thread {
    public final static boolean DEBUG = false;
    public final static boolean MOREDEBUG = false;
    public final static int DATASEP = '\"';
    private StatsStreamTokenizer SS;
    private Hashtable lastUpdateH, maxValueH;
    private Hashtable groupH, paramH;
    private boolean stoppedReading = false;

    public int linesRead = 0, size = 0;
    public int numGroups = 0, numParams = 0, memorySize = 0;
    public Hashtable data;
    public Vector dates, groups, params;

    public boolean broken = false;
    public Exception brokenException;

    public StatsReader (InputStream is) {
	this (is, false, 0);
    }
    public StatsReader (InputStream is, boolean usDateFmt) {
	this (is, usDateFmt, 0);
    }
    public StatsReader (InputStream is, boolean usDateFmt, int memsize) {
	super ("StatsReader");
	try {
	    SS = new StatsStreamTokenizer (is, usDateFmt);
	} catch (Exception ex) {
	    Break(ex);
	    return;
	}
	if (memsize > 0) {
	    memorySize = memsize;
	}
	if (DEBUG) { System.out.println("stats ctor"); }
    }

    public void run () {
	dates = new Vector();
	params = new Vector();
	groups = new Vector();
	groupH = new Hashtable(10);
	paramH = new Hashtable(10);
	lastUpdateH = new Hashtable(10);
	maxValueH = new Hashtable(10);
	data = new Hashtable(10);
	linesRead = size = numGroups = numParams = 0;

	if (DEBUG) { System.out.println("stats run"); }
	try {
	while (SS.nextDataSet()) {
	    boolean moreGroups;
        String gName;

	    dates.addElement (SS.date);
	    do {
    		try {
    		    moreGroups = SS.nextGroup();
    		} catch (Exception ex) {
	            Break(ex);
                return;
    		}

    		if (SS.groupName == null) {
    		    gName = "(unknown)";
    		} else {
    		    gName = SS.groupName;
    		}

    		Enumeration e = SS.nums.keys();
    		while (e.hasMoreElements()) {
    		    String pName, gAndP;
    		    Object value;

    		    try {
    		        pName = (String) e.nextElement();
    			value = SS.nums.get(pName);
    			// minimise hashtable lookups by using
    			// groupName and paramName together as the key.
    			gAndP = gName+DATASEP+pName;
    		    } catch (Exception ex) {
    		        continue;
    		    }
    		    try {
    			Vector v = (Vector) data.get(gAndP);
    			// no exception? good, it already exists.
    			v.addElement(value);
    			if (MOREDEBUG) {
    			    System.out.println("stats add: "+
    			                    gAndP+": "+((Float)value));
    			}
    			updateMaxValue(gName, value);
    		        lastUpdateH.put(gAndP, SS.date);

    		    } catch (NullPointerException ex) {
    			// create the new group, param, or both
    		        try { if (groupH.get (gName) == null) {
    			    newGroup (gName);
    			} } catch (NullPointerException nex) {
    			    newGroup (gName);
    		        }
    		        try { if (paramH.get (pName) == null) {
    			    newParam (pName);
    			} } catch (NullPointerException nex) {
    			    newParam (pName);
    		        }

      			// create the data vector, and pad it
    			// with 0s up until this point.
    		    Vector v = new Vector();
    			for (int i=0; i<size; i++) {
    			    v.addElement (new Float(0.0));
    			}
    		    v.addElement (value);
    		    data.put (gAndP, v);

    			if (MOREDEBUG) {
    			    System.out.println("stats new: "+
    			    	gAndP+": "+((Float)value));
    			}
    		        lastUpdateH.put (gAndP, SS.date);
    			updateMaxValue(gName, value);
    		    }
    		}
	    } while (moreGroups);

	    // zero out the non-updated ones.
	    Enumeration e = data.keys();
	    while (e.hasMoreElements()) {
    		String gAndP;
    		try {
    		    gAndP = (String) e.nextElement();
    		    if (lastUpdateH.get(gAndP) != SS.date) {
    			Vector v = (Vector) data.get(gAndP);
    		        v.addElement(new Float(0.0));
    		    }
    		} catch (NoSuchElementException ex) { }
	    }

	    // linesRead is different from size in that size is trimmed
	    // down by forgetFirstPoint().
	    //
	    size++; linesRead++;
	    if (memorySize > 0 && size > memorySize) {
		forgetFirstPoint();
	    }
	    yield();		// give display thread a chance
	}
	} catch (Exception ex) {
	    Break(ex);
	    return;
	}

	if (DEBUG) { System.out.println("stats finished."); }
	stoppedReading = true;
    }

    private synchronized void Break (Exception ex) {
        //System.err.println ("Reader broke with: "+ex);
        brokenException = ex;
        stoppedReading = broken = true;
    }

    private void newParam (String name) {
	paramH.put (name, Boolean.TRUE);
	params.addElement (name);
	numParams++;
	if (DEBUG) { System.out.println("stats: new param " + name); }
    }

    private void newGroup (String name) {
	groupH.put (name, Boolean.TRUE);
	groups.addElement (name);
	numGroups++;
	if (DEBUG) { System.out.println("stats: new group " + name); }
    }

    private void updateMaxValue (String groupname, Object val) {
	try {
	    float f = ((Float) maxValueH.get(groupname)).floatValue();
	    float g = ((Float) val).floatValue();
	    if (f < g) { maxValueH.put (groupname, val); }
	} catch (Exception ex) {
	    maxValueH.put (groupname, val);
	}
    }

    private synchronized void forgetFirstPoint () {
	try {
	    for (int i = groups.size() - 1; i >= 0; i--) {
		String gName = (String) groups.elementAt (i);
		for (int j = params.size() - 1; j >= 0; j--) {
		    String pName = (String) params.elementAt (j);
		    if (DEBUG) { System.out.println("stats: removing first " +
					"element from "+gName+"/"+pName); }

		    ((Vector) data.get(gName+DATASEP+pName)).removeElementAt (0);
		}
	    }
	} catch (Exception ex) {
	    System.err.println ("foo! screwed up forgetFirstPoint: "+ex);
        }
	dates.removeElementAt (0);
	size--;
    }

    //------------------------------------------------------------------

    public synchronized Date startTime () {
	try {
	    if (size > 0) {
		return (Date) (dates.elementAt (0));
	    } else {
		return null;
	    }
	} catch (ArrayIndexOutOfBoundsException ex) {
	    return null;
	}
    }

    public synchronized Date endTime () {
	if (size > 0) {
	    return (Date) (dates.elementAt (size - 1));
	} else {
	    return null;
	}
    }

    public Vector getDataVector (String group, String param) {
	String gAndP = group+DATASEP+param;
	return ((Vector) data.get (gAndP));
    }

    public synchronized boolean isValidGroup (String gName) {
	try {
	    return groupH.containsKey (gName);
	} catch (Exception ex) {
	    return false;
	}
    }

    public synchronized boolean isValidParam (String pName) {
	try {
	    return paramH.containsKey (pName);
	} catch (Exception ex) {
	    return false;
	}
    }

    public synchronized boolean initializedGroups () {
        return (size > 0 && numGroups > 0 && numParams > 0);
    }

    public synchronized boolean stoppedReading () {
	    return stoppedReading;
    }

    // sortedGroups -- sort the groups by the maximum value
    // of their parameters. use a crappy bubble sort 'cos
    // there's only a few elements (ie. < 20 usually!)
    //
    public synchronized Vector sortedGroups () {
        Vector sorted = new Vector(groups.size());
        Vector gcopy = (Vector) groups.clone();

        while (gcopy.size() > 1) {
            float hi = Float.NEGATIVE_INFINITY;
            String hiGrp = null;
            int i, hiIdx = -1;

            for (i = gcopy.size() - 1; i >= 0; i--) {
                String grp = (String) gcopy.elementAt(i);
                float f = ((Float) maxValueH.get(grp)).floatValue();
                if (f > hi) { hi = f; hiIdx = i; hiGrp = grp; }
            }
            sorted.addElement (hiGrp);
            gcopy.removeElementAt (hiIdx);
        }
        sorted.addElement (gcopy.elementAt(0));
        return (sorted);
    }

    //------------------------------------------------------------------

    public synchronized String toString () {
	try {
	    return ("StatsReader[from "+
		startTime().toString()+" to "+endTime().toString()+
		"; graphable groups: "+groups.toString()+
		"; graphable params: "+params.toString()+ "]");

	} catch (Exception ex) {
	    return ("StatsReader[unread]");
	}
    }
}
