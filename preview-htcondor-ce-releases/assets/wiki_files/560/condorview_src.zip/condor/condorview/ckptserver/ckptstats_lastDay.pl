#!/usr/bin/perl

require "timelocal.pl";

use Socket;

$interval = 900;		# 15 minute record intervals
$date_window = 86400;		# last day

$first_period = 0;
$last_period = 0;

$start_time = $^T-$date_window;
($start_mday,$start_mon,$start_year) = (localtime($start_time))[3,4,5];
($end_mday,$end_mon,$end_year) = (localtime($^T))[3,4,5];
$start_mon++;
$end_mon++;

$STATFILE = ">" . shift(@ARGV);
$HTMLFILE = ">" . shift(@ARGV);

open(STATFILE) || die;
open(HTMLFILE) || die;

while (<>) {

    ($month, $day) = /^(\d+)\/(\d+)/;

#    print $month, " ", $mon, " ", $day, " ", $mday, "\n";
    next if ($month != $start_mon && $month != $end_mon);
    next if ($month == $start_mon && $day < $start_mday);

    ($month, $day, $hour, $minute, $type, $success, $size, $endpoint, $user) =
	/^(\d+)\/(\d+) (\d+):(\d+):\d+ (\w) (\w) ([-\d]+) \w+ \d+ \w+ ([\d\.]+) ([\w\.\@]+)/;

    $recordtime = timelocal(0,$minute,$hour,$day,$month-1,$start_year)
	if ($month == $start_mon);
    $recordtime = timelocal(0,$minute,$hour,$day,$month-1,$end_year)
	if ($month == $end_mon);

    next if ($recordtime < $start_time);

    $period = int($recordtime/$interval);
    $first_period = $period if ($first_period == 0);

    $endpoint =~ m/(^\d+\.\d+\.\d+)/;
    $endpoint = $1;
#    print $endpoint, "\n";

    $userlist{$user} = 0;
    $netlist{$endpoint} = 0;
    if ($type eq "S" && $success eq "S") {
	$num_successful_sends{$period}{$user}++;
	$bytes_sent{$period}{$user} += $size;
	$num_successful_sends{$period}{"Total"}++;
	$bytes_sent{$period}{"Total"} += $size;
	$num_successful_sends{$user}++;
	$bytes_sent{$user} += $size;
	$min_size{$user} = $size if (!defined($max_size{$user}) ||
				     $size < $min_size{$user});
	$max_size{$user} = $size if (!defined($max_size{$user}) ||
				     $size > $max_size{$user});
	$num_successful_sends{$endpoint}++;
	$bytes_sent{$endpoint} += $size;
	$num_successful_sends{"Total"}++;
	$bytes_sent{"Total"} += $size;
	$min_size{"Total"} = $size if (!defined($max_size{"Total"}) ||
				     $size < $min_size{"Total"});
	$max_size{"Total"} = $size if (!defined($max_size{"Total"}) ||
				     $size > $max_size{"Total"});
    } elsif ($type eq "R" && $success eq "S") {
	$num_successful_recvs{$period}{$user}++;
	$bytes_recvd{$period}{$user} += $size;
	$num_successful_recvs{$period}{"Total"}++;
	$bytes_recvd{$period}{"Total"} += $size;
	$num_successful_recvs{$user}++;
	$bytes_recvd{$user} += $size;
	$min_size{$user} = $size if (!defined($max_size{$user}) ||
				     $size < $min_size{$user});
	$max_size{$user} = $size if (!defined($max_size{$user}) ||
				     $size > $max_size{$user});
	$num_successful_recvs{$endpoint}++;
	$bytes_recvd{$endpoint} += $size;
	$num_successful_recvs{"Total"}++;
	$bytes_recvd{"Total"} += $size;
	$min_size{"Total"} = $size if (!defined($max_size{"Total"}) ||
				     $size < $min_size{"Total"});
	$max_size{"Total"} = $size if (!defined($max_size{"Total"}) ||
				     $size > $max_size{"Total"});
    } elsif ($type eq "S" && $success eq "F") {
	$num_failed_sends{$period}{$user}++;
	$num_failed_sends{$period}{"Total"}++;
	$num_failed_sends{$user}++;
	$num_failed_sends{$endpoint}++;
	$num_failed_sends{"Total"}++;
    } elsif ($type eq "R" && $success eq "F") {
	$num_failed_recvs{$period}{$user}++;
	$num_failed_recvs{$period}{"Total"}++;
	$num_failed_recvs{$user}++;
	$num_failed_recvs{$endpoint}++;
	$num_failed_recvs{"Total"}++;
    } 
}

$last_period = $period;

@users = sort keys %userlist;

sub byaddr {
    ($a1, $a2, $a3) = split(/\./, $a);
    ($b1, $b2, $b3) = split(/\./, $b);
    $a_addr = ($a1<<16)+($a2<<8)+$a3;
    $b_addr = ($b1<<16)+($b2<<8)+$b3;
    $a_addr <=> $b_addr;
}
@nets = sort byaddr keys %netlist;

print HTMLFILE "<table border=0 cellspacing=2 cellpadding=2 width=90%>\n";
print HTMLFILE "<tr>\n";
print HTMLFILE "<td><b>User</b></td>\n";
print HTMLFILE "<td align=center><b>Total RestartData</b></td>\n";
print HTMLFILE "<td align=center><b>Total CheckpointData</b></td>\n";
print HTMLFILE "<td align=center><b>Checkpoint Sizes</b></td>\n";
print HTMLFILE "<td align=center><b>Total Restarts</b></td>\n";
print HTMLFILE "<td align=center><b>Total Checkpoints</b></td>\n";
print HTMLFILE "<td align=center><b>Total FailedRestarts</b></td>\n";
print HTMLFILE "<td align=center><b>Total FailedCheckpoints</b></td>\n";
print HTMLFILE "</tr>\n";

print STATFILE "FORMAT Total RestartData CheckpointData Restarts Checkpoints FailedRestarts FailedCheckpoints";
print HTMLFILE "<tr bgcolor=#DDDDDD><td><b>Total</b></td>",
    	"<td align=center>", int($bytes_sent{"Total"}/1024/1024), "</td>",
    	"<td align=center>", int($bytes_recvd{"Total"}/1024/1024), "</td>",
    	"<td align=center>", int($min_size{"Total"}/1024/1024), "-",
    		int($max_size{"Total"}/1024/1024), "</td>",
    	"<td align=center>", int($num_successful_sends{"Total"}), "</td>",
    	"<td align=center>", int($num_successful_recvs{"Total"}), "</td>",
    	"<td align=center>", int($num_failed_sends{"Total"}), "</td>",
    	"<td align=center>", int($num_failed_recvs{"Total"}), "</td>",
    	"</tr>\n";
foreach $user (@users) {
    @user = split('@', $user);
    $user_length = @user;
    $username = shift(@user);
    $addr = pop(@user);
    if ($user_length == 2) {
	$hostname = (gethostbyaddr(Socket::inet_aton($addr),AF_INET))[0];
	$hostname = $addr if ($hostname eq "");
    } else {
	$hostname = join('@', @user);
    }
    print STATFILE " ", $username, "@", $hostname,
    	" RestartData CheckpointData Restarts Checkpoints FailedRestarts FailedCheckpoints";
    print HTMLFILE "<tr";
    $shadecount++;
    print HTMLFILE " bgcolor=#DDDDDD" if ($shadecount % 2 < 0.5);
    print HTMLFILE "><td><b>", $username, "</b><br><font size=-1>", $hostname,
    	"</font></td>",
    	"<td align=center>", int($bytes_sent{$user}/1024/1024), "</td>",
    	"<td align=center>", int($bytes_recvd{$user}/1024/1024), "</td>",
    	"<td align=center>", int($min_size{$user}/1024/1024), "-",
    		int($max_size{$user}/1024/1024), "</td>",
    	"<td align=center>", int($num_successful_sends{$user}), "</td>",
    	"<td align=center>", int($num_successful_recvs{$user}), "</td>",
    	"<td align=center>", int($num_failed_sends{$user}), "</td>",
    	"<td align=center>", int($num_failed_recvs{$user}), "</td>",
    	"</tr>\n";
}
print STATFILE "\n";
print HTMLFILE "</table>\n";

for ($period = $first_period;
     $period <= $last_period;
     $period++) {
    $time = $period*$interval;
    print STATFILE $time, " ",
	int($bytes_sent{$period}{"Total"}/1024/1024), ",",
    	int($bytes_recvd{$period}{"Total"}/1024/1024), ",",
    	int($num_successful_sends{$period}{"Total"}), ",",
    	int($num_successful_recvs{$period}{"Total"}), ",",
	int($num_failed_sends{$period}{"Total"}), ",",
	int($num_failed_recvs{$period}{"Total"});
    foreach $user (@users) {
	print STATFILE " ", int($bytes_sent{$period}{$user}/1024/1024), ",",
		int($bytes_recvd{$period}{$user}/1024/1024), ",",
    		int($num_successful_sends{$period}{$user}), ",",
    		int($num_successful_recvs{$period}{$user}), ",",
		int($num_failed_sends{$period}{$user}), ",",
		int($num_failed_recvs{$period}{$user});
    }
    print STATFILE "\n";
}

print HTMLFILE "<p>\n";
print HTMLFILE "<table border=0 cellspacing=2 cellpadding=2 width=90%>\n";
print HTMLFILE "<tr>\n";
print HTMLFILE "<td><b>Subnet</b></td>\n";
print HTMLFILE "<td align=center><b>Total RestartData</b></td>\n";
print HTMLFILE "<td align=center><b>Total CheckpointData</b></td>\n";
print HTMLFILE "<td align=center><b>Total Restarts</b></td>\n";
print HTMLFILE "<td align=center><b>Total Checkpoints</b></td>\n";
print HTMLFILE "<td align=center><b>Total FailedRestarts</b></td>\n";
print HTMLFILE "<td align=center><b>Total FailedCheckpoints</b></td>\n";
print HTMLFILE "</tr>\n";

$shadecount = 1;
foreach $endpoint (@nets) {
    print HTMLFILE "<tr";
    $shadecount++;
    print HTMLFILE " bgcolor=#DDDDDD" if ($shadecount % 2 < 0.5);
    print HTMLFILE "><td><b>", $endpoint, "</b>",
    	"<td align=center>", int($bytes_sent{$endpoint}/1024/1024), "</td>",
    	"<td align=center>", int($bytes_recvd{$endpoint}/1024/1024), "</td>",
    	"<td align=center>", int($num_successful_sends{$endpoint}), "</td>",
    	"<td align=center>", int($num_successful_recvs{$endpoint}), "</td>",
    	"<td align=center>", int($num_failed_sends{$endpoint}), "</td>",
    	"<td align=center>", int($num_failed_recvs{$endpoint}), "</td>",
    	"</tr>\n";
}
print HTMLFILE "</table>\n";
