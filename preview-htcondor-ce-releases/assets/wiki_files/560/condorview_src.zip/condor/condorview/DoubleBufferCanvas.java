//******************************************************************************
// class oblivion.awt.DoubleBufferCanvas
// Copyright (c) 1998 Christopher E. Weaver. All rights reserved.
//******************************************************************************
// File: DoubleBufferCanvas.java
// Last modified: Thu Sep 24 13:24:56 1998 by Chris Weaver
//******************************************************************************
// Modification History:
//
// 980430 [weaver]: Original file.
//
//******************************************************************************
//
// Deprecated. (Even-better double-buffer.)
//
// Todd - extend this and override draw(). Should work as is.
//
//******************************************************************************

package condor.condorview;


// import java.lang.*;
import java.awt.*;

//******************************************************************************
// class DoubleBufferCanvas
//******************************************************************************

/**
 * The <CODE>DoubleBufferCanvas</CODE> class.
 *
 * @author  Chris Weaver
 * @version %I%, %G%
 */
public abstract class DoubleBufferCanvas extends Canvas
{
	//**********************************************************************
    // Private Members
    //**********************************************************************

	// State (internal) variables
	private Image		offscreen;				// Double buffer

	//**********************************************************************
    // Public Methods
    //**********************************************************************

    public abstract void    draw(Graphics g);

	//**********************************************************************
    // Override Methods (Component)
    //**********************************************************************

	public void		update(Graphics g)
	{
		paint(g);
	}

	public void		paint(Graphics g)
	{
		// int		w = getSize().width;
		// int		h = getSize().height;
		int		w = size().width;
		int		h = size().height;


		if ((w == 0) || (h == 0))
		{
			draw(g);
			return;
		}

		boolean		sizeChanged = false;

		if (offscreen == null)
			offscreen = createImage(w, h);

		if ((offscreen.getWidth(this) < w) || (offscreen.getHeight(this) < h))
		{
			offscreen = createImage(w, h);
			sizeChanged = true;
		}

		Graphics	og = offscreen.getGraphics();
		// Rectangle	r = g.getClipBounds();
		Rectangle	r = g.getClipRect();

		//og.setClip(g.getClip());
		Rectangle ogr = og.getClipRect();
		og.clipRect(r.x, r.y, r.width, r.height);

		if (!sizeChanged)
			og.clearRect(r.x, r.y, r.width, r.height);

		draw(og);
		g.drawImage(offscreen, 0, 0, null);
		og.dispose();
	}
}

