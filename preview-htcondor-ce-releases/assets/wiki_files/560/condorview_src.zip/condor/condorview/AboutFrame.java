// AboutFrame: About window for TimeGraph. Also doubles as the
// error Frame. ;)
//
// (c) 1996, Justin Mason <jmason@iona.com>.
// This software is free software. You may use it as you see fit, including
// altering the source and so on, but the existing copyright notices must be
// retained intact in the source code, and the About box and copyright notice
// therein must remain intact and accessible by the user. Additional notices,
// to copyright your own modifications, may be added.

package condor.condorview;
import java.awt.*;

public class AboutFrame extends Frame {
    protected TimeGraph graph;
    Button Bclose;
    TextArea Text;
    boolean isAbout;

    public AboutFrame (String title, String text, TimeGraph g)
    {
	super (title);
	Bclose = new Button ("Close");
	Text = new TextArea (text); Text.setEditable (false);
	graph = g;

	//--------------------------------------------------

	GridBagLayout gb = new GridBagLayout();
	this.setLayout (gb);

	int line;
	GridBagConstraints c = new GridBagConstraints();

	c.gridx =     0;        c.gridy =      0;
	c.gridwidth = 1;        c.gridheight = 1;
	c.fill =      c.HORIZONTAL; c.anchor = c.NORTH;
	c.weightx =   0.0;      c.weighty =    1.0;
	c.insets = new Insets (5, 2, 1, 2);
	gb.setConstraints (Text, c);
	this.add (Text);

	c.gridx =     0;        c.gridy =      1;
	c.gridwidth = 1;        c.gridheight = 1;
	c.fill =      c.HORIZONTAL; c.anchor = c.SOUTH;
	c.weightx =   0.0;      c.weighty =    0.1;
	c.insets = new Insets (5, 2, 1, 2);
	gb.setConstraints (Bclose, c);
	this.add (Bclose);

	this.pack();
	this.show();
    }

    //------------------------------------------------------------------
    // make the default Enter action be to close the window

    public boolean gotFocus (Event event, Object arg) {
	Bclose.requestFocus();
	return true;
    }

    //------------------------------------------------------------------

    public boolean action (Event event, Object arg) {
	if (event.target == Bclose) {
	    this.hide(); this.dispose();
	    if (graph != null) { graph.aboutFrameHidden = true; }
	    return true;
	}
	return (boolean) super.action (event, arg);
    }

    public boolean handleEvent (Event evt) {
        if (evt.target == this && evt.id == Event.WINDOW_DESTROY) {
	    this.hide(); this.dispose();
	    if (graph != null) { graph.aboutFrameHidden = true; }
            return true;
        }

        return super.handleEvent (evt);
    }
}
