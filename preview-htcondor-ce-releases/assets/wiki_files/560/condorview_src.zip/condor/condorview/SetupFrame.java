// SetupFrame: Configure window for TimeGraph
//
// (c) 1996, Justin Mason <jmason@iona.com>.
// This software is free software. You may use it as you see fit, including
// altering the source and so on, but the existing copyright notices must be
// retained intact in the source code, and the About box and copyright notice
// therein must remain intact and accessible by the user. Additional notices,
// to copyright your own modifications, may be added.

package condor.condorview;
import condor.condorview.ColourButton;
import java.awt.*;

public class SetupFrame extends Frame {
    protected TimeGraph graph;
    protected int numGraphs;
    Choice Cgroup[], Cparam[], Cscale[], Cflags[];
    ColourButton Bcolor[];
    Button Bclose;

    public SetupFrame (String title, TimeGraph g) {
	super (title);
	graph = g;
	numGraphs = g.numGraphs;

	Bcolor = new ColourButton[numGraphs];
	Cgroup = new Choice[numGraphs];
	Cparam = new Choice[numGraphs];
	Cscale = new Choice[numGraphs];
	Cflags = new Choice[numGraphs];
	Bclose = new Button ("Close");

	int i;

        for (i = 0; i < numGraphs; i++) {
            Bcolor[i] = new ColourButton(graph.Ccolor[i]);

            Cgroup[i] = new Choice(); Cgroup[i].addItem ("(unused)");
            for (int j = 0; j < graph.stats.groups.size(); j++) {
                Cgroup[i].addItem((String) graph.stats.groups.elementAt(j));
            }

            Cparam[i] = new Choice();
            for (int j = 0; j < graph.stats.params.size(); j++) {
                Cparam[i].addItem((String) graph.stats.params.elementAt(j));
            }

            Cscale[i] = new Choice();
            for (int j = 1; j <= 1000; j *= 10) {
                Integer jInt = new Integer(j);
                Cscale[i].addItem (jInt.toString()); // separate copies
            }

	    Cgroup[i].select (graph.canvas.group[i]);
	    Cparam[i].select (graph.canvas.param[i]);
	    Cscale[i].select (graph.canvas.scale[i]);

	    Cflags[i] = new Choice();
	    Cflags[i].addItem("plain");
	    Cflags[i].addItem("deltas");

	    if ((graph.canvas.flags[i] & graph.canvas.DELTA) != 0) {
	        Cflags[i].select ("deltas");
	    } else {
	        Cflags[i].select ("plain");
	    }
        }

	//--------------------------------------------------

	GridBagLayout gb = new GridBagLayout();
	this.setLayout (gb);

	int line;
	GridBagConstraints c = new GridBagConstraints();

        for (line = 0; line < numGraphs; line++) {
	    c.gridx =     0;        c.gridy =      line;
	    c.gridwidth = 1;        c.gridheight = 1;
	    c.fill =      c.BOTH;   c.anchor = c.CENTER;
	    c.weightx =   0.0;      c.weighty =    0.0;
	    c.insets = new Insets (3, 4, 3, 2);
	    gb.setConstraints (Bcolor[line], c);
	    this.add (Bcolor[line]);

	    c.gridx =     1;        c.gridy =      line;
	    c.gridwidth = 1;        c.gridheight = 1;
	    c.fill =      c.NONE;   c.anchor = c.CENTER;
	    c.weightx =   0.0;      c.weighty =    0.0;
	    c.insets = new Insets (1, 2, 1, 2);
	    gb.setConstraints (Cgroup[line], c);
	    this.add (Cgroup[line]);

	    c.gridx =     2;        c.gridy =      line;
	    c.gridwidth = 1;        c.gridheight = 1;
	    c.fill =      c.NONE;   c.anchor = c.CENTER;
	    c.weightx =   0.0;      c.weighty =    0.0;
	    c.insets = new Insets (1, 2, 1, 2);
	    gb.setConstraints (Cparam[line], c);
	    this.add (Cparam[line]);

	    c.gridx =     3;        c.gridy =      line;
	    c.gridwidth = 1;        c.gridheight = 1;
	    c.fill =      c.NONE;   c.anchor = c.CENTER;
	    c.weightx =   0.0;      c.weighty =    0.0;
	    c.insets = new Insets (1, 2, 1, 4);
	    gb.setConstraints (Cscale[line], c);
	    this.add (Cscale[line]);

	    c.gridx =     4;        c.gridy =      line;
	    c.gridwidth = 1;        c.gridheight = 1;
	    c.fill =      c.NONE;   c.anchor = c.CENTER;
	    c.weightx =   0.0;      c.weighty =    0.0;
	    c.insets = new Insets (1, 2, 1, 4);
	    gb.setConstraints (Cflags[line], c);
	    this.add (Cflags[line]);
        }

	c.gridx =     0;        c.gridy =      line;
	c.gridwidth = 5;        c.gridheight = 1;
	c.fill =      c.HORIZONTAL; c.anchor = c.CENTER;
	c.weightx =   0.0;      c.weighty =    0.0;
	c.insets = new Insets (5, 2, 1, 2);
	gb.setConstraints (Bclose, c);
	this.add (Bclose);

	this.pack();
	this.show();
    }

    //------------------------------------------------------------------

    public boolean action (Event event, Object arg) {
        if (event.target instanceof Choice) {
            for (int i = 0; i < numGraphs; i++) {
                if (event.target == Cgroup[i]) {
                    graph.canvas.group[i] = (String)
		   		Cgroup[i].getSelectedItem();
                    graph.canvas.repaint();
		    return true;

                } else if (event.target == Cparam[i]) {
                    graph.canvas.param[i] = (String)
		    		Cparam[i].getSelectedItem();
                    graph.canvas.repaint();
		    return true;

                } else if (event.target == Cscale[i]) {
                    graph.canvas.scale[i] = (String)
		    		Cscale[i].getSelectedItem();
                    graph.canvas.repaint();
		    return true;

                } else if (event.target == Cflags[i]) {
                    String s = Cflags[i].getSelectedItem();
                    if (s.equals("deltas")) {
                        graph.canvas.flags[i]|=graph.canvas.DELTA;
                    } else {
                        graph.canvas.flags[i]=0;
                    }
                    graph.canvas.repaint();
		    return true;
                }
            }

        } else if (event.target instanceof Button) {
	    if (event.target == Bclose) {
		this.hide(); this.dispose();
		graph.setupFrameHidden = true;
		return true;
	    }
	}

	return super.action (event, arg);
    }

    public boolean handleEvent (Event evt) {
	if (evt.target == this && evt.id == Event.WINDOW_DESTROY) {
	    this.hide(); this.dispose();
	    graph.setupFrameHidden = true;
	    return true;
	}

	return super.handleEvent (evt);
    }
}
