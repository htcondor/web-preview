// TimeStatsCanvas: a canvas component which graphs statistics
// from a stream, in conjunction with TimeGraph and StatsReader.
//
// (c) 1996, Justin Mason <jmason@iona.com>.
// This software is free software. You may use it as you see fit, including
// altering the source and so on, but the existing copyright notices must be
// retained intact in the source code, and the About box and copyright notice
// therein must remain intact and accessible by the user. Additional notices,
// to copyright your own modifications, may be added.

package condor.condorview;

import condor.condorview.DoubleBufferCanvas;
import condor.condorview.StatsStreamTokenizer;
import condor.condorview.StatsReader;

import java.applet.Applet;

import java.util.Date;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;

import java.awt.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.NoSuchElementException;

//======================================================================

class TimeStatsCanvas extends DoubleBufferCanvas {
    final static boolean DEBUG = false;
    final static boolean MOREDEBUG = false;
    int left, top, right, bot;
    int strHeight, strWidth;
    FontMetrics fm;
    public boolean abbreviate = false;
    public boolean xMarkDaytime = false;
    public boolean xMarkWeekend = false;
    Color gridColour, gridHalfColour, gridQtrColour;
    int xOrigMin, xOrigMax, xMin, xMax, xRange;
    float yOrigMin, yOrigMax, yMin, yMax, yRange, yScale;
    float xScaleRatio, yScaleRatio;
    int zoomJumpX, zoomJumpY;
    int zX1 = -1, zX2, lzX;
    int zY1 = -1, zY2, lzY;
    public boolean zooming;
    StatsReader stats;
    Color graphColour[];
    int numGraphs;
	boolean stackedGraph;
    String group[], param[], scale[];
    int flags[];
    final static int DELTA = 1;
    public String brokenMsg;
	int currbot[];
	float currbotY[];
	int labelLocationsX[];
	int labelLocationsY[];
	int tmpQ, tmpW;

    //------------------------------------------------------------------

    public Dimension minimumSize() { return new Dimension(250, 150); }
    public Dimension preferredSize() { return new Dimension(430, 250); }

    //------------------------------------------------------------------

    public TimeStatsCanvas (StatsReader s, int num, boolean stack) {
	super ();
	fullReset (s, num, stack);
    }

    //------------------------------------------------------------------

    public void fullReset (StatsReader s, int num, boolean stack) {
	stats = s;
	numGraphs = num;
	stackedGraph = stack;
	group = new String[numGraphs];
	param = new String[numGraphs];
	scale = new String[numGraphs];
	flags = new int[numGraphs];
	graphColour = new Color[numGraphs];
	labelLocationsX = new int[numGraphs];
	labelLocationsY = new int[numGraphs];
	currbot = new int[4000];
	currbotY = new float[4000];

	for (int i = 0; i < num; i++) {
	    group[i] = "";
	    param[i] = "";
	    scale[i] = "";
	    flags[i] = 0;
	    graphColour[i] = Color.white;
	}
	reset();	// should this change the selected graphs?
    }

    //------------------------------------------------------------------

    public void draw(Graphics g) {
	int i, x, h, w;
	float y;
	String label;
	int widest_label;

	if (DEBUG) { System.out.println ("painting canvas"); }

	g.setColor (Color.black);
	fm = this.getFontMetrics (this.getFont());
	if (fm == null) {
	    strWidth = 30; strHeight = 20;	// hmm...
		widest_label = 60;
	} else {
	    Float F; String s;
	    F = new Float((float) yMax/3.0);
	    s = F.toString();
	    strHeight = fm.getHeight ();
	    strWidth = fm.stringWidth (s);

		widest_label = 0;
		for (i=0;i < numGraphs; i++) {
			if ( (x=fm.stringWidth(group[i])) > widest_label ) {
				widest_label = x;
			}
			if ( (x=fm.stringWidth(param[i])) > widest_label ) {
				widest_label = x;
			}
		}
	}
	if (!stackedGraph) {
		widest_label = 0;
	}

	tmpW = size().width;
	right = size().width - widest_label - 3;
	bot = size().height - 30;
	top = 10 + (strHeight); // need extra space for tick text.
	left = 15 + strWidth;

	if (stats == null || stats.broken ||
	            stats.size == 0 || stats.size == 1 || brokenMsg != null)
	{
	    return;
	}

	if (xOrigMax < stats.size - 1) {	// still reading!
	    xOrigMax = xMax = stats.size - 1;
	}

	if ( stackedGraph ) {
		if ( stats.stoppedReading() != true ) {
	    	g.setColor (Color.red);
	    	g.drawString (
				"Reading Data from Server...",
				left,top-3);	    
			if ( stats.dates.size() > 1 ) {
	    		Date start = (Date) stats.dates.elementAt(xMin);
	    		Date end   = (Date) stats.dates.elementAt(xMax);
				g.setColor(Color.black);
	    		g.drawString ("So far read from "+start.toString()+" to "+end.toString(),
					left,top+top);	    
			}
			return;
		}
	}

	// draw border around the graph
	g.drawLine (left, top, left, bot);
	g.drawLine (left, bot, right, bot);
	g.drawLine (left, top, right, top);
	g.drawLine (right, top, right, bot);

	// get the colours for the grid lines: a major colour which is
	// darker than the background, then a minor colour which is
	// between the two (but closer to the background colour).
	//
	Color bg = this.getBackground();
	if (bg == null) { bg = Color.gray; }

	gridColour = bg.darker();
	gridHalfColour = new Color
			    ((gridColour.getRed() + 2*bg.getRed()) / 3,
			    (gridColour.getGreen() + 2*bg.getGreen()) / 3,
			    (gridColour.getBlue() + 2*bg.getBlue()) / 3);
	gridQtrColour = new Color
			    ((gridHalfColour.getRed() + 2*bg.getRed()) / 3,
			    (gridHalfColour.getGreen() + 2*bg.getGreen()) / 3,
			    (gridHalfColour.getBlue() + 2*bg.getBlue()) / 3);

	yRange = yMax - yMin;
	yScaleRatio = (bot-top) / yRange;
	yScale = determineYTickInterval (yRange);
	if (yScale == (float) 0.0) {
	    return;	                // not fully read yet!
	}

	xRange = xMax - xMin;
	xScaleRatio = (right-left) / (float) xRange;

	zoomJumpX = (right - left) / 10;
	zoomJumpY = (bot - top) / 10;

	// draw X tick text and marks

	try { if (stats.dates.size() > 1 && !Float.isInfinite(xScaleRatio)) {
	    // float xTickIntvl = (float) ((xMax - xMin) / 7.0);
	    float xTickIntvl = (float) (((xMax - xMin) * 40.0) / (right - left));

	    Date start = (Date) stats.dates.elementAt(xMin);
	    Date tick1 = (Date) stats.dates.elementAt(xMin + (int) xTickIntvl);
	    Date end   = (Date) stats.dates.elementAt(xMax);

	    long xSecsPerTick = (long) (tick1.getTime() -
	    				start.getTime()) / 1000;

	    // System.out.println ("JMDB xTickIntvl = "+xTickIntvl);
	    // System.out.println ("JMDB xSecsPerTick = "+xSecsPerTick);

	    int lastX, lastTick = (int) -xTickIntvl, pixX;
	    clearLastXTick();
	    for (x = xMin, lastX = xPlotToPixel(xMin); x <= xMax; x++, lastX = pixX) {
		Date d = (Date) stats.dates.elementAt(x);
		pixX = xPlotToPixel(x);

    		if (xMarkDaytime) {
		    int hrs = d.getHours(); if (hrs < 8 || hrs > 18) {
			g.setColor (gridHalfColour);
			g.fillRect (lastX+1, top+1, pixX-lastX, (bot-top)-2);
		    }
    		} else if (xMarkWeekend) {
    		    int day = d.getDay(); if (day == 0 || day == 6) {
			g.setColor (gridHalfColour);
			g.fillRect (lastX+1, top+1, pixX-lastX, (bot-top)-2);
    		    }
    		}

		if (x - lastTick >= xTickIntvl) {
		    int hrs = d.getHours();

		    if (hrs == 0) {
			xTickMark (g, pixX, d, 0); lastTick = x;
		    } else if (hrs == 12 && xSecsPerTick < 12*60*60) {
			xTickMark (g, pixX, d, 1); lastTick = x;
		    } else if ((hrs == 6 || hrs == 18) && xSecsPerTick < 6*60*60) {
			xTickMark (g, pixX, d, 2); lastTick = x;
		    } else if ((hrs == 3 || hrs == 9 || hrs == 15 || hrs == 21)
			    && xSecsPerTick < 3*60*60)
		    {
			xTickMark (g, pixX, d, 3); lastTick = x;
		    } else if (xSecsPerTick < 60*60) {
			xTickMark (g, pixX, d, 3); lastTick = x;
		    } else if (xSecsPerTick < 60) {
			xTickMark (g, pixX, d, 3); lastTick = x;
		    }
		}
	    }

	    g.setColor (Color.black);
	    g.drawString ("From "+start.toString()+" to "+end.toString(),
			left,top-3);	    
	} } catch (Exception ex) {
	    System.out.println ("X tick mark exception "+ex);
	    ex.printStackTrace();
	}

	// draw Y tick text and marks
	for (y = yMin; y <= yMax; y += yScale) {
	    yTickMark (g, yPlotToPixel(y), y, false);
	}
	for (y = yMin + yScale/2; y <= yMax; y += yScale) {
	    yTickMark (g, yPlotToPixel(y), y, true);
	}
	if (yMin != 0 && yMax != 0) {
	    g.setColor (Color.black);
	    int zeroLine = yPlotToPixel(0);
	    if (zeroLine > top && zeroLine < bot) {
		g.drawLine (left, zeroLine, right, zeroLine);
	    }
	}

	if (stackedGraph) {		
		for (i=0; i<3999; i++) {
			currbot[i]=bot;
			currbotY[i]=0;
		}
	}

	for (i = 0; i < numGraphs; i++) {
		labelLocationsX[i] = -1;
	    drawGraph (g, i);
	}

	// label all the graphs we just finished drawing.
	// we do this _after_ we draw so labels are on top.
	if ( stackedGraph ) {
		int numLabelsToDo = 0;
		for (i=numGraphs-1; i > -1; i--) {
			if ( labelLocationsX[i] != -1 ) {
				labelLocationsY[numLabelsToDo] = i;
				numLabelsToDo++;
			}
		}
		int tmpLabelSecs = (bot - top) / numLabelsToDo;
		tmpQ = tmpW;
		for ( i=0; i < numLabelsToDo; i++ ) {
			label = group[labelLocationsY[i]];
			h = top + 20 + (i * tmpLabelSecs) + (tmpLabelSecs / 2) - fm.getHeight(); 
			w = (((tmpQ-(right + 3)) / 2) - (fm.stringWidth(label) / 2));
			w += right + 3;
			g.setColor (graphColour[labelLocationsY[i]]);
			g.drawString (label,w,h);
			label = param[labelLocationsY[i]];
			h += fm.getHeight();
			w = (((tmpQ-(right + 3)) / 2) - (fm.stringWidth(label) / 2));
			w += right + 3;
			g.drawString (label,w,h);
		}	
	}

    }

    //------------------------------------------------------------------

    private void drawGraph (Graphics g, int which) {
	int x, lastX = -1, lastY = -1, lastbot = -1, plotX, plotY, myScale;
	boolean limitsChanged = false;
	boolean graphDeltas;
	float y, lastYDatum = (float) 0.0;
	Vector data;

	if (group[which].equals ("(unused)")) {
	    return;		// don't graph this one;
	}
	try {
	    if ((flags[which] & DELTA) != 0) {
	        graphDeltas = true;
	    } else {
	        graphDeltas = false;
	    }
	} catch (NullPointerException nx) {
	    return;     // not set up!
	}

	// get the Vector of data for this group/param combo
	//
	data = stats.getDataVector (group[which], param[which]);
	if (data == null) {
	    if (!stats.isValidGroup (group[which])) {
		    Break("Tag references a non-existent group: "+
		        group[which]);
	    }
	    if (!stats.isValidParam (param[which])) {
		    Break("Tag references a non-existent parameter: "+
		        param[which]);
	    }
	    return;
	}

	// what scale are we at?
	try {
	    myScale = Integer.parseInt (scale[which]);
	} catch (NumberFormatException ex) {
	    myScale = 1;
	}
	g.setColor (graphColour[which]);

	// set the initial value used to determine deltas
	if (graphDeltas) {
	    Float f;
	    try {
		f = (Float)data.elementAt(xMin-1);
	    } catch (Exception ex) { try {
		f = (Float)data.elementAt(xMin);
	    } catch (Exception ex2) { try {
		f = (Float)data.elementAt(1);
	    } catch (Exception ex3) {
		return;		// I give up.
	    } } }
	    lastYDatum = f.floatValue();
	    if (DEBUG) {System.out.println ("graphing deltas");}
	}

	// and start drawing
        for (x = xMin; x <= xMax; x++) {
	    try {
		Float F = (Float) data.elementAt(x);
		float f = F.floatValue();
		if (graphDeltas) {
		    float tmp = f; f -= lastYDatum; lastYDatum = tmp;
		}
		y = f * myScale;

	    } catch (Exception ex) {
		y = yOrigMin;
	    }

		if ( stackedGraph ) {
			y += currbotY[x-xMin];
			currbotY[ x - xMin ] = y;
			// y += currbotY[x-xMin];
		}

	    // if the Y limits are too small, rescale them.
	    if (y < yOrigMin) {
	        float py = prettifyYRange (y);
		    if (yMin == yOrigMin) { yMin = py; }
		    yOrigMin = py; limitsChanged = true;
	    }
	    if (y > yOrigMax) {
	        float py = prettifyYRange (y);
		    if (yMax == yOrigMax) { yMax = py; }
		    yOrigMax = py; limitsChanged = true;
	    }

		if ( limitsChanged == false ) {

	    plotX = xPlotToPixel(x); plotY = yPlotToPixel(y);

	    // keep it in range! (we can use clipping when it works ;)
	    if (plotY < top) { plotY = top; }
	    if (plotY > bot) { plotY = bot; }

	    if (lastX == -1) { lastX = plotX; lastY = plotY; }
	    if (MOREDEBUG) {
	        System.out.println (group[which]+"/"+param[which]+
	            ": ("+x+","+y+") = ("+plotX+","+plotY+")");
	    }
		if ( stackedGraph ) {		
			int xps[] = new int[5];
			int yps[] = new int[5];
			/* Here is the code to draw the non-stepped way **
			xps[0]=lastX; xps[1]=plotX; xps[2]=plotX; xps[3]=lastX; xps[4]=lastX;
			yps[0]=lastY; 
			yps[1] = plotY;
			yps[2]=currbot[x - xMin];
			if ( lastbot == -1 ) { 
				lastbot = yps[2]; 
			}
			yps[3] = lastbot;
			yps[4]=lastY;
			g.fillPolygon(xps,yps,5);
			currbot[x - xMin] = yps[1];
	    	lastX = plotX; 
			lastY = yps[1];
			lastbot = yps[2];
			*/
			/* Here is stepped drawing code */
			xps[0]=lastX; xps[1]=plotX; xps[2]=plotX; xps[3]=lastX; xps[4]=lastX;
			yps[0]=lastY; 
			yps[1] = lastY;
			yps[2]=currbot[x - xMin];
			yps[3] = yps[2];
			yps[4]=lastY;
			g.fillPolygon(xps,yps,5);
			currbot[x - xMin] = yps[0];
	    	lastX = plotX; 
			lastY = plotY;
		} else {
	    	g.drawLine(lastX, lastY, plotX, plotY);
	    	lastX = plotX; lastY = plotY;
		}

		}	// end of if limits not changed
        }

	// oops, the limits were too small, redraw!
	if (limitsChanged == true) {
	    if (DEBUG) {System.out.println ("limits changed, repainting");}
	    repaint();		// feck!
	}

	// Store coordinates or draw the label for this series
	if ( stackedGraph ) {
		labelLocationsX[which] = lastX;
		labelLocationsY[which] = lastY;
	} else {
		String s = "["+group[which]+"/"+param[which]+"]";
		int h = fm.getHeight() / 2; int w = fm.stringWidth(s);
		g.drawString (s,lastX-w,lastY-h);
	}

    }

    //------------------------------------------------------------------
    // Work out X tick mark intervals.
    // 60 =             min. pixel range between tick mark text
    // (right-left)/4 = max. width (provide at least 4 ticks)
    //
    float determineXTickInterval (float xRange) {
	int i;
	return xRange / (Math.round (xRange / (60 / xScaleRatio)));
/*
	for (i = Math.round (xRange / (60 / xScaleRatio));
	    i > Math.round (xRange / (((right-left) / 4) / xScaleRatio))
	    && i > 0; i--)
	{
	    if (xRange % i == 0) {
		break;		// found an even divisor
	    }
	}
	return (xRange / i);
*/
    }

    //------------------------------------------------------------------
    // Work out Y tick mark intervals.
    // 60 =          min. pixel range between tick mark text
    // (bot-top)/5 = max. height (provide at least 5 ticks including baseline)
    //
    float determineYTickInterval (float yRange) {
	int i;

	for (i = Math.round (yRange / (60 / yScaleRatio));
	    i > Math.round (yRange / (((bot-top) / 5) / yScaleRatio))
	    && i > 0; i--)
	{
	    if (yRange % i == 0) {
		break;		// found an even divisor
	    }
	}
	return (yRange / i);
    }

    //------------------------------------------------------------------

    int yPlotToPixel (float plotY) {
	return (int) (bot - (plotY - yMin) * yScaleRatio);
    }

    //------------------------------------------------------------------

    int xPlotToPixel (float plotX) {
	return (int) (left + (plotX - xMin) * xScaleRatio);
    }

    //------------------------------------------------------------------

    float prettifyYRange (float y) {
        float newy = 1;
        boolean negative;
		float convergefactor;

		convergefactor = (float) 1.2;

        if (y < 0) {
            negative = true; y = -y;
        } else {
            negative = false;
        }
        while (true) {
            //System.out.println ("converging on y: "+y+" "+newy);
            if (newy < y) {
                if (newy * convergefactor > y) {
					newy = newy * convergefactor;
					if ( newy >= 25 ) {
						newy = (float)Math.floor((double)newy);
						while ( newy % 5 != 0 ) {
							newy++;
						}
					}
                    return (negative ? -1 : 1) * newy;
                } else {
                    newy *= convergefactor;
                }
            } else {
                if (newy / convergefactor < y) {
					if ( newy >= 25 ) {
						newy = (float)Math.floor((double)newy);
						while ( newy % 5 != 0 ) {
							newy++;
						}
					}
                    return (negative ? -1 : 1) * newy;
                } else {
                    newy /= convergefactor;
                }
            }
        }
    }

    //------------------------------------------------------------------

    void yTickMark (Graphics g, int y, float val, boolean isSubTick) {
	String s;

	if (abbreviate) {	// abbreviate to 10.5M, 5.3K etc.
	    if (val > (float) 1e+6) {
		Float f = new Float((float) Math.round (val/1e+5) * 10.0);
		s = f.toString() + "M";
	    } else if (val > (float) 1e+3) {
		Float f = new Float((float) Math.round (val/1e+2) * 10.0);
		s = f.toString() + "K";
	    } else {
		Float i = new Float(val);
		s = i.toString();
	    }
	} else {
	    Float i = new Float(val);
	    s = i.toString();
	}

	if (y != top && y != bot) {
	    if (isSubTick) {
		g.setColor (gridHalfColour);
	    } else {
		g.setColor (gridColour);
	    }
	    g.drawLine (left + 1, y, right - 1, y);
	}

	g.setColor (Color.black);
	if (!isSubTick) {
	    g.drawLine (left - 5, y, left, y);
	    g.drawString (s, 5, y + (strHeight / 2));
	}
    }

    //------------------------------------------------------------------

    static final String DaysOfWeek[] =
   	 {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

    String lastXTick = null;
    int lastXTickPos = 0;

    void clearLastXTick () {
	lastXTick = "";
	lastXTickPos = 0;
    }

    void xTickMark (Graphics g, int x, Date d, int subTickLevel) {
	String s;

	if (subTickLevel > 0) {
	    int mins = d.getMinutes();
	    s = d.getHours() + ":" + ((mins < 10) ? ("0"+mins) : (""+mins));
	} else {
	    s = DaysOfWeek[d.getDay()] + " " + d.getDate();
	}

	//System.out.println ("JMDB lastXTick='"+lastXTick+"', this='"+s+
	//	"'; lastpos="+lastXTickPos+", pos="+x+", date="+d.toString());

	if ((lastXTickPos > 0 && lastXTickPos < x+10 && lastXTickPos > x-10)
		|| (lastXTick != null && lastXTick.equals (s)))
	{
	    return;		// we've already ticked this one!
	}

	lastXTick = s; lastXTickPos = x;
	if (fm == null) {
	    strWidth = 30;
	} else {
	    strWidth = fm.stringWidth (s);
	}

	if (x != left && x != right) {
	    if (subTickLevel > 0) {
		g.setColor (gridHalfColour);
	    } else {
		g.setColor (gridColour);
	    }
	    g.drawLine (x, top + 1, x, bot - 1);
	}

	if (subTickLevel > 0) {
	    g.setColor (gridColour);
	} else {
	    g.setColor (Color.black);
	}
	g.drawLine (x, bot, x, bot + 5);
	g.drawString (s, x - (strWidth / 2), bot + 20);
	g.setColor (Color.black);
    }

    public synchronized void Break (String msg) {
        brokenMsg = msg;
    }

    //------------------------------------------------------------------

    public synchronized boolean mouseDown (Event e, int x, int y) {
	if (zX1 != -1 && zY1 != -1) {
	    xorZoomRect (zX1, zY1, zX2, zY2);	// clear old one
	}
	zX2 = -1; zY2 = -1;
	zooming = false;

	x = Math.max (x, left); x = Math.min (x, right);
	y = Math.max (y, top);  y = Math.min (y, bot);

	lzX = zX1 = x;
        lzY = zY1 = y;
	return true;
    }

    public synchronized boolean mouseDrag (Event e, int x, int y) {
	int x1, y1, xw, yw;

	xorZoomRect (zX1, zY1, lzX, lzY);	// clear old one
	zooming = true;

	//zoomCursor (zX1, zY1, x, y);

	x = Math.max (x, left); x = Math.min (x, right);
	y = Math.max (y, top);  y = Math.min (y, bot);

	xorZoomRect (zX1, zY1, x, y);		// new one
	lzX = x; lzY = y; return true;
    }

//    public void zoomCursor (int x1, int y1, int x2, int y2) {
//	if (x1 < x2 && y1 < y2) {
//	    setCursor (Frame.SE_RESIZE_CURSOR);
//	} else if (x1 > x2 && y1 < y2) {
//	    setCursor (Frame.SW_RESIZE_CURSOR);
//	} else if (x1 < x2 && y1 > y2) {
//	    setCursor (Frame.NE_RESIZE_CURSOR);
//	} else {
//	    setCursor (Frame.NW_RESIZE_CURSOR);
//	}
//    }

    public synchronized boolean mouseUp (Event e, int x, int y) {
	Graphics g = getGraphics();

	if (x == zX1 || y == zY1) {
	    // too small -- we can't zoom in to that!
	    zX1 = zX2 = -1;
	    zY1 = zY2 = -1;
	} else {
	    x = Math.max (x, left); x = Math.min (x, right);
	    y = Math.max (y, top);  y = Math.min (y, bot);
	    zX2 = x; zY2 = y;
	}
	return true;
    }

    //------------------------------------------------------------------

    protected void xorZoomRect (int x1, int y1, int x2, int y2) {
	int x, y, xw, yw;
	Graphics g = getGraphics();

	g.setXORMode (getBackground());
	x = x1; xw = x2 - x1; if (x2 < x1) { x = x2; xw = x1 - x2; }
	y = y1; yw = y2 - y1; if (y2 < y1) { y = y2; yw = y1 - y2; }
	g.drawRect (x, y, xw, yw);
	g.setColor (getForeground()); g.setPaintMode();
    }

    //------------------------------------------------------------------

    public void zoomIn () {
	if (zX1 == -1 || zY1 == -1) {
	    // no rectangle was dragged out, just use default zoom
	    zX1 = left + zoomJumpX; zX2 = right - zoomJumpX;
	    zY1 = top + zoomJumpY;  zY2 = bot - zoomJumpY;
	}

	// swap them around if they're inverted
	if (zX2 < zX1) {
	    int tmp = zX2; zX2 = zX1; zX1 = tmp;
	}
	if (zY2 < zY1) {
	    int tmp = zY2; zY2 = zY1; zY1 = tmp;
	}

	xMax = (int) (((zX2 - left) / xScaleRatio) + xMin);
	xMin = (int) (((zX1 - left) / xScaleRatio) + xMin);
	yMax = (float) (((bot - zY1) / yScaleRatio) + yMin);
	yMin = (float) (((bot - zY2) / yScaleRatio) + yMin);

	lzX = zX1 = lzY = zY1 = -1;
	zooming = false;
	repaint();
    }

    //------------------------------------------------------------------

    public void zoomOut () {
	xMin = (int) Math.max (0, xMin - (zoomJumpX / xScaleRatio));
	xMax = (int) Math.min (stats.size - 1, xMax + (zoomJumpX / xScaleRatio));
	if (xMin == xMax) {
	    if (xMin > 0 && xMax == stats.size - 1) {
		xMin--;
	    } else {
		xMax++;
	    }
	}

	yMin = (float) Math.max (0, yMin - (zoomJumpY / yScaleRatio));
	yMax = (float) (yMax + (zoomJumpY / yScaleRatio));

	zooming = false;
	repaint();
    }

    //------------------------------------------------------------------

    public void reset () {
	xOrigMin = xMin = 0;
	try {
	    xOrigMax = xMax = stats.size - 1;
	} catch (NullPointerException ex) {
	    xOrigMax = xMax = 0;
	}
	yOrigMin = yMin = (float) 0;
	yOrigMax = yMax = (float) 1;
	repaint();
    }
}
