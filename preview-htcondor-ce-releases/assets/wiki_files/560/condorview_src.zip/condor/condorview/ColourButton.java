// a simple button -- no label, just a colour.
//
// (c) 1996, Justin Mason <jmason@iona.com>.
// This software is free software. You may use it as you see fit, including
// altering the source and so on, but the existing copyright notices must be
// retained intact in the source code, and the About box and copyright notice
// therein must remain intact and accessible by the user. Additional notices,
// to copyright your own modifications, may be added.
//
package condor.condorview;

import java.awt.*;

public class ColourButton extends Canvas {
    public Color color;

    public ColourButton (Color c) {
	super();
	color = c;
    }

    public void setColor (Color c) { color = c; }
    public Dimension minimumSize() { return new Dimension(20, 20); }
    public Dimension preferredSize() { return new Dimension(30, 30); }

    public void paint (Graphics g) {
	int w, h;

	w = size().width;
	h = size().height;
	g.setColor (color);
	g.fill3DRect (0, 0, w, h, true);
    }
}
