/*
  TimeGraph: Graph Applet for network statistics

  This was designed specifically for net stats, as it relies on the X index
  being a timestamp, and only plots linegraphs.  Of course, it'd be useful for
  any other numeric statistics whose progress over time needs to be graphed,
  eg. CPU usage, temperature, etc.

  It can also graph parameters as deltas, ie the differences between
  consecutive values; and it can automatically select the groups with the
  highest-valued parameters using the "highest" parameter.

  See URL:http://www.iona.com/~jmason/java/TimeGraph/ for details of the
  parameters and stats file format. The revision history is at the end of this
  file.

  (c) 1997, Justin Mason <jmason@iona.com>.

  This software is free software. You may use it as you see fit, including
  altering the source and so on, but the existing copyright notices must be
  retained intact in the source code, and the About box and copyright notice
  therein must remain intact and accessible by the user. Additional notices,
  to copyright your own modifications, may be added.

*/

package condor.condorview;

import condor.condorview.TimeStatsCanvas;
import condor.condorview.SetupFrame;

import java.util.Vector;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Hashtable;
import java.util.Date;

import java.io.InputStream;
import java.net.URL;
import java.net.Socket;

import java.applet.Applet;
import java.awt.*;

import java.util.NoSuchElementException;
import java.io.IOException;
import java.lang.StringIndexOutOfBoundsException;

//======================================================================

public class TimeGraph extends Applet implements Runnable {
final static String Version = "CondorView Applet ver 6.6.6";

final static int numGraphs = 8;
Color Ccolor[] = {Color.red,Color.blue,Color.green,Color.pink,
	        Color.orange,Color.yellow,Color.magenta,Color.cyan};

final static String AboutText = Version +"\n\n"+
    "The code for this applet was derived from TimeGraph.\n"+
    "TimeGraph (c) 1996, Justin Mason <jmason@iona.com>.\n\n" +
    "Changes for stacked charts, boxfill, legends, FORMAT\n" +
	"schema (to save bandwidth), double buffering, UTC dates,\n" +
	"by Todd Tannenbaum <tannenba@cs.wisc.edu> for the Condor Team.\n";

    final static boolean DEBUG = false;
    boolean highestGroups, graphDeltas, usDates, stackedGraph;
    int dynamicMemorySize;
    Button zoomIn, zoomOut, openSetup, openAbout, Reset;
    SetupFrame setupFrame; boolean setupFrameHidden = true;
    AboutFrame aboutFrame; boolean aboutFrameHidden = true;
    TimeStatsCanvas canvas;
    InputStream is;
    StatsReader stats;
    Thread engine = null;

    //------------------------------------------------------------------

    public String getAppletInfo() {
	return Version;
    }

    //------------------------------------------------------------------

    public String[][] getParameterInfo() {
	String[][] info = {
        {"src",	   "URL",    "the statistics data file"},
	{"graph n","string", "graph number 'n': group[/param][*scale][,delta]"},
	{"stacked",  "boolean","create filled stacked graph instead of line graph"},
	{"delta",  "boolean","graph delta between consecutive items"},
	{"highest","string", "auto-select the highest data"},
	{"markdaytime","boolean","differentiate between night and day"},
	{"markweekend","boolean","differentiate between weekdays and weekend"},
	{"usdates","boolean","expect mm/dd/yy formatted dates in the stats data"},
	{"memory","int","number of data points to remember for dynamic data feeds"},
	{"bg",	   "color",  "background of applet (in \"RRR,GGG,BBB\" format)"},
	};
	return info;
    }

    //------------------------------------------------------------------

    public void init() {
	System.out.println (Version);		// to java console

	// - - - - - - - - - - - - - - - - - - - - - - - - - -
	// Initialize colour list.

	if (Ccolor.length != numGraphs) {
	    System.err.println ("color initializer != numGraphs!");
	    return;
	}

	// - - - - - - - - - - - - - - - - - - - - - - - - - -
	// get parameters.
	String parm;

	parm = this.getParameter("highest");
	if (parm != null && parm.equals ("true")) {
	    highestGroups = true;
	} else {
	    highestGroups = false;
	}

	parm = this.getParameter("stacked");
	if (parm != null && parm.equals ("true")) {
	    stackedGraph = true;
	} else {
	    stackedGraph = false;
	}

	parm = this.getParameter("delta");
	if (parm != null && parm.equals ("true")) {
	    graphDeltas = true;
	} else {
	    graphDeltas = false;
	}

	usDates = false; parm = this.getParameter("usdates");
	if (parm != null && parm.equals ("true")) { usDates = true; }

	dynamicMemorySize = 0;
	parm = this.getParameter("memory");
	if (parm != null) {
	    try {
		dynamicMemorySize = Integer.parseInt(parm);
		if (dynamicMemorySize <= 0) {
		    dynamicMemorySize = 0;
		    Break ("applet tag error: \"memory\" must be a positive integer!");
		}
	    } catch (NumberFormatException ex) {
		dynamicMemorySize = 0;
	        Break ("applet tag error: \"memory\" is not a number!");
	    }
	}

	try {
	    parm = this.getParameter("src");
	    if (parm == null) {
	        canvas = new TimeStatsCanvas (null, numGraphs,stackedGraph);
	        Break ("applet tag error: no \"src\" parameter!");
	        return;
	    }
            if (parm.startsWith("socket:")) {
                // eg. URL-style spec.: socket://[host:]port
                // host is optional, defaults to the host
                // the applet came from.
                // there must be a port number though.
		//
                is = openSocketStream(getDocumentBase(), parm.substring(7));
            } else {
                is = new URL(getDocumentBase(), parm).openStream();
            }

	} catch (Exception e) {
	    canvas = new TimeStatsCanvas (null, numGraphs,stackedGraph);
	    Break ("couldn't read data file: "+e);
	    return;
	}

	// - - - - - - - - - - - - - - - - - - - - - - - - - -
	// Start stats reader thread. (low priority!)

	stats = new StatsReader (is, usDates, dynamicMemorySize);
	stats.setPriority (2);
	stats.start();
	canvas = new TimeStatsCanvas (stats, numGraphs,stackedGraph);
	selectDefaults();

	parm = this.getParameter("markdaytime");
	if (parm != null && parm.equals ("true")) {
	    canvas.xMarkDaytime = true;
	} else {
	    canvas.xMarkDaytime = false;
	}

	parm = this.getParameter("markweekend");
	if (parm != null && parm.equals ("true")) {
	    canvas.xMarkWeekend = true;
	} else {
	    canvas.xMarkWeekend = false;
	}

	try {
	    String bg = this.getParameter ("bg");
	    if (bg != null) {
		setBackground (readColor (bg, getBackground()));
	    }
	} catch (Exception ex) {
	    Break ("cannot set background colour as specified in \"bg\" tag!");
	}

	// - - - - - - - - - - - - - - - - - - - - - - - - - -
	// Select the parameters used in the tag

	for (int i = 0; i < numGraphs; i++) {
	    int idx;
	    String param = "graph "+(new Integer(i+1)).toString();

	    String s = this.getParameter (param);
	    if (s == null) {
		continue;
	    }
	    s = s.trim();

	    if ((idx = s.lastIndexOf (",delta")) > 0) {
		canvas.flags[i] |= canvas.DELTA;
		s = s.substring(0, idx).trim();
	    }

	    if (graphDeltas) {
		canvas.flags[i] |= canvas.DELTA;
	    }

	    if ((idx = s.lastIndexOf ('*')) > 0) {
		String num = (s.substring(idx + 1));
		try {
		    Integer foo = new Integer(num);
		    canvas.scale[i] = foo.toString();
		} catch (NumberFormatException nfx) {
		    Break ("applet tag error: the range value in "+
			"parameter \"graph "+i+"\" is not a number!");
		}
		s = s.substring(0, idx).trim();
	    }

	    if ((idx = s.lastIndexOf ('/')) > 0) {
		canvas.param[i] = s.substring(idx + 1);
		s = s.substring(0, idx).trim();
	    }

	    canvas.group[i] = s;

	    if (DEBUG) {
		System.out.println ("graph "+i+":"+
			" flags="+canvas.flags[i]+
			" scale="+canvas.scale[i]+
			" param="+canvas.param[i]+
			" group="+canvas.group[i]);
	    }
	}

	// - - - - - - - - - - - - - - - - - - - - - - - - - -

	openSetup = new Button("Configure...");
	zoomIn = new Button("Zoom In");
	zoomOut = new Button("Zoom Out");
	Reset = new Button("Reset");
	openAbout = new Button("About");

	// - - - - - - - - - - - - - - - - - - - - - - - - - -
	// add the graph canvas & the above buttons to display

	GridBagConstraints c = new GridBagConstraints();
	GridBagLayout gridbag = new GridBagLayout();

        setLayout (gridbag);
	c.gridx =     0;	c.gridy =      0;
	c.gridwidth = 5;	c.gridheight = 1;
	c.fill =      c.BOTH;	c.anchor =     c.NORTHWEST;
	c.weightx =   1.0;	c.weighty =    1.0;
	gridbag.setConstraints (canvas, c); add (canvas);

	c.gridx =     0;	c.gridy =      1;
	c.gridwidth = 1;	c.gridheight = 1;
	c.fill =      c.HORIZONTAL; c.anchor = c.WEST;
	c.weightx =   0.25;	c.weighty =    0.0;
	c.insets = new Insets (1, 5, 1, 5);
	gridbag.setConstraints (openSetup, c); add (openSetup);

	c.gridx =     1;	c.gridy =      1;
	c.gridwidth = 1;	c.gridheight = 1;
	c.fill =      c.HORIZONTAL; c.anchor = c.EAST;
	c.weightx =   0.25;	c.weighty =    0.0;
	c.insets = new Insets (1, 5, 1, 5);
	gridbag.setConstraints (zoomIn, c); add (zoomIn);

	c.gridx =     2;	c.gridy =      1;
	c.gridwidth = 1;	c.gridheight = 1;
	c.fill =      c.HORIZONTAL; c.anchor = c.EAST;
	c.weightx =   0.25;	c.weighty =    0.0;
	c.insets = new Insets (1, 5, 1, 5);
	gridbag.setConstraints (zoomOut, c); add (zoomOut);

	c.gridx =     3;	c.gridy =      1;
	c.gridwidth = 1;	c.gridheight = 1;
	c.fill =      c.HORIZONTAL; c.anchor = c.EAST;
	c.weightx =   0.25;	c.weighty =    0.0;
	c.insets = new Insets (1, 5, 1, 5);
	gridbag.setConstraints (Reset, c); add (Reset);

	c.gridx =     4;	c.gridy =      1;
	c.gridwidth = 1;	c.gridheight = 1;
	c.fill =      c.HORIZONTAL; c.anchor = c.EAST;
	c.weightx =   0.25;	c.weighty =    0.0;
	c.insets = new Insets (1, 5, 1, 5);
	gridbag.setConstraints (openAbout, c); add (openAbout);
    }

    //------------------------------------------------------------------

    private InputStream openSocketStream (URL context, String hostnport)
        throws IOException
    {
        int colon = hostnport.lastIndexOf (':');
        String host, portstr;
        int port;

	host = "";
	portstr = "";

        if (colon <= 0) {
            host = context.getHost();
            portstr = (colon == 0) ? hostnport.substring(1) : hostnport;
        } else {
            try {
                host = hostnport.substring (0, colon);
                portstr = hostnport.substring (colon+1);
            } catch (StringIndexOutOfBoundsException ex) {
                throw new IOException ("invalid 'src' socket");
            }
        }

        try {
            port = Integer.parseInt(portstr);
        } catch (Exception ex) {
            throw new IOException ("port is not a number: "+portstr);
        }

        return ((new Socket(host,port)).getInputStream());
    }
 
    //------------------------------------------------------------------

    final static int numTries = 999;

    public void selectDefaults() {
	// select the default set of parameters and groups.
	// only the first graph is active to start with,
	// and only the first param is selected.
	int i;

	for (i = 0; i < numTries; i++) {
		if (stats.initializedGroups() == true) {
		    break;
		} else if (stats.stoppedReading() == true) {
		    i = numTries;   // oops, an error has occurred
		    break;
		}
	    try { Thread.sleep (100); } catch (Exception interrupted) {}
	    if (stats.DEBUG) { System.out.println ("zzz... "+stats); }
	}

	if (i >= numTries) {
	    Break ("failed to read the data file: "+
	                    stats.brokenException.toString());
	    return;
	}

	Vector sorted;
	if (highestGroups) {
	    sorted = stats.sortedGroups();
	} else {
	    sorted = null;
	}
	for (i = 0; i < numGraphs; i++) {
	    try {
	        if (highestGroups) {
	            try {
	                canvas.group[i] = (String) sorted.elementAt(i);
	            } catch (ArrayIndexOutOfBoundsException ax) {
	                canvas.group[i] = "(unused)";
	            }
	        } else {
        		if (i == 0) {
        		    canvas.group[i] = (String) stats.groups.elementAt(0);
        		} else {
        		    canvas.group[i] = "(unused)";
        		}
	        }
		canvas.param[i] = (String) stats.params.elementAt(0);

	    } catch (Exception ex) {
    		// can't use the data. Oh well...
    		canvas.group[i] = "(unused)";
    		canvas.param[i] = "(unused)";
	    }
	    if (graphDeltas) {
	        canvas.flags[i] = canvas.DELTA;
	    } else {
	        canvas.flags[i] = 0;
	    }

	    canvas.scale[i] = "1";
	    canvas.graphColour[i] = Ccolor[i];
	}
    }

    //------------------------------------------------------------------

    public void run() {
	int lastRead = 0;
	boolean stopUpdating = false;

	Thread me = Thread.currentThread();
	me.setPriority(5);
	if (stats == null) {		// cannot read the data file
	    return;
	}
	while (stopUpdating == false) {
	    if (stats.stoppedReading() == true && dynamicMemorySize == 0) {
			stopUpdating = true;	// after this repaint
	    }
	    if (!canvas.zooming && stats.linesRead>0 && lastRead<stats.linesRead) {
		if (DEBUG) {
		    System.out.println ("updating: last read="+
		                    lastRead+" current="+stats.linesRead);
		}
		lastRead = stats.linesRead;
		canvas.repaint();
	    }
	    if (canvas.brokenMsg != null) {
	        Break (canvas.brokenMsg);
	    }
	    if (stats.brokenException != null) {
	        Break("failed to read data: "+stats.brokenException);
	    }
	    try { Thread.sleep (2000); } catch (Exception ex) {}
	}
    }

    public void start() {
        if (engine == null) {
            engine = new Thread(this);
            engine.start();
        }
    }

    public void stop() {
        if (engine != null && engine.isAlive()) {
            engine.stop();
        }
	if (setupFrame != null) {
	    setupFrame.hide(); setupFrame.dispose();
	    setupFrame = null;
	    setupFrameHidden = true;
	}
	if (aboutFrame != null) {
	    aboutFrame.hide(); aboutFrame.dispose();
	    aboutFrame = null;
	    aboutFrameHidden = true;
	}
        engine = null;
    }

    //------------------------------------------------------------------

    public static void main(String args[]) {
        Frame f = new Frame("TimeGraph");
        TimeGraph nsGraph = new TimeGraph();

        nsGraph.init();
        f.pack();
        f.show();
        nsGraph.start();
    }

    //------------------------------------------------------------------

    public void Break (String msg) {
        String str;
        int ind, nextSpc;

        str = "";
	    for (ind = 0; ind < msg.length(); ind = nextSpc) {
	        str += "\n";
	        try {
	            nextSpc = msg.indexOf(' ', ind+50);
	            str += msg.substring (ind, nextSpc);
	        } catch (StringIndexOutOfBoundsException ex) {
	            nextSpc = msg.length();
	            str += msg.substring (ind);
	        }
	    }
	    AboutFrame brokenFrame = new AboutFrame
	                    ("TimeGraph Error", str, null);
    }

    //------------------------------------------------------------------

    public boolean action (Event event, Object arg) {
	if (event.target instanceof Button) {
	    if (event.target == zoomIn) {
		canvas.zoomIn(); return true;

	    } else if (event.target == zoomOut) {
		canvas.zoomOut(); return true;

	    } else if (event.target == Reset) {
		canvas.reset(); return true;

	    } else if (event.target == openSetup) {
		if (setupFrameHidden) {
		    setupFrame = new SetupFrame ("Setup Graph", this);
		    setupFrame.pack(); setupFrame.show();
		    setupFrameHidden = false;
		} else {
		    setupFrame.hide(); setupFrame.dispose();
		    setupFrame = null;
		    setupFrameHidden = true;
		}
		return true;

	    } else if (event.target == openAbout) {
		if (aboutFrameHidden) {
		    aboutFrame = new AboutFrame
		        ("About the CondorView Applet", AboutText, this);
		    aboutFrame.pack(); aboutFrame.show();
		    aboutFrameHidden = false;
		} else {
		    aboutFrame.hide(); aboutFrame.dispose();
		    aboutFrame = null;
		    aboutFrameHidden = true;
		}
		return true;
	    }
	}
	return super.action (event, arg);
    }

    //------------------------------------------------------------------

    public Color readColor (String str, Color col) {
        if (str == null) {
            return col;
	}

        try {
	    StringTokenizer tok = new StringTokenizer(str, ",");
            int i = Integer.valueOf(tok.nextToken()).intValue();
            int j = Integer.valueOf(tok.nextToken()).intValue();
            int k = Integer.valueOf(tok.nextToken()).intValue();

            Color c = new Color(i, j, k);
            return c;

        } catch (Exception e) {
            return col;
        }
    }


    public void set_two_graphs(String item1,String param1,String item2,String param2) {
	canvas.group[0] = item1;
	canvas.group[1] = item2;
	canvas.param[0] = param1;
	canvas.param[1] = param2;
	canvas.repaint();
	canvas.reset();
    }

       	
    public void set_three_graphs(String item1, String param1, String item2, String param2, String item3, String param3) {
	canvas.group[0] = item1;
	canvas.group[1] = item2;
	canvas.group[2] = item3;
	canvas.param[0] = param1;
	canvas.param[1] = param2;
	canvas.param[2] = param3;
	canvas.repaint();
	canvas.reset();

    }

    /*public void set_four_graphs(String item1, String param1, String item2, String param2, String item3, String param3, String item4, String param4) {
        canvas.group[0] = item1;
        canvas.group[1] = item2;
        canvas.group[2] = item3;
        canvas.group[3] = item4;
        canvas.param[0] = param1;
        canvas.param[1] = param2;
        canvas.param[2] = param3;
        canvas.param[3] = param4;
        canvas.repaint();
        canvas.reset();

    }
*/
    public void do_repaint() {
	canvas.repaint();
    }
}

/*------------------------------------------------------------------

REVISION HISTORY:

1.0     jmason  march 96    Initial. no StatsReader thread,
                            the stats were read before display.

1.1     jmason  april 96    used threads; TimeGraph & StatsReader
                            thread functionality isolated.
                            Also fixed bug in reading stats
                            files where space was a significant
                            char to the Tokenizer, so had to
                            make FixedStreamTokenizer class as well to fix
                            a bug in the JDK impl.

1.2     jmason  may 96      added Configure window, fixed bugs

1.3     jmason  may 96      added parameter-parsing, labels
                            on graph.

1.4     jmason  may 96      added "highest" & "delta" functionality

1.5	jmason	jun 96	    added "About" button

1.6     jmason  jul 96      errors are no longer in console

1.7     jmason  jul 96      fixed bug where graphs weren't drawing at all;
			    also added "Reset" button, and removed about
			    and setup frames when the applet is stopped.

2.0     jmason  aug 96      added support for "socket:" pseudo-URLs as
			    a data source, and the dynamic feed memory support.
			    A good enough reason for a new version number as any!

2.1     jmason  dec 96      added support for "bg" tag

2.2     jmason  may 97      fixed X scale to support smaller items, also supports
			    WINDOW_DESTROY events on the popup frames now

2.3	jmason	jul 97	    fixed bug in zoom-out code on the Y axis, made copyright
			    notices more consistent

*/
