// StatsStreamTokenizer: a specialized wrapper around StreamTokenizer
// to interpret statistics in the .nstats format.
//
// The StreamTokenizer class in java.io is broken in JDK 1.0,
// so we use our own version -- FixedStreamTokenizer (The bug was
// that it required that space (' ') was a whitespace character).
//
//--------------------------------------------------------------
//
// line format:
//
// timestamp<wspace>group[<wspace>group...]<newline>
//
//     timestamp looks like: "19:20 Sun 17/03/96"
//     leading 0's can be dropped.
//
//     group looks like:
//	    name="groupname",param=value[,param=value...]
//
//	    string values must have quotes around them.
//	    each group must have a "name" string parameter.
//
// alternatively, a data-file format specification line looks like:
//
// FORMAT<wspace>format[<wspace>format-specific-flags...]<newline>
//
//     format is the name of the format, used to dynamically
//     create the StatsReader class for that format. TODO.
//
//--------------------------------------------------------------
//
// (c) 1996, Justin Mason <jmason@iona.com>.
// This software is free software. You may use it as you see fit, including
// altering the source and so on, but the existing copyright notices must be
// retained intact in the source code, and the About box and copyright notice
// therein must remain intact and accessible by the user. Additional notices,
// to copyright your own modifications, may be added.

package condor.condorview;

import condor.condorview.FixedStreamTokenizer;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.Hashtable;
import java.util.Date;
import java.util.Vector;

class StatsStreamTokenizer {
    //private final static boolean DEBUG = true;
    private final static boolean DEBUG = false;

    protected FixedStreamTokenizer S;
    protected int state, ST_DATE = 1, ST_GROUP = 2, ST_EOF = 3;
    protected boolean usDates;
    public char quote;
	
	protected boolean use_alternate_format = false;
	protected Vector column_names;
	protected int column_index = 0;

    // vars used to access contents of each line.
    public Date date;
    public Hashtable strs, nums;
    public String groupName;

    public StatsStreamTokenizer (InputStream stream, boolean ctorUsDates) {
	S = new FixedStreamTokenizer (stream);
	S.eolIsSignificant (true);
	S.slashSlashComments (false);
	S.slashStarComments (false);
	S.parseNumbers();
	S.quoteChar (quote = '"');

	// used to separate bits of timestamps
	S.whitespaceChars (':', ':');
	S.whitespaceChars ('/', '/');

	// used inside a group of parameters
	S.ordinaryChar (',');
	S.ordinaryChar ('=');

	usDates = ctorUsDates;
	state = ST_DATE;
    }

    //--------------------------------------------------------------

    public boolean nextDataSet() throws IOException {
	int t;
	int year, mon, mday, hrs, min;
	long utc;

	// parse the timestamp at start of line:
	// looks like: "19:20 Sun 17/03/96<tab>"
	// or (USA):   "19:20 Sun 03/17/96<tab>"

	if (state == ST_EOF) {
	    return false;
	}
	stateAssert (ST_DATE);

	S.whitespaceChars (' ', ' ');
	S.whitespaceChars ('\t', '\t');


	t = S.nextToken(); if (t == S.TT_EOF) {
	    state = ST_EOF;
	    return false;
	} else if (t == S.TT_EOL) {	// ignore blank lines
	    return nextDataSet();
	} else if (t != S.TT_NUMBER) {
	    if (t == S.TT_WORD && S.sval.equals ("FORMAT")) {
			// handle a different data-file format
			use_alternate_format = true;
			column_names = new Vector(320);
			int name_count = 0;

			while ( (t=S.nextToken()) == S.TT_WORD ) {
				column_names.addElement( S.sval );
				name_count++;
			}
			return nextDataSet();
	    } else {
		throw new IOException ("unparseable date: "+S);
	    }
	}

	if ( usDates ) {

			hrs = (int) S.nval;

			t = S.nextToken(); if (t != S.TT_NUMBER) {
				throw new IOException ("unparseable date: "+S);
			}
			min = (int) S.nval;

			t = S.nextToken(); if (t != S.TT_WORD) {
				throw new IOException ("unparseable date: "+S);
			}
			// we actually ignore this -- Java's Date class deals with it

			int x, y;			// handle euro & non-euro dates

			t = S.nextToken(); if (t != S.TT_NUMBER) {
				throw new IOException ("unparseable date: "+S);
			}
			x = (int) S.nval;

			t = S.nextToken(); if (t != S.TT_NUMBER) {
				throw new IOException ("unparseable date: "+S);
			}
			y = (int) S.nval - 1;		// off by one? wierd but true!

			if (usDates) {
				mday = y; mon = x;
			} else {
				mday = x; mon = y;
			}

			t = S.nextToken(); if (t != S.TT_NUMBER) {
				throw new IOException ("unparseable date: "+S);
			}
			year = (int) S.nval;

			date = new Date (year, mon, mday, hrs, min);
			
	} else {

		// do UTC (epoch) time format

		utc = (long) S.nval;
		date = new Date(1000 * utc);

	}

	state = ST_GROUP;
	column_index = 0;
	return true;
    }

    //--------------------------------------------------------------

    public boolean nextGroup() throws IOException {
	String name;
	int t;

	stateAssert (ST_GROUP);
	if (strs == null) {
	    strs = new Hashtable(10);
	    nums = new Hashtable(10);
	} else {
	    strs.clear();
	    nums.clear();
	}
	groupName = "(unset)";

	S.ordinaryChar (' ');
	S.ordinaryChar ('\t');

	// skip the whitespace before the first token
	while ((t = S.nextToken()) == ' ' || t == '\t');
	S.pushBack();

	// in a group entry, whitespace means end of group
	while ((t = S.nextToken()) != ' ' && t != '\t' &&
			    t != S.TT_EOL && t != S.TT_EOF)
	{
		// first handle the alternate FORMAT mode
		if ( use_alternate_format ) {
			groupName = (String)column_names.elementAt(column_index);
			column_index++;
			
			while ( t == ',' || t == S.TT_NUMBER ) {
				if (t == ',') {
					column_index++;
				} else if ( t == S.TT_NUMBER ) {
					nums.put ((String)column_names.elementAt(column_index),
							  new Float(S.nval));
				} else {			
					break;
				}
				t = S.nextToken();
			}
			column_index++;
			break;
		} else {

		// and now handle the traditional format
	    if (DEBUG) { System.out.println (date+": name: "+S); }
	    if (t == ',') {
		continue;
	    } else if (t == S.TT_EOL || t == S.TT_EOF) {
		break;
	    } else if (t == S.TT_NUMBER) {
		name = (new Double(S.nval)).toString();
	    } else if (t == S.TT_WORD) {
		name = S.sval;
	    } else {
		throw new IOException ("bad parameter: "+S);
	    }

	    //--------------------------------------------------
	    // okay, we got the parameter name. Now get the
	    // '=' sign...
	    //
	    t = S.nextToken();
	    if (DEBUG) { System.out.println (date+": equals: "+S); }
	    if (t != '=') {
		throw new IOException ("no = sign: "+name+", "+S);
	    }

	    //--------------------------------------------------
	    // then the value.
	    //
	    t = S.nextToken();
	    if (DEBUG) { System.out.println (date+": val: "+S); }
	    if (t == ',') {
		strs.put (name, "");
	    } else if (t==S.TT_EOF || t==S.TT_EOL || t==' ' || t=='\t') {
		strs.put (name, ""); break;
	    } else if (t == quote) {
		strs.put (name, S.sval);
		if (name.equals("name")) { groupName = S.sval; }
	    } else if (t == S.TT_NUMBER) {
		nums.put (name, new Float(S.nval));
	    } else {
		throw new IOException("unparseable value: "+name+"="+S);
	    }
		}  // end of traditional format
	}
	if (DEBUG) { System.out.println (date+": done: "+strs+"/"+nums); }
	S.whitespaceChars (' ', ' ');

	if (t == S.TT_EOL) {
	    state = ST_DATE; return false;
	} else if (t == S.TT_EOF) {
	    state = ST_EOF; return false;
	} else {
	    return true;	// there are more groups to come
	}
    }

    //--------------------------------------------------------------

    protected void stateAssert (int desired) throws IOException {
	if (state != desired) {
	    throw new IOException
	   	 ("StatsStreamTokenizer assert: bad state: "+state+" != "+desired);
	}
    }
}
