#!/usr/bin/env python

##**************************************************************
##
## Copyright (C) 1990-2007, Condor Team, Computer Sciences Department,
## University of Wisconsin-Madison, WI.
## 
## Licensed under the Apache License, Version 2.0 (the "License"); you
## may not use this file except in compliance with the License.  You may
## obtain a copy of the License at
## 
##    http://www.apache.org/licenses/LICENSE-2.0
## 
## Unless required by applicable law or agreed to in writing, software
## distributed under the License is distributed on an "AS IS" BASIS,
## WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
## See the License for the specific language governing permissions and
## limitations under the License.
##
##**************************************************************
import os, sys, time, re, socket, shutil

from optparse import OptionParser
from xml.dom import getDOMImplementation
from xml.dom import minidom
from subprocess import *

VERBOSE              = 1
java_home          = None
work_dir           = "."
all_props          = {}
env_list           = {}
jobtracker_class   = 'org.apache.hadoop.mapred.JobTracker'
tasktracker_class  = 'org.apache.hadoop.mapred.TaskTracker'
#taskrunner_class  = 'org.apache.hadoop.mapred.JobShell'
taskrunner_class  = 'org.apache.hadoop.util.RunJar'

java_opts="-Xmx1000m -Dhadoop.log.dir=. -Dhadoop.log.file=hadoop.log -Dhadoop.id.str= -Dhadoop.root.logger=DEBUG,console"

#bare minimum properties for hadoop. Their default values can be 
#overwritten by user specified options. Appropriate file locations for 
#these properties (and other user specified) are searched through hadoop
#directory and sent with job description.

hadoop_props  = {
    'fs.default.name'       : "hdfs://", \
    'mapred.job.tracker'    : "0.0.0.0:0", \
    'mapred.job.tracker.http.address' : "0.0.0.0:0",\
    'mapred.task.tracker.http.address' : "0.0.0.0:0",\
    'mapred.system.dir' : "${fs.default.name}/tmp/",\
    'mapred.tasktracker.map.tasks.maximum' : "1",\
    'mapred.tasktracker.reduce.tasks.maximum' : "1", \
    'hadoop.tmp.dir' : "@CWD@/tmp/", \
    'mapred.temp.dir' : "@CWD@/temp/", \
    'mapred.local.dir' : "@CWD@/local/", \
}

####  ERROR CODES    #####
# 1 Missing JOB parameters
# 2 Missing path to hadoop directory
# 3 Missing JAVA_HOME
# 4 Failure to extract version for hadoop installation
# 5
####  END ERROR CODE #####



###########################################################
def log(str):
  if VERBOSE:
    print str

############################################################
def create_work_dir(dir):
  global work_dir

  if dir != None:
    work_dir = dir
 
  log("Using work directory = %s" %  work_dir) 
  if not os.path.exists(work_dir):
    log("Work directory doesn't exist, creating...");
    os.mkdir(work_dir)

############################################################
def init(parser):
  global VERBOSE
  global all_props
  global hadoop_props
  global java_home
  global env_list
  global work_dir

  missing_argumetns = []
  (options, args) = parser.parse_args()
  if options.verbose:
    VERBOSE = 1

  if (options.is_execute):
    execute()
    return

  create_work_dir(options.work_dir)

  if (options.submit):
    submit(work_dir)
    return

  if (options.clear_log):
    import glob
    for f in glob.glob('job_*_conf.xml'):
      os.remove(f)
    for f in glob.glob('err.*'):
      os.remove(f)
    for f in glob.glob('outfile.*'):
      os.remove(f)
    for f in glob.glob('*.log'):
      os.remove(f)
    return

  #if job.desc file exists, lists default from the 
  job_desc = {}
  if os.path.exists('%s/job.desc'%work_dir):
    f = open('%s/job.desc'%work_dir, 'r')
    line = f.readline()
    while ( line != '' ):
      vals = line.strip().split('=')
      if len(vals) >=2 :
        job_desc[vals[0]] = vals[1].split(';')[0]
      line = f.readline()

  user_job_args = None
  if len(args) >= 1:
    user_job_args = args[0]
    if not os.path.exists(user_job_args):
      parser.error('Path to job jar file does not exist!');
    env_list['_MR_JOB_ARGS'] = '%s %s'%(os.path.basename(user_job_args), ' '.join(args[1:]))
    env_list['_MR_JOB_PATH'] = '%s'%user_job_args
  else:
    if '_MR_JOB_PATH' in job_desc and '_MR_JOB_ARGS' in job_desc:
      user_job_args = job_desc['_MR_JOB_PATH']
      env_list['_MR_JOB_PATH'] = '%s'%job_desc['_MR_JOB_PATH']
      env_list['_MR_JOB_ARGS'] = '%s'%job_desc['_MR_JOB_ARGS']
    else:
      parser.error('Please specify the jar file to submit as MapReduce job');
      
  hadoop_dir = ""
  if options.hadoop_path == None or not os.path.exists(options.hadoop_path):
    if '_HADOOP_LOCAL_HOME' not in job_desc:
      parser.error('You must specify path to hadoop installation if not running in execute mode')
    else:
      hadoop_dir = job_desc['_HADOOP_LOCAL_HOME']
  else:
    hadoop_dir = options.hadoop_path

  env_list['_HADOOP_LOCAL_HOME'] = hadoop_dir;

  java_home = None
  if options.java_home == None:
    if '_JAVA_PATH' in job_desc:
      java_home = job_desc['_JAVA_PATH']
  else:
    java_home = options.java_home

  if (java_home != None):
    env_list['_JAVA_PATH'] = java_home
  else:
    parser.error('java home is not defined. use -j JAVA_HOME!');
   
  hadoop_version=get_version(hadoop_dir)
  log("Hadoop local path %s, version=%s" % (hadoop_dir, str(hadoop_version)) )   

  log("Building properties-filename map for default hadoop properties")
  files = find(hadoop_dir, '*-default.xml')
  #if  len(files) == 0 and not store_values:
  if len(files) == 0:
     msg="Failed to read default configuration files (*-default.xml) from hadoop directory.\n"
     msg="%s Make sure that you specified correct path to a hadoop instllation" % msg
     raise Exception(msg)

  read_configs(files, all_props)

  log("Reading existing properties files under working dir")
  files = find(work_dir, '*-site.xml')
  read_configs(files, hadoop_props, True)

  log("Handling any command line configuration values specified by user")
  if options.configs != None:
    for i in options.configs:
      k_v = i.split('=')
      if len(k_v) < 2:
        log("skipping %s" % k_v)
        continue
      hadoop_props[k_v[0]] = k_v[1]

  #handle any explicitly specified options
  nn = None
  if options.name_node != None:
    nn=options.name_node
  else:
    if '_HADOOP_NN' in job_desc:
      nn = job_desc['_HADOOP_NN']

  if nn != None:
    hadoop_props['fs.default.name'] = nn
    hadoop_props['mapred.system.dir'] = '%s/tmp'%(nn)
    env_list['_HADOOP_NN'] = nn
  else:
    parser.error('You must specify URL for name node!')

  if options.max_maps != None:
    hadoop_props['mapred.tastracker.map.tasks.maximum'] = options.max_maps

  if options.max_reduce != None:
    hadoop_props['mapred.tasktracker.redcue.tasks.maximum'] = options.max_reduce
 
  site_files = generate_configs(hadoop_props)

  #build a list of 
  jars = hadoop_jar_list(hadoop_dir, hadoop_version)
  exe=""

  if (os.getcwd() != os.path.abspath(work_dir)):
     exe="%s/%s" %(os.getcwd(), sys.argv[0])
     ret = call(["cp", exe, work_dir])
     if ret != 0:
       raise Exception('Failed to copy hadoop jars to work dir')

  #create condor submit file
  f = file("%s/job.desc"%work_dir, 'w')

  print >> f, "#######################################################################"
  print >> f, "##                    Condor MapReduce Submit File                  ##"
  print >> f, "#######################################################################"

  print >> f, "\nuniverse = parallel"
  print >> f, "\nexecutable = mrscript.py"
  print >> f, "\narguments = -e"
  print >> f, "\noutput = outfile.$(NODE)"
  print >> f, "\nerror  = err.$(NODE)"
  print >> f, "\nmachine_count  = %s"%options.machine_count
  print >> f, "\nshould_transfer_files  = yes"
  print >> f, "\nwhen_to_transfer_output  = on_exit"

  print >> f, "\nenvironment = \\"
  for env in env_list:
    print >> f, "\t\t %s=%s; \\"%(env, env_list[env])

  file_transfer_list = {}
  print >> f, "\ntransfer_input_files = \\"
  for jar in jars:
    file_transfer_list[jar] = 1

  for site_file in site_files:
    file_transfer_list[site_file] = 1

  if options.user_file_list != None:
    for user_file in options.user_file_list:
      file_transfer_list[user_file] = 1

  if user_job_args != None:
    file_transfer_list[user_job_args] = 1

  for k in file_transfer_list.keys():
    print >> f, " \t\t %s, \\"%k

  print >> f, "\nqueue"
  f.close()

#########################################################################
def find(dir, pattern):
  files = {}
  cmd='find %s -name \"%s\"' % (dir, pattern)
  log("Executing %s" % cmd)
  my_stdout = os.popen(cmd)
  paths=my_stdout.readlines()

  if paths == None or my_stdout.close() != None:
    return files
    
  for p in paths:
    xmlFile = p.strip()
    if os.path.isfile(xmlFile):
       subsystem = os.path.basename(xmlFile).split('-')
       if not subsystem[0] in files:
         files[subsystem[0]] = xmlFile

  log("file matching %s are %s" %(pattern, str(files)))

  return files

############################################################################
def read_configs(files, props, store_values=False):
  for k, path in files.iteritems():
    xmldoc = minidom.parse(path)
    prop_nodes = xmldoc.getElementsByTagName('property')    
    for el in prop_nodes:
     n_v = get_property(el)
     if (store_values):
       props[n_v[0].strip()] = n_v[1].strip()
     else:
       props[n_v[0].strip()] = "%s-site.xml" % k

##############################################################################
def get_property(xml_el): 
  prop_name = None
  prop_value = ''

  for node in xml_el.childNodes:
    if node.nodeName == "name":           
      prop_name = node.childNodes[0].nodeValue
    if node.nodeName == "value" and len(node.childNodes) > 0:
      prop_value = node.childNodes[0].nodeValue
    
  return [prop_name, prop_value]

#############################################################################
def generate_configs(props):   
  global all_props
  global work_dir

  xmlImpl = getDOMImplementation()
  _elems = {}
  _docs  = {}

  for k,v in props.iteritems():
    if not all_props.has_key(k):
      log("Skipping %s not present in default files" % k)
      continue

    e = all_props[k]
    el = None
    doc = None
    if e in _elems:
      el = _elems[e]
      doc = _docs[e]
    else:
      doc = xmlImpl.createDocument('', 'configuration', None)
      comment = doc.createComment('This is an auto generated files, do not modify')
      el = doc.documentElement
      el.appendChild(comment)
      _elems[e] = el
      _docs[e]  = doc

    p = create_property(doc, k, v)
    el.appendChild(p)

  site_files = []
  for e in _elems:
    site_file = os.path.join(work_dir, e)
    site_files.append(e)
    f = file(site_file, 'w')
    print >> f, _elems[e].toxml(encoding="utf-8")
    f.close()

  return site_files

#############################################################################
def create_property(doc, name, value, final = False):
    prop = doc.createElement("property")
    nameP = doc.createElement("name")
    string = doc.createTextNode(name)
    nameP.appendChild(string)
    valueP = doc.createElement("value")
    string = doc.createTextNode(value)
    valueP.appendChild(string)
    if final:
      finalP = doc.createElement("final")
      string = doc.createTextNode("true")
      finalP.appendChild(string)
    prop.appendChild(nameP)
    prop.appendChild(valueP)
    if final:
      prop.appendChild(finalP)
    
    return prop

##########################################################################
def get_version(hadoop_path):
  global java_home
  global env_list

  hadoopVer = { 'major' : None, 'minor' : None }
  hadoopPath = os.path.join(hadoop_path, 'bin', 'hadoop')
  cmd = "%s version" % hadoopPath
  log("Determining hadoop version: %s " % cmd)
  
  env=os.environ
  env['JAVA_HOME']=java_home
  p = Popen(cmd, shell=True, stdout=PIPE, close_fds=True, env=env)
  verString = p.stdout.readline()
  if  p.wait() == 0:
    log("Hadoop version string is %s" % verString)
    reVerString = re.compile("Hadoop ([0-9]+)\.([0-9]+).*")
    verMatch = reVerString.match(verString)
    if verMatch != None:
      hadoopVer['major'] = verMatch.group(1)
      hadoopVer['minor'] = verMatch.group(2)
    else:
      raise Exception("Failed to identify version string for hadoop!")
  
  return hadoopVer

###########################################################################
#return list of hadoop jar files to be sent as part of job description. 
def hadoop_jar_list(hadoop_path, hadoop_version):
  global env_list

  jars = []
  cmd='find %s/lib -name "*.jar"' % hadoop_path
  my_stdout = os.popen(cmd)
  while 1:
    p = my_stdout.readline()
    if p == None or len(p) == 0:
      break
    jars.append(p.strip())

  if len(jars) == 0:
    raise Exception("Failed to determine list of hadoop jar files to transfer")
 
  major = hadoop_version['major']
  minor = hadoop_version['minor']
  cmd = 'find %s -maxdepth 1 -name "hadoop-%s.%s*core*.jar"' %(hadoop_path, major, minor)
  p = Popen(cmd, shell=True, stdout=PIPE, close_fds=True)
  path = p.stdout.readline()   
  if path != None and len(path) > 0:
    jars.append(path.strip())
    env_list['_HADOOP_JAR_FILE']=os.path.basename(path.strip())
  else:
    raise Exception("Failed to determine list of core hadoop jar file to transfer")

  return jars

#############################################################################
def execute():  
  slot_id = 0
  print os.environ
  if os.environ['_CONDOR_PROCNO']:
    slot_id = int(os.environ['_CONDOR_PROCNO'])

  cwd=os.getcwd()
  cmd = 'find . -name \"*.jar\" -printf \"%f:\"'
  p = Popen(cmd, shell=True, stdout=PIPE, close_fds=True)
  output = p.stdout.readlines()
  jars = output[0].split(':')

  classpath = '%s/conf:%s:%s/webapps/' %(cwd, cwd, cwd)
  for cls in jars:
     classpath = '%s:%s/%s' %(classpath, cwd, cls)

  if slot_id == 0:
    log("executing job tracker")
    execute_jobtracker(classpath)
  else:
    log("executing task tracker ")
    execute_tasktracker(classpath)

###############################################################
def update_xml_params(params):
  cmd = 'find . -name \"*-site.xml\" -maxdepth 1'
  p = Popen(cmd, shell=True, stdout=PIPE, close_fds=True)
  xml_configs = p.stdout.readlines()
  for config in xml_configs:
    is_modified = True
    xmldoc = minidom.parse(config.strip())
    els = xmldoc.getElementsByTagName('name')
    for el in els:
      k = el.childNodes[0].data.strip()
      if params.has_key(k):
        v = el.parentNode.childNodes[1].childNodes[0].data.strip()
        #if value of any property in paths is to its default
        #modify that path to current working dir
        parent = el.parentNode
        parent.childNodes[1].childNodes[0].data = "%s"%(params[k])
        is_modifed = True

    new_config = file('conf/%s'%config.strip(), 'w')
    print >> new_config, xmldoc.toxml(encoding="utf-8")
    log(xmldoc.toxml())
    new_config.close()

################################################################
def execute_jobtracker(classpath):
  global hadoop_props

  cwd = os.getcwd()
  #cwd = "/data2/slot1/"

  if cwd == "/data2/slot1/":
     parent = "/data2/slot1"
     for p in os.listdir(parent):
       name = "%s/%s"%(parent, p)
       if os.path.isdir(name):
         shutil.rmtree(name)
       else:
         os.remove(name)
 

  updates = {}
  updates['hadoop.tmp.dir']  = '%s/tmp'%cwd
  updates['mapred.temp.dir'] = '%s/temp'%cwd
  updates['mapred.local.dir']= '%s/local'%cwd 

  if not os.path.exists('./conf'):
    os.mkdir('conf')

  update_xml_params(updates)

  #extracting webapps 
  hadoop_jar = os.environ['_HADOOP_JAR_FILE']
  cmd='jar xf %s webapps'%hadoop_jar
  p = Popen(cmd, shell=True, close_fds=True)
  p.wait()

  out=open('jobtracker.log', 'w+')
  cmd='java %s -cp %s %s' %(java_opts, classpath, jobtracker_class)
  log("JobTracker : %s " %cmd)
  p = Popen(cmd, shell=True, stderr=out)
  pid=p.pid
  time.sleep(6)
  print "Job tracker running as process %d" %pid

  jobtracker_port=-1
  jobtracker_webport=-1
  found=-1
  count=0

  try:
    f=open('jobtracker.log', 'r')
    while 1:
      count = count + 1
      line = f.readline()
      if line == None or line == '' or count > 5000:
        break
      if jobtracker_port == -1:
        found=line.rfind('JobTracker up at:')
        if found != -1:
          jobtracker_port = get_port(line)
      else:
        found = line.rfind('JobTracker webserver:')
        if found != -1:
          jobtracker_webport = get_port(line)

  except IOError:
    print "I/O error while reading output of job_tracker, detail"
  except:
    print 'Unexpected error while reading output of job_tracker'
    raise

  if jobtracker_port == -1 or jobtracker_webport == -1:
    raise Exception('Failed to extract port(s) from job tracker\'s log')

  hostname = socket.gethostname()
  log("finding path for condor_chirp")
  cmd='condor_config_val libexec'
  p = Popen(cmd, shell=True, stdout=PIPE)
  chirp_path = p.stdout.readline()
  p.wait()

  enV = os.environ
  enV['PATH']="%s:%s" %(chirp_path.strip(), enV['PATH'])
  cmd='condor_chirp set_job_attr JOB_TRACKER_HOST \"\'%s\'\";\
       condor_chirp set_job_attr JOB_TRACKER_PORT \"\'%s\'\"; \
       condor_chirp set_job_attr JOB_TRACKER_WEB_PORT \"\'%s\'\"' \
       % (hostname, jobtracker_port, jobtracker_webport)

  p = Popen(cmd, shell=True, env=enV)

  if p.wait() != 0:
    raise Exception('Failed to execute chirp for disseminating port information')

  updates['mapred.job.tracker'] ="%s:%s" % (hostname, jobtracker_port)
  updates['mapred.job.tracker.http.address'] ="%s:%s" % (hostname, jobtracker_webport)
  update_xml_params(updates)

  out=open('job.log', 'w+')
  user_job = os.environ['_MR_JOB_ARGS']
  user_job_param = user_job.split(' ')

  ext = user_job_param[0].split('.');
  ext = ext[len(ext) - 1];
  pid = -1

  if (ext == 'jar'):
    classpath = '%s:%s'%(classpath, user_job_param[0])
    cmd='java %s -cp %s %s %s' %(java_opts, classpath, taskrunner_class, user_job)
    p = Popen(cmd, shell=True, stdout=out, stderr=out, close_fds=True)
    pid = p.pid
  else:
    cmd=user_job
    p = Popen(cmd, shell=True, stdout=out, stderr=out, close_fds=True)
    pid = p.pid

  if (os.environ['_CONDOR_NPROCS'] == '1'):
    #FIXME: Executing tasktracker is going to redo some steps that can
    #be avoided. 
    execute_tasktracker(classpath, False)

  os.waitpid(pid, 0)

  #Here our job should have finished, but we won't exit right away instead
  #give some time to Parall Universe for properly transfering all trackers related 
  #log files.

  cmd='condor_chirp set_job_attr MR_JOB_EXIT \"\'1\'\"'
  p = Popen(cmd, shell=True, env=enV, stdout=PIPE, stderr=PIPE)
  p.wait()
  print p.stdout.readlines()
  print p.stderr.readlines()
  time.sleep(10)

  return pid

#################################################################
def execute_tasktracker(classpath, blocking=True):
  global hadoop_options

  job_attrs={
         'JOB_TRACKER_HOST' : '', \
         'JOB_TRACKER_PORT'  : '', \
         'JOB_TRACKER_WEB_PORT' : ''
        }
  
  if not os.path.exists('./conf'):
    os.mkdir('conf')

  cmd='condor_config_val libexec'
  p = Popen(cmd, shell=True, stdout=PIPE)
  chirp_path = p.stdout.readline()
  p.wait()
  enV = os.environ
  enV['PATH']="%s:%s" %(chirp_path.strip(), enV['PATH'])
 
  trials = 0
  i=0
  while (trials <= 20 and i < len(job_attrs)):
    trials = trials + 1
    k = job_attrs.keys()[i]
    cmd='condor_chirp get_job_attr %s' %k
    p = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE, env=enV, close_fds=True)
    log(p.stderr.readlines())
    out = p.stdout.readline()
    if out != None and len(out) != 0:
      job_attrs[k] = out.strip().split('\'')[1]
    if (p.wait() == 0):
      i = i + 1
    time.sleep(1)
  
  updates = {}
  updates['mapred.job.tracker'] ="%s:%s" % (job_attrs['JOB_TRACKER_HOST'],
               job_attrs['JOB_TRACKER_PORT'])
  updates['mapred.job.tracker.http.address'] ="%s:%s" % (job_attrs['JOB_TRACKER_HOST'], 
               job_attrs['JOB_TRACKER_WEB_PORT'])

  cwd=os.getcwd()
  #cwd = "/data2/slot1"
  if cwd == "/data2/slot1/":
     parent = "/data2/slot1"
     for p in os.listdir(parent):
       name = "%s/%s"%(parent, p)
       if os.path.isdir(name):
         shutil.rmtree(name)
       else:
         os.remove(name)
 
  updates['hadoop.tmp.dir']   = '%s/tmp'%cwd
  updates['mapred.temp.dir']  = '%s/temp'%cwd
  updates['mapred.local.dir'] = '%s/local'%cwd

  update_xml_params(updates)

  #extracting webapps 
  hadoop_jar = os.environ['_HADOOP_JAR_FILE']
  cmd='jar xf %s webapps'%hadoop_jar
  p = Popen(cmd, shell=True, close_fds=True)
  p.wait()
 
  ttlog = 'tasktracker%s.log'%(os.environ['_CONDOR_PROCNO'])
  out=open(ttlog, 'w+')
  cmd='java %s -cp %s %s' %(java_opts, classpath, tasktracker_class)
  print cmd
  p = Popen(cmd, shell=True, stderr=out)
  pid=p.pid

  if blocking:
    cmd='condor_chirp get_job_attr MR_JOB_EXIT'
    while True:
      p = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE, env=enV, close_fds=True)
      if (p.wait() == 0):      
        os.kill(pid, 9)
        break


#################################################################
def submit(work_dir):
  if not os.path.exists('%s/job.desc'%work_dir):
    raise Exception("No job.desc file found")
 
  cmd='condor_submit job.desc'
  p = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE, close_fds=True)
  out =  p.stdout.readlines()
  err = p.stderr.readlines()
  job_id = -1

  if (p.wait() == 0 and len(out) >=2):
    for ind in out:
      if ind.find('cluster') != -1:        
        s1 = ind.split(' ');
        s1 = s1[len(s1) -1];
        job_id = s1.replace('.', '').strip()
  else:
    print '\n'.join(err)

  if (job_id != -1):    
    url = submit_query(job_id);
    if len(url) >= 3:
      track="http://%s:%s/"%(url['JOB_TRACKER_HOST'], url['JOB_TRACKER_WEB_PORT'])
      print "Track your job at : %s" % track.replace('\'', '')
  else:
    print("Job submission failed!");

#################################################################
def submit_query(job_id):
  job_running = False
  url = {}

  while True:
    if not job_running:
      cmd='condor_q %s |grep -v "Submitter" |grep %s'%(job_id, job_id)
      p = Popen(cmd, shell=True, stdout=PIPE)
      out = p.stdout.readlines()
      if (p.wait() == 0 and len(out) >= 1):
        s1 = out[0].split()
        if s1[5] == 'R':
          job_running = True
      else:
        print("No job found!")
        break
 
    if job_running:
      cmd="condor_q %s -l |grep -Ee 'JOB_TRACKER_HOST|JOB_TRACKER_PORT|JOB_TRACKER_WEB_PORT'"%job_id
      p = Popen(cmd, shell=True, stdout=PIPE)
      out = p.stdout.readlines()
      if (p.wait() == 0 and len(out) >=3):
        for kv in out:
          s1 = kv.split('=')
          url[s1[0].strip()] = s1[1].strip()
        break
      else:
        #lets check job status again in the next iteration
        job_running = False

    time.sleep(1)

  return url
 
##################################################################
def get_port(line):
  log("get_port %s " % line)
  t=line.split(':')
  port = 0;
  try:
    port=int(t[len(t) -1].strip())
  except ValueError:
    return -1

  return port

###################################################################
def main():
  usage  = "usage: %prog [options] <job>.jar"
  
  parser = OptionParser(usage=usage, version="%prog 1.0")

  parser.add_option("-f", "--add-file", dest="user_file_list", action="append",
                   help="Files to be shipped along with this job. Can be used multiple times")

  parser.add_option("-m", "--max-mappers", dest="max_maps",metavar="NUM",
                   help="Maximum number of mappers per slot")

  parser.add_option("-r", "--max-reducers", dest="max_reduce", metavar="NUM",
                   help="Maximum number of reducers per slot")

  parser.add_option("-p", "--hadoop-dir", dest="hadoop_path", metavar="PATH",
                   help="Maximum number of reducers per slot")

  parser.add_option("-e", "--execute", dest="is_execute", action="store_true",
                   help="Execute the user code for MapReduce job")

  parser.add_option("-v", "--verbose", dest="verbose", action="store_true")

  parser.add_option("-o", "--job-jar", dest="job_jar", metavar="JAR",
                   help="Jar file containing code for MapReduce job")

  parser.add_option("-j", "--java-home", dest="java_home", metavar="PATH",
                   help="Overide JAVA_HOME with this path")

  parser.add_option("-s", "--submit", dest="submit", action="store_true",
                   help="Make a submission of job.desc file under working directory and retrieves the URL for the job tracker.")

  parser.add_option("-a", "--append-config", dest="configs", action="append",
                   help="Append to hadoop config files")

  parser.add_option("-c", "--machine-count", dest="machine_count", metavar="NUM", default=1,
                   help="Relates to machine_count in Condor's job description file default is 1")

  parser.add_option("-n", "--name-node", dest="name_node", metavar="URL",
                   help="Specify number of machines to run MapReduce on")

  parser.add_option("-w", "--work-dir", dest="work_dir", metavar="PATH",
                   help="A working directory to store any temperory or intermediate files")

  parser.add_option("-l", "--clear-log", dest="clear_log", action="store_true",
                   help="Clear working directory of any log files")

    
  init(parser)
   
if __name__ == "__main__":
    main()
