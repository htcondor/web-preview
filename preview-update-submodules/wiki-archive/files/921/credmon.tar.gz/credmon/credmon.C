#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#define BADBAD_SVID_SOURCE
/* print files in current directory in reverse order */
#include <dirent.h>
#include <string.h>
#include <fnmatch.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>


#ifndef SUBSYS
  #define SUBSYS "DEFAULT"
#endif

int ccfilter(const dirent*d) {
  bool match = !fnmatch("*.cred", d->d_name, FNM_PATHNAME);
  // printf("d: %s, %i\n", d->d_name, match);
  return match;
}

void process_cred_file(char *fname) {
   char * src = fname;
   char * trg = strdup(src);
   strcpy((trg + strlen(src) - 5), ".cc");
   printf("%i: FOUND %s CREATE %s\n", time(0), src, trg);
   FILE *cc = fopen(trg, "w");
   fprintf(cc, "KRB5CCACHE: %i\n", time(0));
   fclose(cc);
   free(trg);

   // could aklog here if needed
}

void scantokens() {
   struct dirent **namelist;
   int n;

   n = scandir(".", &namelist, &ccfilter, alphasort);
   if (n < 0)
       perror("scandir");
   else {
       while (n--) {
           process_cred_file(namelist[n]->d_name);
	   free(namelist[n]);
       }
       free(namelist);
   }
   fflush(stdout);

   // "signal" that we have done our duty, either by dropping a file:
   system("touch CREDMON_COMPLETE");
   // or by invoking a condor signalling tool:
   //     system("condor_notify READY");

}


// Define the function to be called when ctrl-c (SIGINT) signal is sent to process
void
signal_callback_handler(int signum)
{
   if(signum == SIGHUP) {
      printf("%i: ** GOT SIGHUP\n", time(0));
      fflush(stdout);
      // scantokens(); (called in main after sleep!)
      return;
   }

   printf("%i: Caught signal %d, terminating!\n", time(0), signum);
   fflush(stdout);
   // Terminate program
   exit(0);
}

int main()
{
   // open log file
   umask(022);
   freopen("/scratch/zmiller/CRED_DIR_" SUBSYS "/credmon.log", "w", stdout);

   // drop pid file
   FILE* pidfile = fopen("/scratch/zmiller/CRED_DIR_" SUBSYS "/pid", "w");
   fprintf(pidfile, "%i\n", getpid());
   fclose(pidfile);

   chdir("/scratch/zmiller/CRED_DIR_" SUBSYS);

   // all files readable by root only
   umask(077);

   // Register signal and signal handler
   signal(SIGHUP, signal_callback_handler);
   signal(SIGTERM, signal_callback_handler);
   signal(SIGINT, signal_callback_handler);

   while(1)
   {
      scantokens();
      printf("%i: Sleeping 60.\n", time(0));
      fflush(stdout);
      sleep(60);
   }
   return 0;
}

