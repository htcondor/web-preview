#!/usr/bin/env perl

  # Generate a job classad:
  print "Cmd = \"C:\\WINDOWS\\system32\\ipconfig.exe\"\n";
  print "Iwd = \"C:\\TEMP\\hooks\"\n";
  print "Owner = \"pmackinn\"\n";
  print "User = \"pmackinn\@redhat.com\"\n";
  print "Out = \"C:\\TEMP\\hooks\\hook-output.$$\"\n";
  print "JobUniverse = 5\n";
  print "JobLeaseDuration = 500000\n";
  print "IsFetched = TRUE\n";
  