/*
The ClassAd Catalog is Copyright (C) 2002 Douglas Thain and the Condor Team
This software is released under the GNU General Public License.
See the file COPYING for details.
*/

#ifndef CATALOG_UPDATE_H
#define CATALOG_UPDATE_H

#include "catalog_server.h"
#include "datagram.h"

/* An update can be no larger than a UDP datagram */
#define CATALOG_UPDATE_MAX DATAGRAM_PAYLOAD_MAX

struct catalog_update * catalog_update_create( const char *host, int port );
int                     catalog_update_write( struct catalog_update *cu, const char *update );
void                    catalog_update_delete( struct catalog_update *cu );

#endif
