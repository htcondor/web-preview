/*
The ClassAd Catalog is Copyright (C) 2002 Douglas Thain and the Condor Team
This software is released under the GNU General Public License.
See the file COPYING for details.
*/

#ifndef CATALOG_CLIENT_H
#define CATALOG_CLIENT_H

#include "catalog_server.h"

struct catalog_query * catalog_query_create( const char *host, int port );
int    catalog_query_begin( struct catalog_query *cc, const char *query, int timeout );
char * catalog_query_read( struct catalog_query *cc, int timeout);
void   catalog_query_delete( struct catalog_query *cc );

#endif
