
package condor.gahp;

/**
 *
 * @author  ckireyev
 */
public interface CleanupStep {
    public void doCleanup();    
}
