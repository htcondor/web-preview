package condor.gahp.gt3;

import condor.gahp.*;
import condor.gahp.gsi.GSIUtils;

import org.globus.ogsa.impl.base.gram.client.*;
import org.globus.ogsa.impl.security.authentication.Constants;
import org.globus.ogsa.impl.security.authorization.Authorization;
import org.globus.ogsa.impl.security.authorization.SelfAuthorization;
import org.globus.ogsa.base.gram.types.JobStateType;

import org.globus.ogsa.base.gram.service.ManagedJobServiceGridLocator;
import org.globus.ogsa.impl.security.authorization.SelfAuthorization;
import org.gridforum.ogsi.GridService;
import org.globus.ogsa.impl.base.gram.client.GramRsl2XmlConverter;
import org.globus.rsl.ParseException;
import org.gridforum.ogsi.GridService;
import org.gridforum.ogsi.OGSIServiceLocator;
import org.globus.ogsa.handlers.GrimProxyPolicyHandler;
import org.globus.ogsa.impl.security.authentication.Constants;
import org.globus.ogsa.utils.AnyHelper;
import org.gridforum.ogsi.ExtensibilityType;
import org.globus.ogsa.types.properties.PropertiesDetailType;
import org.gridforum.ogsi.EntryType;
import org.globus.ogsa.base.gram.service.ManagedJobServiceLocator;
import org.gridforum.ogsi.EntryContentType;
import org.gridforum.ogsi.ServiceDataValuesType;
import org.gridforum.ogsi.Factory;
import org.globus.ogsa.utils.QueryHelper;
import org.globus.ogsa.impl.security.authorization.Authorization;
import org.globus.ogsa.ServiceData;
import org.gridforum.ogsi.TerminationTimeType;
import org.gridforum.ogsi.ExtendedDateTimeType;
import org.globus.ogsa.base.gram.ManagedJobPortType;
import org.gridforum.ogsi.LocatorType;
import org.globus.ogsa.utils.GridServiceFactory;
import org.globus.ogsa.impl.base.gram.utils.rsl.RslParser;
import org.globus.ogsa.impl.base.gram.utils.rsl.RslParseException;
import org.globus.ogsa.impl.base.gram.utils.rsl.RslParserFactory;
import org.globus.ogsa.base.gram.types.JobStatusType;
import org.globus.axis.gsi.GSIConstants;
import org.globus.ogsa.base.gram.types.JobStateType;
import org.w3c.dom.Element;
import javax.xml.namespace.QName;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;
import org.gridforum.jgss.ExtendedGSSManager;
import org.gridforum.ogsi.HandleType;
import javax.xml.rpc.Stub;
import java.net.URL;

public class Gt3GramJobCancelHandler implements CommandHandler {

    private GahpInterface gahp = null;

    public void setGahp (GahpInterface g) {
        gahp = g;
    }
    
    public CommandHandlerResponse handleCommand (String[] cmd) {
        Integer reqId = null;
        String contactString = null;

        try {
            // cmd[0] = GRAM_JOB_REQUEST
            reqId = new Integer(cmd[1]);
            contactString = cmd[2];
        }
        catch (Exception e) {
            e.printStackTrace(System.err);
            return CommandHandlerResponse.SYNTAX_ERROR;
        }
        
        return new CommandHandlerResponse (
            CommandHandlerResponse.SUCCESS,
            new JobCancelRunnable(reqId.intValue(), contactString) );
    } // handleCommand
    
    class JobCancelRunnable implements Runnable {
        private int requestId;
        private String job_gsh;
        
        public JobCancelRunnable (int reqId, String gsh) {
            this.requestId = reqId;
            this.job_gsh = gsh;
        }
        
        public void run() {
            // Job status code
            int statusCode = 0;
            
            try {
                OGSIServiceLocator locator = new OGSIServiceLocator();
                GridService gridService =
                    locator.getGridServicePort(new URL(job_gsh));

                GrimProxyPolicyHandler grimPolicyHandler = new GrimProxyPolicyHandler();
                grimPolicyHandler.reset();

                ((Stub)gridService)._setProperty(Constants.GSI_SEC_CONV,
                                                 Constants.SIGNATURE);
                ((Stub)gridService)._setProperty(Constants.GRIM_POLICY_HANDLER,
                                                 grimPolicyHandler);
                ((Stub)gridService)._setProperty(Constants.AUTHORIZATION,
                                                 SelfAuthorization.getInstance());
                GSSCredential cred = GSIUtils.getCredential (gahp);
                if ( cred != null ) {
                    ((Stub)gridService)._setProperty(GSIConstants.GSI_CREDENTIALS,cred);
                } 
                
                gridService.destroy();
            } catch (Exception e) {
                System.err.println("cancel failed: ");
                e.printStackTrace(System.err);
                
                String errorMessage = (e.getMessage()==null)?"unknown":e.getMessage();
                String [] result = {
                    ""+1, //result code
                    errorMessage}; // job state

                gahp.addResult (requestId, result);    
            }
            
            String[] result = { "0", "NULL" };
            gahp.addResult (requestId, result);

        }
    }
} // GRAM_JOB_CANCEL_Handler
