package condor.gahp.gt3;

import condor.gahp.*;
import condor.gahp.gsi.GSIUtils;

import java.util.HashMap;

import org.globus.ogsa.client.managers.NotificationSinkManager;
import org.globus.ogsa.impl.security.authentication.Constants;
import org.globus.ogsa.handlers.GrimProxyPolicyHandler;
import org.globus.ogsa.impl.security.authorization.SelfAuthorization;
import org.globus.ogsa.base.gram.ManagedJobPortType;
import org.globus.axis.gsi.GSIConstants;
import org.ietf.jgss.GSSCredential;

public class Gt3GramCallbackAllowHandler implements CommandHandler {
    private GahpInterface gahp;
    public void setGahp (GahpInterface g) {
        gahp = g;
    }

    public CommandHandlerResponse handleCommand (String[] cmd) {
        Integer reqId = null;
        Integer port = null;    
        try {
            reqId = new Integer(cmd[1]);
            port = new Integer(cmd[2]);
        }  catch (Exception e) {
            e.printStackTrace(System.err);
            return CommandHandlerResponse.SYNTAX_ERROR;
        }
    
        // This is an immediate command, do it here
        NotificationSinkManager manager = null; 
        try {
            manager = createNotificationSinkManager ();
        }
        catch (Exception e) {
            e.printStackTrace(System.err);
            return new CommandHandlerResponse (
                                               CommandHandlerResponse.FAILURE+" 1 "+IOUtils.escapeWord(e.getMessage()));
        }

        CallbackSink callbackSink = new CallbackSink (
            manager,
            reqId.intValue(),
            gahp);

        String callbackID = gahp.generateUniqueId();
        CallbackSink.storeCallbackSink (gahp, callbackID, callbackSink);
        gahp.addCleanupStep ((CleanupStep)callbackSink);

        return new CommandHandlerResponse (
            CommandHandlerResponse.SUCCESS + " " + callbackID);
    }    

    private NotificationSinkManager createNotificationSinkManager()  throws Exception{
        NotificationSinkManager notificationSinkManager
            = NotificationSinkManager.getInstance("Secure");

        notificationSinkManager.startListening();

        GrimProxyPolicyHandler grimPolicyHandler = new GrimProxyPolicyHandler();
        grimPolicyHandler.reset();

        HashMap notificationSinkProperties = new HashMap();
        notificationSinkProperties.put( Constants.GSI_SEC_CONV,
                                        Constants.SIGNATURE );
        notificationSinkProperties.put( Constants.GRIM_POLICY_HANDLER,
                                        grimPolicyHandler);
        notificationSinkProperties.put( Constants.AUTHORIZATION,
                                        SelfAuthorization.getInstance());
        notificationSinkProperties.put(GSIConstants.GSI_MODE, 
                                       GSIConstants.GSI_MODE_LIMITED_DELEG);
        GSSCredential cred =GSIUtils.getCredential(gahp);
        if ( cred != null ) {
            notificationSinkProperties.put(GSIConstants.GSI_CREDENTIALS,cred);
        }
        notificationSinkManager.init(notificationSinkProperties);
        return notificationSinkManager;
    }

}
 
