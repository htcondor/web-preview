package condor.gahp.gt3;

import condor.gahp.*;
import condor.gahp.gsi.GSIUtils;

import org.globus.ogsa.impl.base.gram.client.*;
import org.globus.ogsa.impl.security.authentication.Constants;
import org.globus.ogsa.impl.security.authorization.Authorization;
import org.globus.ogsa.impl.security.authorization.SelfAuthorization;
import org.globus.ogsa.base.gram.types.JobStateType;

import org.globus.ogsa.base.gram.service.ManagedJobServiceGridLocator;
import org.globus.ogsa.impl.security.authorization.SelfAuthorization;
import org.gridforum.ogsi.GridService;
import org.globus.ogsa.impl.base.gram.client.GramRsl2XmlConverter;
import org.globus.rsl.ParseException;
import org.gridforum.ogsi.GridService;
import org.gridforum.ogsi.OGSIServiceLocator;
import org.globus.ogsa.handlers.GrimProxyPolicyHandler;
import org.globus.ogsa.impl.security.authentication.Constants;
import org.globus.ogsa.utils.AnyHelper;
import org.gridforum.ogsi.ExtensibilityType;
import org.globus.ogsa.types.properties.PropertiesDetailType;
import org.gridforum.ogsi.EntryType;
import org.globus.ogsa.base.gram.service.ManagedJobServiceLocator;
import org.gridforum.ogsi.EntryContentType;
import org.gridforum.ogsi.ServiceDataValuesType;
import org.gridforum.ogsi.Factory;
import org.globus.ogsa.utils.QueryHelper;
import org.globus.ogsa.impl.security.authorization.Authorization;
import org.globus.ogsa.ServiceData;
import org.gridforum.ogsi.TerminationTimeType;
import org.gridforum.ogsi.ExtendedDateTimeType;
import org.globus.ogsa.base.gram.ManagedJobPortType;
import org.gridforum.ogsi.LocatorType;
import org.globus.ogsa.utils.GridServiceFactory;
import org.globus.ogsa.impl.base.gram.utils.rsl.RslParser;
import org.globus.ogsa.impl.base.gram.utils.rsl.RslParseException;
import org.globus.ogsa.impl.base.gram.utils.rsl.RslParserFactory;
import org.globus.ogsa.base.gram.types.JobStatusType;
import org.globus.axis.gsi.GSIConstants;
import org.globus.ogsa.base.gram.types.JobStateType;
import org.globus.ogsa.impl.base.gram.client.*;
import org.globus.ogsa.NotificationSinkCallback;
import org.globus.ogsa.client.managers.NotificationSinkManager;
import org.globus.ogsa.impl.core.service.ServicePropertiesImpl;
import org.globus.ogsa.ServicePropertiesException;
import org.w3c.dom.Element;
import javax.xml.namespace.QName;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;
import org.gridforum.jgss.ExtendedGSSManager;
import org.gridforum.ogsi.HandleType;
import javax.xml.rpc.Stub;
import java.net.URL;
import java.io.StringReader;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public  class Gt3GramJobStartHandler implements CommandHandler {
    private GahpInterface gahp;
    
        public void setGahp (GahpInterface g) {
            gahp = g;
        }

    public CommandHandlerResponse handleCommand (String[] cmd) {
            Integer reqId;
            String contactString = null;
            String callbackContact = null;
            boolean fullDelegation = false;

            try {
                    reqId = new Integer(cmd[1]);
                    contactString = cmd[2];

            }
            catch (Exception e) {
                    e.printStackTrace(System.err);
                    return CommandHandlerResponse.SYNTAX_ERROR;
            }

            StartGramJob toRun = new StartGramJob (reqId, 
                                               contactString, 
                                               fullDelegation,
                                               gahp);

            return new CommandHandlerResponse (
                    CommandHandlerResponse.SUCCESS,
                    toRun);
    }

    class StartGramJob implements Runnable {
            public final String jobGSH;
            public final Integer requestID;
            private String callbackContact;
            private GahpInterface gahp;
            private boolean fullDelegation;
            
            public StartGramJob (Integer requestID, 
                            String jobGSH, 
                            boolean fullDelegation,
                            GahpInterface gahp) {
                    this.jobGSH = jobGSH;
                    this.requestID = requestID;
                    this.gahp = gahp;
                    this.fullDelegation = fullDelegation;
            }
            
            public void run () {
                 try {
                     startJob ();
                 }
                 catch (Exception e) {
                     System.err.println ("Error starting job");
		     e.printStackTrace(System.err);

                    String errorString = e.toString();
                    if (errorString == null) errorString = "unknown";
                    gahp.addResult (
                        requestID.intValue(),
                        new String[] { "1", errorString}
                    ); 
                    return;
                 }

		 // Job started successfully
		 gahp.addResult (
				 requestID.intValue(),
				 new String [] { "0", "NULL" });

            } // run
                   
     
        private  void startJob() throws Exception
	{
            ManagedJobServiceGridLocator serviceLocator =
                    new ManagedJobServiceGridLocator();
            ManagedJobPortType job =
                serviceLocator.getManagedJobPort(new URL(jobGSH));

            GrimProxyPolicyHandler grimPolicyHandler = new GrimProxyPolicyHandler();
            grimPolicyHandler.reset();

            ((Stub)job)._setProperty(Constants.GSI_SEC_CONV,
                                                             Constants.SIGNATURE);
            ((Stub)job)._setProperty(Constants.GRIM_POLICY_HANDLER,
                                                             grimPolicyHandler);
            ((Stub)job)._setProperty(Constants.AUTHORIZATION,
                                                             SelfAuthorization.getInstance());
            ((Stub)job)._setProperty(GSIConstants.GSI_MODE,
                                         (fullDelegation) ?
                                         GSIConstants.GSI_MODE_FULL_DELEG :
                                         GSIConstants.GSI_MODE_LIMITED_DELEG
                                         );
                                         
            
            GSSCredential cred = GSIUtils.getCredential(gahp);
            if ( cred != null ) {
                ((Stub)job)._setProperty(GSIConstants.GSI_CREDENTIALS,cred);
            }

            grimPolicyHandler.reset();

            JobStatusType jobStatusType = job.start();

            if (!grimPolicyHandler.isCalled()) {
                    System.err.println("Error: Expected GRIM credentials");
                    return;
            }
	}
    } // class StartGramJob
} // class GRAM_JOB_REQUEST_Handler
