package condor.gahp.gt3;

import org.globus.ogsa.impl.base.gram.client.GramJobListener;
import org.globus.ogsa.impl.base.gram.client.GramJob;

public class GahpGramJobListener {

    private static int idSeed = 0;

    private final Integer uniqueId;

    public GahpGramJobListener() {
        uniqueId = new Integer (idSeed++);
    }

    public Integer getUniqueId() {
        return uniqueId;
    }

    public void statusChanged(GramJob job) {
	    
        // Must return
        // Request ID -
        // Result Code - job.getID()
        // Job URL - job.getJobId()

        // get id
        String jobStatus = job.getStatusAsString();
    }
}
