/*
 * IOUtils.java
 *
 * Created on November 3, 2003, 6:40 PM
 */

package condor.gahp;

/**
 *
 * @author  ckireyev
 */
public abstract class IOUtils {
    public static String escapeWord (String word) {
        if (word == null) return null;
    
        StringBuffer result = new StringBuffer();
        for (int i=0; i<word.length(); i++) {
            char c = word.charAt(i);
            if (c == ' ') { 
                result.append ('\\');
            } else if (c == '\r' || c == '\n') {
                result.append ('\\');
                c=' ';
            }
            result.append (c);
        }
        return result.toString();
    }
    
}
