#!/bin/bash
export JAVA_HOME=/usr/java/j2sdk1.4.2_03
export CLASSPATH=$JAVA_HOME/lib:$JAVA_HOME/jre/lib:./ajo.jar:./classad.jar:./
export PATH=$JAVA_HOME/bin:$PATH
javac  -verbose -classpath ajo.jar:classad.jar:./ com/fujitsu/arcon/servlet/*.java
javac  -verbose -classpath ajo.jar:classad.jar:./ com/fujitsu/arcon/upl/*.java
javac  -verbose -classpath ajo.jar:classad.jar:./ com/fujitsu/arcon/common/*.java
javac  -verbose -classpath ajo.jar:classad.jar:./ condor/gahp/*.java
javac  -verbose -classpath ajo.jar:classad.jar:./ condor/gahp/unicore/*.java
javac  -verbose -classpath ajo.jar:classad.jar:./ condor/gahp/unicore/*.java
