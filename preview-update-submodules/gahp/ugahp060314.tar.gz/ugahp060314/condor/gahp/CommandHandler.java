package condor.gahp;

/**
 * An interface to handle GAHP commands.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:55 $ 
 * 
 */
public interface CommandHandler {

    /**
     * Handle GAHP commands from standard input.
     * @param cmd command line from standard input.
     * @return CommandHandlerResponse the result of GAHP commands.
     */
    public CommandHandlerResponse handleCommand(String[] cmd);

    /**
     * Set GAHP.
     * @param gahp GAHP.
     */
    public void setGahp(GahpInterface gahp);
}
