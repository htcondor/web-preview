package condor.gahp;

import java.util.Vector;

/**
 * This class provides utility to manage command result queue.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version 1.0 (2005/03/22)
 * 
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:55 $ 
 */
public class CommandResultQueue {

	private Vector resultQueue = new Vector();

	/**
	 * Construct a default CommandResultQueue.
	 */
	public CommandResultQueue() {
	}

	/**
	 * return size of result queue
	 * 
	 * @return int size of queue.
	 */
	public int size() {
		return this.resultQueue.size();
	}

	/**
	 * add result into result queue.
	 * 
	 * @param reqId
	 *            request id
	 * @param result
	 *            result string
	 * @return boolean always return true.
	 */
	public synchronized boolean addResult(int reqId, String[] result) {
		resultQueue.add(new CommandResult(reqId, result));
		return true;
	}

	/**
	 * flush result list.
	 * 
	 * @return CommandResult[] command result.
	 */
	public synchronized CommandResult[] flushResultList() {
		CommandResult[] result = new CommandResult[resultQueue.size()];
		resultQueue.copyInto(result);
		resultQueue.clear();
		return result;
	}

	/**
	 * returns result string in this result queue.
	 * 
	 * @return String result string.
	 */
	public String toString() {
		return resultQueue.toString();
	}

	/**
	 * This class provides a command result.
	 * 
	 * @author Yasuyoshi ITOU (Fujitsu Limited)
	 * @version 0.5.1 (06/02/2005)
	 */
	class CommandResult {
		public final int REQ_ID;

		public final String[] RESULT;

		/**
		 * @param reqId
		 *            request id.
		 * @param result
		 *            result.
		 */
		public CommandResult(int reqId, String[] result) {
			this.REQ_ID = reqId;
			this.RESULT = result;
		}

		/**
		 * Returns request id and result string.
		 * 
		 * @return String result string.
		 */
		public String toString() {
			return REQ_ID + " " + RESULT;
		}
	}
}