package condor.gahp;

/**
 * This class provides utility to generate unique id.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:55 $ 
 * 
 */
public class UniqueID  {
    
    private static long id_seed=0;
    private static long time_seed=System.currentTimeMillis();
    private final Object ID;
    
    /**
     * Construct a default UniqueID.
     */
    public UniqueID() {
        this.ID=generate();
    }
    
    /**
     * @return Object
     */
    private static synchronized Object generate() {
    	String obj = "" + time_seed +"."+(++id_seed);
		return obj;
    }

    /**
     * @param obj
     * @return boolean
     */
    public boolean equals (Object o) {
        if (!(o instanceof UniqueID)) {
            return false;
        }
        boolean flag = this.ID.equals (((UniqueID)o).ID);
        return flag;    	
    }

    /**
     * return hash code
     * @return int
     */
    public int hashCode() {
        return ID.hashCode();
    }
    
    /**
     * This method isn't used!!
     * @return String
     */
    public String toString () {
        return ID.toString();
    }   
}
