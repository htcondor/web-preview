package condor.gahp.unicore;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringWriter;

import org.unicore.outcome.ActionGroup_Outcome;
import org.unicore.outcome.ConditionalAction_Outcome;
import org.unicore.outcome.Outcome;
import org.unicore.sets.OutcomeEnumeration;

import com.fujitsu.arcon.servlet.OutcomeTh;

import condor.classad.ClassAdParser;
import condor.classad.ClassAdWriter;
import condor.classad.Constant;
import condor.classad.RecordExpr;

/**
 * This class provides a Manage UNICORE and Condor job related information.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
public class JobStatusInfo {

	private int jobStatus;

	private int exitCode;

	private int exitSignal;

	private float byteSend;

	private float byteRecvd;

	private boolean exitBySignal;

	private float remoteWallClockTime;

	private String unicoreJobStatus;

	private String unicoreJobId;

	private String errMessage;

	/**
     * Construct a default JobStatusInfo.
	 */
	public JobStatusInfo() {
		jobStatus = 0;
		byteSend = 0;
		byteRecvd = 0;
		remoteWallClockTime = 0;
		exitCode = 0;
		exitSignal = 0;
		exitBySignal = false;
		unicoreJobStatus = null;
		unicoreJobId = null;
		errMessage = null;
	}

	/**
	 * @param outcome
	 */
	public void setUnicoreJobStatus(OutcomeTh outcome) {
		try {
			unicoreJobStatus = outcome.getOutcome().getStatus().toString();
		} catch (NullPointerException e) {
			Log.log("** Can't get status because outcome is null!");
		}
	}

	/**
	 * 
	 */
	public void setJobStatus() {

		if (unicoreJobStatus == null) {
			return;
		} else if (unicoreJobStatus.equals("CONSIGNED")
				|| unicoreJobStatus.equals("PENDING")
				|| unicoreJobStatus.equals("READY")
				|| unicoreJobStatus.equals("QUEUED")
				|| unicoreJobStatus.equals("SUSPENDED")) {
			setJobStatus(1); //for condor job status
		} else if (unicoreJobStatus.equals("RUNNING")
				|| unicoreJobStatus.equals("EXECUTING")) {
			setJobStatus(2); //for condor job status
		} else if (unicoreJobStatus.equals("NOT_SUCCESSFUL")
				|| unicoreJobStatus.equals("SUCCESSFUL")
				|| unicoreJobStatus.equals("FAILED_IN_INCARNATION")
				|| unicoreJobStatus.equals("FAILED_IN_EXECUTION")
				|| unicoreJobStatus.equals("FAILED_IN_CONSIGN")
				|| unicoreJobStatus.equals("NEVER_TAKEN")
				|| unicoreJobStatus.equals("KILLED")) {
			setJobStatus(4); //for condor job status
		} else if (unicoreJobStatus.equals("HELD")) {
			setJobStatus(5); //for condor job status
		} else {
			setJobStatus(1); //for condor job status
		}
	}

	/**
	 * @return String
	 */
	public String createClassad() {

		RecordExpr rcdexpr = new RecordExpr();

		if (getErrMessage() != null) {
			rcdexpr.insertAttribute("ErrMessage", Constant
					.getInstance(getErrMessage()));
		}

		if (getUnicoreJobId() != null) {
			rcdexpr.insertAttribute("UnicoreJobId", Constant
					.getInstance(getUnicoreJobId()));
		}

		if (getUnicoreJobStatus() != null) {
			rcdexpr.insertAttribute("UnicoreJobStatus", Constant
					.getInstance(getUnicoreJobStatus()));
		}

		if (getJobStatus() == 1 || getJobStatus() == 2) {
			rcdexpr.insertAttribute("JobStatus", Constant
					.getInstance(getJobStatus()));
		} else if (getJobStatus() == 4) {
			rcdexpr.insertAttribute("JobStatus", Constant
					.getInstance(getJobStatus()));
			rcdexpr.insertAttribute("ByteSend", Constant
					.getInstance(getByteSend()));
			rcdexpr.insertAttribute("ByteRecvd", Constant
					.getInstance(getByteRecvd()));
			setRemoteWallClockTime(1);
			Log.log(new Float(getRemoteWallClockTime()).toString());
			rcdexpr.insertAttribute("RemoteWallClockTime", Constant
					.getInstance(getRemoteWallClockTime()));
			rcdexpr.insertAttribute("ExitCode", Constant
					.getInstance(getExitCode()));
			rcdexpr.insertAttribute("ExitSignal", Constant
					.getInstance(getExitSignal()));
			rcdexpr.insertAttribute("ExitBySignal", Constant
					.getInstance(getExitBySignal()));
		}

		String classad = rcdexpr.toString();
		return classad;
	}

	/**
	 * @return String
	 * @param classad
	 * @exception IOException
	 */
	public String convertClassad(String classad) throws IOException {

		StringWriter swriter = new StringWriter();
		ClassAdWriter writer = new ClassAdWriter(swriter, ClassAdWriter.XML,
				true);
		ClassAdParser parser = new ClassAdParser(classad, ClassAdParser.TEXT);
		writer.println(parser.parse());
		writer.close();

		String xml_classad00 = swriter.toString();

		//For Windows
		//String xml_classad01 = xml_classad00.replaceAll("\n\n", "");

		//For UNIX
		String xml_classad01 = xml_classad00.replaceAll("\n", "");

		String xml_classad02 = xml_classad01.replaceAll(
				"<\\?xml version=\"1.0\"\\?><!DOCTYPE classads><classads>", "");
		String xml_classad = xml_classad02.replaceAll("</classads>", "");

		return xml_classad;
	} //convertClassad

	/**
	 * @return float
	 */
	public float getByteRecvd() {
		return this.byteRecvd;
	}

	/**
	 * @return float
	 */
	public float getByteSend() {
		return this.byteSend;
	}

	/**
	 * @return String
	 */
	public String getErrMessage() {
		return this.errMessage;
	}

	/**
	 * @return String
	 */
	public boolean getExitBySignal() {
		return this.exitBySignal;
	}

	/**
	 * @return int Exit Code
	 */
	public int getExitCode() {
		return this.exitCode;
	}

	/**
	 * @return int Exit Signal
	 */
	public int getExitSignal() {
		return this.exitSignal;
	}

	/**
	 * @return int
	 */
	public int getJobStatus() {
		return this.jobStatus;
	}

	/**
	 * @return long
	 */
	public float getRemoteWallClockTime() {
		return this.remoteWallClockTime;
	}

	/**
	 * @return String
	 */
	public String getUnicoreJobId() {
		return this.unicoreJobId;
	}

	/**
	 * @return String
	 */
	public String getUnicoreJobStatus() {
		return this.unicoreJobStatus;
	}


	/**
	 * @param size
	 */
	public void setByteRecvd(float size) {
		this.byteRecvd = size;
	}

	/**
	 * @param size
	 */
	public void setByteSend(float size) {
		this.byteSend = size;
	}

	/**
	 * @param errmsg
	 *            error message
	 */
	public void setErrMessage(String errmsg) {
		this.errMessage = errmsg;
	}

	/**
	 * @param exitBySignal
	 */
	public void setExitBySignal(boolean exitBySignal) {
		this.exitBySignal = exitBySignal;
	}

	/**
	 * @param exitCode
	 */
	public void setExitCode(int exitCode) {
		this.exitCode = exitCode;
	}

	/**
	 * @param exitSignal
	 */
	public void setExitSignal(int exitSignal) {
		this.exitSignal = exitSignal;
	}

	/**
	 * @param jobStatus
	 */
	public void setJobStatus(int jobStatus) {
		this.jobStatus = jobStatus;
	}

	/**
	 * @param time
	 */
	public void setRemoteWallClockTime(float time) {
		this.remoteWallClockTime = time;
	}

	/**
	 * @param unicoreJobId
	 */
	public void setUnicoreJobId(String unicoreJobId) {
		this.unicoreJobId = unicoreJobId;
	}

	/**
	 * @param string
	 */
	public void setUnicoreJobStatus(String string) {
		this.unicoreJobStatus = string;
	}

	/**
	 * get log from Outcome
	 * 
	 * @param outcome
	 *            Outcome
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public void createUnicoreLog(Outcome outcome) {
		
		String st = outcome.getStatus().toString();

		Log.log("AbstractAction <" + outcome.getId().getName() + "> Log:\n"
				+ outcome.getLog());

		if (outcome instanceof ActionGroup_Outcome) {
			OutcomeEnumeration oe = ((ActionGroup_Outcome) outcome)
					.getOutcomes();
			while (oe.hasMoreElements()) {
				createUnicoreLog(oe.nextElement());
			}
		} else if (outcome instanceof ConditionalAction_Outcome) {
			createUnicoreLog(((ConditionalAction_Outcome) outcome)
					.getTrueBranchOutcome());
			createUnicoreLog(((ConditionalAction_Outcome) outcome)
					.getFalseBranchOutcome());
		}
	}

}