package condor.gahp.unicore;

import condor.gahp.CommandHandler;
import condor.gahp.CommandHandlerResponse;
import condor.gahp.GahpInterface;

/**
 * This class provides a Handle job status.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
public class JobCallbackHandler implements CommandHandler {

	private GahpInterface gahp;

	/**
     * Construct a default JobStatusHandler.
	 */
	public JobCallbackHandler() {
	}
	public static final String CALLBACK_REQ_ID = "CALLBACK_REQ_ID";
	
	/**
	 * handle command
	 * 
	 * @see condor.gahp.CommandHandler
	 * @param cmd
	 *            command line from stdin
	 * @return CommandHandlerResponse result
	 */
	public CommandHandlerResponse handleCommand(String[] cmd) {

		try {
			if (cmd.length != 2) {
				Log.log("Args: <reqest-id> ");
				return CommandHandlerResponse.SYNTAX_ERROR;
			}
			int reqId = new Integer(cmd[1]).intValue();
			//check reqId data format
			if (reqId < 1) {
				Log.log("Args: <reqest-id> must be number > 0");
				return CommandHandlerResponse.SYNTAX_ERROR;
			}
			gahp.storeObject(CALLBACK_REQ_ID, new Integer(reqId));

			return new CommandHandlerResponse(CommandHandlerResponse.SUCCESS);
				
		} catch (NumberFormatException e) {
			Log.log("Args: <reqest-id> must be number (0 < number < "
					+ Integer.MAX_VALUE + ")");
			Log.log(e);
			Log.printStackTrace(e);
			return CommandHandlerResponse.SYNTAX_ERROR;
		} catch (Exception e) {
			Log.log(e);
			Log.printStackTrace(e);
			return CommandHandlerResponse.SYNTAX_ERROR;
		}

	}

	/**
	 * set gahp
	 * 
	 * @see condor.gahp.CommandHandler
	 * @param g
	 *            gahp
	 */
	public void setGahp(GahpInterface g) {
		gahp = g;
	}
}