package condor.gahp.unicore;

import org.unicore.ajo.AbstractJob;
import condor.gahp.GahpInterface;

/**
 * This class provides a Job create thread.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.5 $ $Date: 2005/07/19 02:13:16 $
 * 
 */
public class JobCreateRunnable implements Runnable {

	/**
	 * gahp
	 */
	private GahpInterface gahp;

	/**
	 * job id
	 */
	private String jobId;

	/**
	 * job Classad
	 */
	private String jobClassad;

	/**
	 * request id
	 */
	public final int REQ_ID;

	/**
	 * Construct a default JobCreateRunnable.
	 * 
	 * @param reqId
	 *            request id
	 * @param jobClassad
	 *            job classad (xml expression)
	 * @param gahp
	 *            gahp interface
	 */
	public JobCreateRunnable(int reqId, String jobClassad, GahpInterface gahp) {

		this.REQ_ID = reqId;
		this.jobClassad = jobClassad;
		this.gahp = gahp;
	}

	/**
	 * Thread activity
	 */
	public void run() {

		UnicoreGahp.setConnectionKeepOpen();
		AbstractJob ajo;
		String handle;

		JobInfo info = new JobInfo();

		try {
			// add to handle job status info
			JobStatusInfo stinfo = new JobStatusInfo();

			info.parse(jobClassad);

			Log.jobId.set(info.getOut());

			ajo = null;

			do {
				try {
					ajo = info.createJob(info);
				} catch (Exception e) {
					Log.printStackTrace(e);
					Log.log("< Retry: " + info.create_retry_cnt + " times >");
					Thread.sleep((long) (10000 * Math.random()));
				}
			} while (info.create_retry_cnt++ < 10 && ajo == null);

			if (ajo == null) {
				gahp.addResult(REQ_ID, new String[] { "F", "null",
						"failed to create AJO " });
				return;
			}

			int ajoid = ajo.getAJOId().getValue();

			// now id number only
			jobId = Integer.toString(ajoid);

			gahp.storeObject(jobId + "ajo", ajo);
			gahp.storeObject(jobId + "jobinfo", info);
			gahp.storeObject(jobId + "jobstatus", stinfo);

			Log.log("** SUCCESS Creating Job");

			JobHandle jobHandle = new JobHandle(jobId, info.getCondorId());

			info.setJobHandle(jobHandle);

			gahp.addResult(REQ_ID, new String[] { "S", jobHandle.toString(),
					"null" });

		} // try
		catch (Exception e) {
			Log.log("** ERROR Creating Job " + e);
			Log.printStackTrace(e);
			String errMsg = (e.getMessage() == null) ? "unknown" : e
					.getMessage();
			String jobhandle = (info.getJobHandle() == null) ? "unknown" : info
					.getJobHandle().toString();
			String[] result = { "F", jobhandle, errMsg };
			gahp.addResult(REQ_ID, result);
			return;
		}
	}
}
