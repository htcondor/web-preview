package condor.gahp.unicore;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class provides a Job handle.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
class JobHandle {

	static final String PATTERN = "(.*)::(.*)";

	String jobId;

	String jobAlias;

	/**
     * Construct a default JobHandle.
	 * 
	 * @param jobId
	 * @param jobAlias
	 */
	JobHandle(String jobId, String jobAlias) {
		this.jobId = jobId;
		this.jobAlias = jobAlias;
	}

	/**
     * Construct a default JobHandle.
	 * 
	 * @param handleStr
	 * @exception Exception
	 */
	JobHandle(String handleStr) throws Exception {
		Pattern pattern = Pattern.compile(PATTERN);
		Matcher matcher = pattern.matcher(handleStr);
		if (!matcher.matches()) {
			throw new Exception("failed to parse : " + handleStr);
		}
		jobId = matcher.group(1);
		jobAlias = matcher.group(2);
	}

	/**
	 * @return String
	 */
	public String toString() {
		return jobId + "::" + jobAlias;
	}

	/**
	 * exception
	 * 
	 * @author Yasuyoshi ITOU (Fujitsu Limited)
	 * @version 0.3.5
	 */
	static class Exception extends java.lang.Exception {

		/**
		 * constructor
		 * 
		 * @param str
		 */
		Exception(String str) {
			super(str);
		}
	}
}

