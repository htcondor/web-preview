package condor.gahp.unicore;

import org.unicore.ajo.AbstractJob;

import condor.gahp.GahpInterface;

/**
 * This class provides a Setup executing job contorl command (start, status, hold ,release ,destroy)
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
abstract class JobRunnable implements Runnable {

    /**
     * requestId
     */
    protected int reqId;

    /**
     * GahpInterface 
     */
    protected GahpInterface gahp;

    /**
     * AJO
     */
    protected AbstractJob ajo;

    /**
     * JobHandle String
     */
    protected String jobHandleString;

    /**
     * JobHandle Object
     */
    protected JobHandle jobHandle;

    /**
     * Construct a default JobRunnable.
     * @param reqId
     * @param jobHandleString
     * @param gahp
     */
    JobRunnable(int reqId, String jobHandleString, GahpInterface gahp) {
        this.reqId = reqId;
        this.jobHandleString = jobHandleString;
        this.gahp = gahp;
    }

    /** 
     * setup variables
     * @return boolean
     */
    boolean setup() {
        
        try {
            jobHandle = new JobHandle(jobHandleString);
        } catch (JobHandle.Exception e) {
            Log.log(e.getMessage());
            gahp.addResult(reqId, new String[] { "F", e.getMessage()});
            return false;
        }
        ajo = (AbstractJob) gahp.getObject(jobHandle.jobId + "ajo");
        Log.set(jobHandle.jobAlias);
        return true;
    }
}
