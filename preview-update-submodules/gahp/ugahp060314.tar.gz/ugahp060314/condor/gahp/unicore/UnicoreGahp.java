package condor.gahp.unicore;

import java.util.Timer;
import java.util.TimerTask;

import condor.gahp.GahpInterface;
import com.fujitsu.arcon.servlet.Connection;

/**
 * This class provides utility for all.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
public class UnicoreGahp {

	private static boolean setKeepOpen = false;

	public static final String VERSION = "NAREGI Condor-U";

	/**
	 * @return String
	 */
	public static String getVersion() {
		return VERSION;
	}

	/**
	 * scheduling task periodically check job status
	 * 
	 * @param gahp
	 *            gahp interface
	 * @param task
	 * @param jobId
	 * @param initial
	 * @param periodic
	 */
	static void registerTimerTask(GahpInterface gahp, TimerTask task,
			String jobId, int initial, int periodic) {
		// get the timer;
		Timer timer = (Timer) gahp.getObject("theTimer");
		if (timer == null) {
			// create a daemon timer
			timer = new Timer(true);
			gahp.storeObject("theTimer", timer);
		}
		// schedule the task
		timer.schedule(task, initial * 1000, periodic * 1000);
		// register the task to the Gahp
		gahp.storeObject(jobId + "monitorTask", task);
	}

	/**
	 * keep connection
	 */
	static void setConnectionKeepOpen() {
		if (!setKeepOpen) {
			Connection.setKeepOpen(false);
			setKeepOpen = true;
		}
	}
}