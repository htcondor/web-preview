package condor.gahp.unicore;

import java.io.File;

import org.unicore.ajo.Control;
import org.unicore.ajo.ControlAction;
import com.fujitsu.arcon.servlet.Identity;
import com.fujitsu.arcon.servlet.OutcomeTh;
import com.fujitsu.arcon.servlet.JobManager;
import com.fujitsu.arcon.servlet.VsiteTh;
import com.fujitsu.arcon.servlet.Reference;

import condor.gahp.GahpInterface;

/**
 * This class provides a Job hold thread.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
public class JobHoldRunnable extends JobRunnable {

	private OutcomeTh outcome;

	/**
     * Construct a default JobHoldRunnable.
	 * 
	 * @param reqId
	 *            equest ID
	 * @param jobHandleString
	 *            job handle
	 * @param gahp
	 *            gahp
	 */
	public JobHoldRunnable(int reqId, String jobHandleString, GahpInterface gahp) {
		super(reqId, jobHandleString, gahp);
	}

	/**
	 * Thread
	 */
	public void run() {
		if (!setup()) {
			return;
		}
		try {
			OutcomeTh out = (OutcomeTh) gahp.getObject(jobHandle.jobId
					+ "outcome");

			ControlAction hold = new ControlAction("HoldJob", ajo.getAJOId(),
					Control.HOLD);

			JobInfo info = (JobInfo) gahp
					.getObject(jobHandle.jobId + "jobinfo");

			java.security.Security
					.addProvider(new com.sun.net.ssl.internal.ssl.Provider());

			Identity identity = new Identity(new File(info.getKeystoreFile()),
					info.getPasswd().toCharArray(), info.getUserAlias());

			VsiteTh vsiteTh = new VsiteTh(new Reference.SSL(ajo.getVsite()
					.getAddress(), identity), ajo.getVsite());

			outcome = JobManager.executeAction(hold, vsiteTh);

			Log.log("** SUCCESS Holding Job");

		} catch (Exception e) {
			Log.log("** ERROR Holding Job" + e);
			String errMsg = (e.getMessage() == null) ? "unknown" : e
					.getMessage();
			String[] result = { "F", errMsg };
			gahp.addResult(reqId, result);
			return;
		}
		String[] result = { "S", "null" };
		gahp.addResult(reqId, result);
	}
}