package condor.gahp.unicore;

import java.io.File;
import java.security.Security;
import java.util.regex.Pattern;

import org.unicore.AJOIdentifier;
import org.unicore.ajo.AbstractJob;
import org.unicore.ajo.Control;
import org.unicore.ajo.ControlAction;
import com.fujitsu.arcon.servlet.Identity;
import com.fujitsu.arcon.servlet.OutcomeTh;
import com.fujitsu.arcon.servlet.JobManager;
import com.fujitsu.arcon.servlet.VsiteTh;
import com.fujitsu.arcon.servlet.Reference;
import com.sun.net.ssl.internal.ssl.Provider;

import condor.gahp.GahpInterface;

/**
 * This class provides a Job destroy thread.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
public class JobDestroyRunnable extends JobRunnable {

	private OutcomeTh outcome;
	/**
     * Construct a default JobDestroyRunnable.
	 * 
	 * @param reqId
	 *            request id
	 * @param jobHandleString
	 *            job handle
	 * @param gahp
	 *            gahp
	 */
	public JobDestroyRunnable(int reqId, String jobHandleString,
			GahpInterface gahp) {
		super(reqId, jobHandleString, gahp);
	}

	/**
	 * Thread
	 */
	public void run() {
		if (!setup()) {
			return;
		}
		Exception e0 = new Exception("Unknown");
		try {

			AJOIdentifier ajoId = new AJOIdentifier(jobHandle.jobId, Integer
					.parseInt(jobHandle.jobId));
			ControlAction hold = new ControlAction("HoldJob", ajoId,
					Control.HOLD);

			ControlAction kill = new ControlAction("AbortJob", ajoId,
					Control.ABORT);
			Security.addProvider(new Provider());
			JobInfo info = (JobInfo) gahp
					.getObject(jobHandle.jobId + "jobinfo");
			Identity identity = new Identity(new File(info.getKeystoreFile()),
					info.getPasswd().toCharArray(), info.getUserAlias());
			VsiteTh vsiteTh = new VsiteTh(new Reference.SSL(info
					.getUnicoreUSite(), identity), info.getUnicoreVSite());
			if (vsiteTh == null){
				Log.log("vsiteTh is null");
			}
			{
				int counter = 5;
				while (counter-- > 0) {
					try {
						JobManager.executeAction(hold, vsiteTh);
						break;
					} catch (Exception e) {
						Log.log("holding error:" + e);
						Log.printStackTrace(e);
						if (counter == 0) {
							throw e;
						} else {
						}
						try {
							Thread.sleep((long) (10000 * Math.random()));
						} catch (InterruptedException ie) {
						}
					}
				}
			};

			{
				int counter = 5;
				while (counter-- > 0) {
					try {
						JobManager.executeAction(kill, vsiteTh);
						break;
					} catch (Exception e) {
						Log.log("killing error:" + e);
						if (counter == 0) {
							throw e;
						}
						try {
							Thread.sleep((long) (10000 * Math.random()));
						} catch (InterruptedException ie) {
						}
					}
				}
			};

			{
				int counter = 5;
				while (counter-- > 0) {
					try {
						//JobManager.sendROA(ajo.getAJOId(), vsiteTh);
						JobManager.sendROA(ajoId, vsiteTh);
						break;
					} catch (Exception e) {
						Log.log("sending ROA error:" + e);
						if (counter == 0) {
							throw e;
						}
						try {
							Thread.sleep((long) (10000 * Math.random()));
						} catch (InterruptedException ie) {
						}
					}
				}
			};
			
			gahp.removeObject(jobHandle.jobId + "ajo");
			gahp.removeObject(jobHandle.jobId + "outcome");
			gahp.removeObject(jobHandle.jobId + "jobinfo");
			gahp.removeObject(jobHandle.jobId + "jobstatus");
			gahp.removeObject(jobHandle.jobId + "monitorTask");

			Log.log("** SUCCESS Destroying Job");
			String[] result = { "S", "null" };
			gahp.addResult(reqId, result);
			return;
		} catch (JobManager.Exception e1){
			String pattern = "(.*)The target AJO(.*)is not on this NJS(.*)"; 
			Pattern p = Pattern.compile(pattern);
			if (p.matcher(e1.getMessage()).matches()){
				Log.log("** SUCCESS Destroying Job");
				String[] result = { "S", "The specified AJO is not on the NJS" };
				gahp.addResult(reqId, result);
				return;
			} else {
				e0 = e1;
			}
		} catch (Exception e1) {
			e0 = e1;
		}
		
		Log.log("** ERROR Destroying Job " + e0);
		Log.printStackTrace(e0);
		String errMsg = (e0.getMessage() == null) ? "unknown" : e0
				.getMessage();
		String[] result = { "F", errMsg };
		gahp.addResult(reqId, result);
		return;
	}
}