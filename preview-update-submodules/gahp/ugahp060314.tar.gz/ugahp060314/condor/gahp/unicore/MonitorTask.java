package condor.gahp.unicore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.TimerTask;

import org.unicore.AJOIdentifier;
import org.unicore.outcome.ActionGroup_Outcome;
import org.unicore.outcome.ExecuteScriptTask_Outcome;
import org.unicore.outcome.Outcome;
import org.unicore.sets.OutcomeEnumeration;

import com.fujitsu.arcon.servlet.Connection;
import com.fujitsu.arcon.servlet.TsJobManager;
import com.fujitsu.arcon.servlet.VsiteTh;
import com.fujitsu.arcon.servlet.OutcomeTh;

import condor.gahp.GahpInterface;

/**
 * This class provides a function of 
 * Will be kicked periodically by the Timer
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
class MonitorTask extends TimerTask {

	private GahpInterface gahp;

	JobHandle jobHandle;

	JobInfo info;

	JobStatusInfo stinfo;

	AJOIdentifier id;

	VsiteTh vsite_th;

	int errorTimes = 0;

	int errorMax;

	File tmpDir;

	int jobStatus = -1;
	
	/**
     * Construct a default MonitorTask.
	 * 
	 * @param gahp
	 * @param vsite_th
	 * @param errorMax
	 */
	MonitorTask(GahpInterface gahp, JobInfo info, JobStatusInfo stinfo,
			VsiteTh vsite_th, int errorMax) {
		this.gahp = gahp;
		this.info = info;
		this.stinfo = stinfo;

		this.vsite_th = vsite_th;
		this.errorMax = errorMax;
		this.jobHandle = info.getJobHandle();
		int jobIdInt = Integer.parseInt(jobHandle.jobId);
		this.id = new AJOIdentifier("CondorJob", jobIdInt);
	}

	/**
	 * will be kicked periodically by the Timer
	 */
	public void run() {
		Exception e;
		Log.set(info.getJobHandle().jobAlias);
		Log.log("try to getOutcome");
		try {
			TsJobManager jobmgr = new TsJobManager();
			
			if (info.getTrasferOutputRemaps() != null){
				tmpDir = info.getTransferOutputRemapsTmpDir();
				jobmgr.setOutcomeRootDirectory(tmpDir);
			} else {
				jobmgr.setOutcomeRootDirectory(new File(info.getIwd()));
			}

			if ((info.getErr() != null) && (info.getTransferErr() == true)) {
				jobmgr.setErrFileName(info.getErr());
			}

			OutcomeTh outcome = jobmgr.getOutcome(id, vsite_th);

			int size = jobmgr.getFetchedDataSize();
			info.setRecvDataSize(size);

			// setup stinfo 
			stinfo.setExitCode(jobmgr.getExitCode());
			stinfo.setExitSignal(jobmgr.getExitSignal());
			stinfo.createUnicoreLog(outcome.getOutcome());

			stinfo.setUnicoreJobId(info.getJobHandle().toString());
			stinfo.setUnicoreJobStatus(outcome);
			stinfo.setJobStatus();
			stinfo.setByteSend(info.getSendDataSize());
			stinfo.setByteRecvd(info.getRecvDataSize());        	

			//impl to get Exit code and exit signal
			setJobExecTime(outcome.getOutcome());

			gahp.storeObject(info.getJobHandle().jobId + "outcome", outcome);
			gahp.storeObject(info.getJobHandle().jobId + "jobinfo", info);
			gahp.storeObject(info.getJobHandle().jobId + "jobstatus", stinfo);

			Log.log("got it");

			if (jobStatus != stinfo.getJobStatus()){
				Integer callbackReqId = (Integer)gahp.getObject(JobCallbackHandler.CALLBACK_REQ_ID);
				if (callbackReqId != null){
			        String text_classad = stinfo.createClassad();
			        try {
			            String xml_classad = stinfo.convertClassad(text_classad);
				        String[] result = {xml_classad};
						gahp.addResult(callbackReqId.intValue(), result);
			        } catch (IOException e1) {
			            Log.log("** Failed to callback Job status, ignore");
			        }
				}
				jobStatus = stinfo.getJobStatus();
			}

			
			if (stinfo.getJobStatus() == 4) {// the job is done, successive getoutcome
				                            // will end up exception
				Log.log("MonitorTask stop..");
				gahp.removeObject(info.getJobHandle().jobId + "monitorTask");
				this.cancel();
				moveMappedFiles();
				cleanupTmpDir();
			}

			Log.set("----");
			return;
		} catch (TsJobManager.Exception e0) {
			e = e0;
		} catch (Connection.Exception e0) {
			e = e0;
		}
		Log.log("failed in getOutcome");

		if (++errorTimes > errorMax) {
			Log.log(" -- too much error, give up (" + errorTimes + " > "
					+ errorMax + " )");
			Log.log(" the last exception follows. ");
			Log.printStackTrace(e);
			gahp.removeObject(info.getJobHandle().jobId + "monitorTask");
			this.cancel(); // will never be scheduled again
			moveMappedFiles();
			cleanupTmpDir();
		} else {
			Log.log(" -- will retry: " + (errorMax - errorTimes + 1) + " more ");
		}
		Log.set("----");
	}


	private void moveMappedFiles() {
		Log.log("moveMappedFiles");
		if (tmpDir == null)
			return;
		String [] files = tmpDir.list();
		if (files == null)
			return;
		for (String tmpFileName: files) {
			Log.log("moveMappedFiles: examin " + tmpFileName);
			String target = info.getTrasferOutputRemaps().get(tmpFileName);
			File targetFile = null;
			if (target != null){
				if (target.charAt(0) == '/') {   
					// absolute path
					targetFile = new File(target);
				} else {
					// relative path
					targetFile = new File(info.getIwd(), target);
				}
			} else {
				targetFile = new File(info.getIwd(), tmpFileName);
			}
			targetFile.delete();  // delete the file before rename;
			File tmpFile = new File(tmpDir, tmpFileName);
			Log.log("moveMappedFiles: moving from " + tmpFile.getAbsolutePath());
			Log.log("moveMappedFiles: moving to   " + targetFile.getAbsolutePath());
			boolean result =tmpFile.renameTo(targetFile);
			Log.log("moveMappedFiles:           " + result);
			if (!result){
				// failed to move the file with 'renameTo', may be due to the
				// java implementation issue; the JDK refuse to rename if the
				// files are on different file system.
				// so, try to do it by itself. 

				try {
					byte [] buffer = new byte[10000];
					FileInputStream fis  = new FileInputStream(tmpFile);
					FileOutputStream fos = new FileOutputStream(targetFile);
					while (true){
						int readLength = fis.read(buffer);
						if (readLength < 0)
							break;
						fos.write(buffer, 0, readLength);
					}
					fis.close();
					fos.close();
					tmpFile.delete();
				} catch (IOException e){
					Log.log("faild to move"); 
					Log.printStackTrace(e);
				}
			}
		}

	}
	
	
	private void cleanupTmpDir(){
		if (tmpDir != null)
			tmpDir.delete();
	}
	
	/**
	 * @param outcome
	 * @return int
	 */
	public void setJobExecTime(Outcome outcome) {

		if (outcome instanceof ActionGroup_Outcome) {
			String status = outcome.getStatus().toString();
			if (status.equals("SUCCESSFUL") || status.equals("NOT_SUCCESSFUL")) {
				OutcomeEnumeration oe = ((ActionGroup_Outcome) outcome)
						.getOutcomes();
				while (oe.hasMoreElements()) {
					Outcome obj = oe.nextElement();
					if (obj instanceof ExecuteScriptTask_Outcome) {
						Date time = obj.getStatusHistory().getLastTime();
						Calendar timecal = Calendar.getInstance();
						timecal.setTime(time);

						String log = obj.getLog().toString();
						int first = log
								.lastIndexOf("Incarnation started on BSS with identifier");
						String templog = log
								.substring(first - 18, log.length());

						Integer hour = new Integer(templog.substring(0, 2));
						Integer min = new Integer(templog.substring(3, 5));
						Integer sec = new Integer(templog.substring(6, 8));
						Integer day = new Integer(templog.substring(9, 11));
						Integer mon = new Integer(templog.substring(12, 14));

						//get present year
						Calendar now = Calendar.getInstance();
						now.setTimeInMillis(System.currentTimeMillis());
						int year1 = now.get(Calendar.YEAR);
						Calendar start1 = Calendar.getInstance();
						start1
								.set(year1, mon.intValue() - 1, day.intValue(),
										hour.intValue(), min.intValue(), sec
												.intValue());
						float exec_time = (timecal.getTimeInMillis() - start1
								.getTimeInMillis()) / 1000;

						//set job execution time
						stinfo.setRemoteWallClockTime(exec_time);
					} else {
						setJobExecTime(obj);
					}
				}
			}
		}
	}
}