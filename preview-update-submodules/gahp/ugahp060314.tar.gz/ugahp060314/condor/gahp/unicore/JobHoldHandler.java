package condor.gahp.unicore;

import condor.gahp.CommandHandler;
import condor.gahp.CommandHandlerResponse;
import condor.gahp.GahpInterface;

/**
 * This class provides a Handle job hold.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
public class JobHoldHandler implements CommandHandler {

	private GahpInterface gahp;

	/**
     * Construct a default JobHoldHandler.
	 */
	public JobHoldHandler() {
	}

	/**
	 * set gahp
	 * 
	 * @see condor.gahp.CommandHandler
	 * @param g
	 */
	public void setGahp(GahpInterface g) {
		gahp = g;
	}

	/**
	 * handle command
	 * 
	 * @see condor.gahp.CommandHandler
	 * @param cmd
	 *            command line from stdin
	 * @return CommandHandlerResponse result
	 */
	public CommandHandlerResponse handleCommand(String[] cmd) {

		try {
			if (cmd.length != 3) {
				Log.log("Args: <reqest-id> <job-handle>");
				return CommandHandlerResponse.SYNTAX_ERROR;
			}

			int reqId = new Integer(cmd[1]).intValue();
			//check reqId data format
			if (reqId < 1) {
				Log.log("Args: <reqest-id> must be number > 0");
				return CommandHandlerResponse.SYNTAX_ERROR;
			}

			String job_handle = cmd[2];

			JobHoldRunnable toRun = new JobHoldRunnable(reqId, job_handle, gahp);

			return new CommandHandlerResponse(CommandHandlerResponse.SUCCESS,
					toRun);
		} catch (NumberFormatException e) {
			Log.log("Args: <reqest-id> must be number (0 < number < "
					+ Integer.MAX_VALUE + ")");
			Log.log(e);
			Log.printStackTrace(e);
			return CommandHandlerResponse.SYNTAX_ERROR;
		} catch (Exception e) {
			Log.log(e);
			Log.printStackTrace(e);
			return CommandHandlerResponse.SYNTAX_ERROR;
		}

	}
}