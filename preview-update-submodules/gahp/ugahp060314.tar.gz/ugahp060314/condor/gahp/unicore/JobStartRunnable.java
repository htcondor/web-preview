package condor.gahp.unicore;

import java.io.File;
import com.fujitsu.arcon.servlet.Connection;
import com.fujitsu.arcon.servlet.Identity;
import com.fujitsu.arcon.servlet.JobManager;
import com.fujitsu.arcon.servlet.OutcomeTh;
import com.fujitsu.arcon.servlet.PortfolioTh;
import com.fujitsu.arcon.servlet.Reference;
import com.fujitsu.arcon.servlet.TsJobManager;
import com.fujitsu.arcon.servlet.VsiteTh;

import condor.gahp.GahpInterface;

/**
 * This class provides a Job start thread.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.4 $ $Date: 2005/07/19 02:13:16 $ 
 * 
 */
public class JobStartRunnable extends JobRunnable {

	private Identity identity;

	private VsiteTh vsite_th;

	private PortfolioTh pfth;

	private OutcomeTh outcome;

	private String status;

	private JobInfo info;

	private JobStatusInfo stinfo;

	/**
     * Construct a default JobStartRunnable.
	 * 
	 * @param reqId
	 * @param jobHandleString
	 * @param gahp
	 */
	public JobStartRunnable(int reqId, String jobHandleString,
			GahpInterface gahp) {
		super(reqId, jobHandleString, gahp);
	}

	/**
	 * @return boolean
	 */
	boolean localSetup() {
		try {
			info = (JobInfo) gahp.getObject(jobHandle.jobId + "jobinfo");
			stinfo = (JobStatusInfo) gahp.getObject(jobHandle.jobId
					+ "jobstatus");

			java.security.Security
					.addProvider(new com.sun.net.ssl.internal.ssl.Provider());

			this.identity = new Identity(new File(info.getKeystoreFile()), info
					.getPasswd().toCharArray(), info.getUserAlias());

			//pfth contains Import files information.
			this.pfth = info.getPfth();

			// store jobinfo object
			gahp.storeObject(jobHandle.jobId + "jobinfo", info);
		} catch (Exception e) {
			Log.printStackTrace(e);
			return false;
		}
		return true;
	}

	/**
	 * Thread
	 */
	public void run() {
		if (!setup()) {
			return;
		}
		if (!localSetup()) {
			return;
		}
		try {
			//start job
			startJob();
		} catch (Exception e) {
			Log.log("** ERROR Starting Job");
			String errMsg = (e.getMessage() == null) ? "unknown" : e
					.getMessage();
			String[] result = { "F", errMsg };
			Log.log("         " + errMsg);
			Log.printStackTrace(e);
			gahp.addResult(reqId, result);
			return;
		}
	}

	/**
	 * @param counter
	 * @param interval
	 * @exception Connection.Exception
	 * @exception TsJobManager.Exception
	 */
	void consignAsyncWithRetry(int counter, int interval)
			throws Connection.Exception, TsJobManager.Exception {
		Connection.Exception ce = null;
		TsJobManager.Exception je = null;

		while (counter-- > 0) {
			try {
				//JobManager.consignAsynchronous(ajo, pfth, vsite_th);
				//2004/12/30 change
				if (this.pfth == null) {
					(new TsJobManager()).consignAsynchronous(ajo, vsite_th, false);
				} else {
					(new TsJobManager()).consignAsynchronous(ajo,
							new PortfolioTh[] { this.pfth }, vsite_th, false);
				}
				return;

			} catch (Connection.Exception e) {
				ce = e;
			} catch (TsJobManager.Exception e) {
				je = e;
			}
			Log.log("failed to consign, retry.. ");
			try {
				Thread.sleep(interval * 1000);
			} catch (InterruptedException e) {
			}
		}
		Log.log("give up");
		if (ce != null) {
			throw ce;
		}
		if (je != null) {
			throw je;
		}
	}

	/**
	 * @exception Connection.Exception
	 * @exception TsJobManager.Exception
	 */
	public void startJob() throws Connection.Exception, TsJobManager.Exception {
		try {
			vsite_th = new VsiteTh(new Reference.SSL(ajo.getVsite()
					.getAddress(), this.identity), ajo.getVsite());

			consignAsyncWithRetry(5, 1);

			gahp.addResult(reqId, new String[] { "S", "null" });
			Log.log("** SUCCESS Starting Job");

			// create a priodic task
			MonitorTask task = new MonitorTask(gahp, info, stinfo, vsite_th, 3);
			UnicoreGahp.registerTimerTask(gahp, task, jobHandle.jobId, 30, 30);

		} catch (Reference.Exception e) {
			Log.printStackTrace(e);
		}
	}
}
