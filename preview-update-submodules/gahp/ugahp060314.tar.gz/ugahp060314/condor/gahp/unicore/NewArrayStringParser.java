package condor.gahp.unicore;

import java.util.LinkedList;
import java.util.List;

public class NewArrayStringParser {
	

    static final int OUT       = 0;
    static final int IN_STRING = 1;
    static final int IN_QUOTE  = 2;
    static final int IN_QUOTE_QUOTE  = 3;


    static String target = "one \"two\" spacey' '''quoted''' 'argument '''a''' ''''a''''";

    //static String target = "'''a'''";
    static boolean isWhite(int i){
        return i == ' ' || i == '\t';
    }

    static boolean isQuote(int i){
        return i == '\'';
    }

    static List<String> divide(String str){
        List <String> list = new LinkedList<String>();

        int state   = OUT;
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < str.length(); i++){
            char ch = (char)str.charAt(i);
            switch (state) {
            case OUT:
                if (isWhite(ch) ){
                    ; // nothing to do
                } else if (isQuote(ch)){
                    state = IN_QUOTE;
                } else {
                    sb.append(ch);
                    state = IN_STRING;
                }
                break;
            case IN_STRING:
                if (isQuote(ch)){
                    state = IN_QUOTE;
                } else if (isWhite(ch)){
                    state = OUT;
                    list.add(new String(sb));
                    sb = new StringBuffer();
                } else {
                    sb.append(ch);
                }
                break;
            case IN_QUOTE:
                if (isQuote(ch)){
                    state = IN_QUOTE_QUOTE;
                } else {
                    sb.append(ch);
                }
                break;
            case IN_QUOTE_QUOTE:
                if (isQuote(ch)) {
                    sb.append(ch);
                } else {
                    i--;
                }
                state = IN_STRING;
                break;
            }
        }
        String tmp = new String(sb);
        if (tmp.length() != 0)
        	list.add(tmp);
        return list;
    }

    public static void main(String []args){
        System.out.println(target);
        System.out.println("");
        for (String s : divide(target))
            System.out.println(s);
    }
}
