package condor.gahp.unicore;

import java.io.File;

import org.unicore.ajo.AbstractJob;
import condor.gahp.GahpInterface;
import org.unicore.Vsite;
import com.fujitsu.arcon.servlet.Identity;
import com.fujitsu.arcon.servlet.VsiteTh;
import com.fujitsu.arcon.servlet.Reference;

/**
 * This class provides a Job recover thread.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */

public class JobRecoverRunnable implements Runnable {

	/**
	 * request id
	 */
	public final int REQ_ID;

	/**
	 * Job Classad
	 */
	private String jobClassad;

	/**
	 * GahpInterface object
	 */
	private GahpInterface gahp;

	/**
	 * Job handle
	 */
	private String job_handle;

	/**
     * Construct a default JobRecoverRunnable.
	 * @param reqId Request ID
	 * @param jobClassad Job ClassAd
	 * @param gahp GahpInterface Object
	 */
	public JobRecoverRunnable(int reqId, String jobClassad,
			GahpInterface gahp) {
		this.REQ_ID = reqId;
		this.jobClassad = jobClassad;
		this.gahp = gahp;
	}

	/**
	 *  
	 */
	public void run() {
		UnicoreGahp.setConnectionKeepOpen();

		AbstractJob ajo;
		String handle;

		try {
			JobInfo info = new JobInfo();
			JobStatusInfo stinfo = new JobStatusInfo();
			info.parse(jobClassad);
			if (info.getJobHandle() == null) {
				throw new Exception(
						"the classAd does not include contact string!");
			}

			Log.jobId.set(info.getCondorId());
			Log.log("JobRecoverRunnable run");

			gahp.storeObject(info.getJobHandle().jobId + "jobinfo", info);
			gahp.storeObject(info.getJobHandle().jobId + "jobstatus", stinfo);

			JobHandle jobHandle = info.getJobHandle();

			//Identity creation
			Identity identity = new Identity(new File(info.getKeystoreFile()),
					info.getPasswd().toCharArray(), info.getUserAlias());

			VsiteTh vsiteTh = new VsiteTh(new Reference.SSL(info
					.getUnicoreUSite(), identity), new Vsite(info
					.getUnicoreVSite()));

			// create a priodic task
			MonitorTask task = new MonitorTask(gahp, info, stinfo, vsiteTh, 10);
			UnicoreGahp.registerTimerTask(gahp, task, jobHandle.jobId, 30, 30);

			gahp.addResult(REQ_ID, new String[] { "S", "null" });
			Log.log("** SUCCESS Recover Job");

		} //try
		catch (Exception e) {
			Log.log("** ERROR Recover Job " + e );
            String errMsg =( e.getMessage() == null) ? "unknown" : e.getMessage();
            String[] result = {"F", errMsg};
            gahp.addResult(REQ_ID, result);
			return;
		}
	}
}