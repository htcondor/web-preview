package condor.gahp.unicore;
import java.util.*;


public class MapParser {
	static final int OUT            = 0;
	static final int IN_KEY         = 1;
	static final int IN_KEY_ESCAPE  = 2;
	static final int IN_VAL         = 3;
	static final int IN_VAL_ESCAPE  = 4;

	//static String target = "one \"two\" spacey' '''quoted''' 'argument '''a''' ''''a''''";
	static String target = "a=b; c = a \\=d ";
	
	//static String target = "'''a'''";
	static boolean isEscape(int i){
		return i == '\\';
	}

	static boolean isEqual(int i){
		return i == '=';
	}
	static boolean isSemi(int i){
		return i == ';';
	}
	

	static Map<String,String> divide(String str){
		Map <String,String> map = new HashMap<String,String>();

		int pointer = 0;
		int state   = IN_KEY;
		StringBuffer sb = new StringBuffer();
		String key = null;  
		
		for (int i = 0; i < str.length(); i++){		   
			char ch = (char)str.charAt(i);
			switch (state) {
			case IN_KEY:
				if (isEscape(ch)){
					state = IN_KEY_ESCAPE;
				} else if (isEqual(ch)) {
					key = sb.toString();
					sb = new StringBuffer();
					state = IN_VAL;
				} else if (isSemi(ch)) {
					// semicolon is not allow here 
					return null;
				} else {
					sb.append(ch);
				}
				break;
			case IN_KEY_ESCAPE:
				if (isEscape(ch) || isEqual(ch) || isSemi(ch)) { 
					sb.append(ch);
					state = IN_KEY;
				} else {
					// escape error 
					return null;
				}
				break;
			case IN_VAL:
				if (isEscape(ch)){
					state = IN_VAL_ESCAPE;
				} else if (isEqual(ch)) {
					// 
					return null;
				} else if (isSemi(ch)) {
					String val = sb.toString();
					sb = new StringBuffer();
					map.put(key.trim(), val.trim());
					state = IN_KEY;
				} else {
					sb.append(ch);
				}
				break;
			case IN_VAL_ESCAPE:
				if (isEscape(ch) || isEqual(ch) || isSemi(ch)) { 
					sb.append(ch);
					state = IN_VAL;
				} else {
					// escape error 
					return null;
				}
				break;
			}
		}
		if (state == IN_VAL){
			String val = sb.toString();
			map.put(key.trim(), val.trim());
		}
		return map;
	}

	public static void main(String []args){
		System.out.println(target);
		System.out.println("");
		Map<String,String> map = divide(target);
		for (String s : map.keySet())
			System.out.println("--" + s + "--" + map.get(s) + "--");
	}
	
}
