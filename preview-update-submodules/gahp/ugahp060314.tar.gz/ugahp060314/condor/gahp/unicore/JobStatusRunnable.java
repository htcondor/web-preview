package condor.gahp.unicore;

import java.io.IOException;
import com.fujitsu.arcon.servlet.OutcomeTh;

import condor.gahp.GahpInterface;

/**
 * This class provides a Job status thread.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.4 $ $Date: 2005/07/19 02:13:16 $ 
 * 
 */
public class JobStatusRunnable extends JobRunnable {

    private String log;
    private OutcomeTh outcome;
    private String status;
    private String statusCode;
    private String text_classad;
    private String xml_classad;

    /**
     * Construct a default JobStatusRunnable.
     * @param reqId
     * @param jobHandleString
     * @param gahp
     */
    public JobStatusRunnable(
        int reqId,
        String jobHandleString,
        GahpInterface gahp) {
        super(reqId, jobHandleString, gahp);
    }

    /**
     * Thread
     */
    public void run() {
        if (!setup()) {
            return;
        }

        JobStatusInfo stinfo =(JobStatusInfo) gahp.getObject(jobHandle.jobId + "jobstatus");

        if (gahp.getObject(jobHandle.jobId + "monitorTask") == null &&
			(stinfo == null || stinfo.getJobStatus() != 4)
			) {
            // no monitor Task for the handle, this means
            // the monitor task gave up to get the status.
            // possibly the job died. 
            // return failure to notify it to Condor.
            Log.log("   no task monitor for this job, and the status is not done.");
			Log.log("   possibly the job died");
            gahp.addResult(
                reqId,
                new String[] { "F", "<c></c>", "Monitor task gave up" });
            Log.log("** Failed Status Job");
            return;
        }

        outcome = (OutcomeTh) gahp.getObject(jobHandle.jobId + "outcome");

        if (outcome == null) {
            Log.log("** outcome is null");
        }

        //jobinfo object is used to get byteSend value
        JobInfo info = (JobInfo) gahp.getObject(jobHandle.jobId + "jobinfo");

        xml_classad = null;

        if (stinfo == null) {
            stinfo = new JobStatusInfo();
        }

        if (outcome != null) {
            stinfo.setUnicoreJobStatus(outcome);
        }

        text_classad = stinfo.createClassad();

        try {
            xml_classad = stinfo.convertClassad(text_classad);
        } catch (IOException e) {
            //Log.printStackTrace(e);
            gahp.addResult(reqId, new String[] { "F", "<c></c>", e.toString()});
            Log.log("** Failed Status Job");
            return;
        }
        String[] result = { "S", xml_classad, "null" };
        // store statusinfo
        gahp.storeObject(jobHandle.jobId + "jobstatus", stinfo);

        if (outcome != null) {
            gahp.storeObject(jobHandle.jobId + "outcome", outcome);
        }
        gahp.addResult(reqId, result);
        Log.log("** SUCCESS Status Job");
    }
}
