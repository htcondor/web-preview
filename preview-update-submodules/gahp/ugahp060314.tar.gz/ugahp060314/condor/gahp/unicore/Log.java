package condor.gahp.unicore;

import java.util.Calendar;

/**
 * This class provides a Manage condor job id.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
class CondorJobId extends ThreadLocal {

    /**
     * @return Object
     */
    protected synchronized Object initialValue() {
        return "------";
    }

    /**
     * @return String
     */
    public String toString() {
        Object o = get();
        if (o == null) {
            return "------";
        } else {
            return o.toString();
        }
    }
}

/**
 * This class provides a logging.
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version 0.5.1 (06/02/2005) 
 */
public class Log {

    static CondorJobId jobId = new CondorJobId();

    /**
     * date and time header
     * @return String
     */
    private static String header() {
        
        Calendar cal = Calendar.getInstance();
        int mon = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DATE);
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int min = cal.get(Calendar.MINUTE);
        int sec = cal.get(Calendar.SECOND);
        String daytime =
            mon + 1 + "/" + day + " " + hour + ":" + min + ":" + sec;
        String idStr = " [" + jobId.toString() + "]: ";
        return daytime + idStr;
    }

    /**
     * logging string
     * @param str
     */
    static void log(String str) {
        System.err.println(header() + str);
    }

    /**
     * logging object name
     * @param obj
     */
    static void log(Object obj) {
        log(obj.toString());
    }

    /**
     * print stack tarce
     * @param e
     */
    static void printStackTrace(Throwable e) {
        System.out.print(header());
        e.printStackTrace(System.out);
    }

    /**
     * set object
     * @param obj
     */
    static void set(Object obj) {
        jobId.set(obj);
    }
}
