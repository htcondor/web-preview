package condor.gahp.unicore;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.security.Security;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.*;

import org.unicore.Vsite;
import org.unicore.ajo.AbstractJob;
import org.unicore.ajo.ActionGroup;
import org.unicore.ajo.CopyFile;
import org.unicore.ajo.CopyPortfolioToOutcome;
import org.unicore.ajo.DeclarePortfolio;
import org.unicore.ajo.DeletePortfolio;
import org.unicore.ajo.ExecuteScriptTask;
import org.unicore.ajo.IncarnateFiles;
import org.unicore.ajo.MakePortfolio;
import org.unicore.ajo.Option;
import org.unicore.ajo.Portfolio;
import org.unicore.ajo.ScriptType;
import org.unicore.ajo.ActionGroup.InvalidDependencyException;
import org.unicore.sets.OptionSet;
import org.unicore.sets.ResourceSet;

import com.fujitsu.arcon.servlet.Connection;
import com.fujitsu.arcon.servlet.Gateway;
import com.fujitsu.arcon.servlet.Identity;
import com.fujitsu.arcon.servlet.JobManager;
import com.fujitsu.arcon.servlet.PortfolioTh;
import com.fujitsu.arcon.servlet.VsiteManager;
import com.fujitsu.arcon.servlet.VsiteTh;
import com.fujitsu.arcon.servlet.Reference;
import com.fujitsu.arcon.servlet.JobManager.Exception;
import com.sun.net.ssl.internal.ssl.Provider;

import condor.classad.ClassAdParser;
import condor.classad.Constant;
import condor.classad.Expr;
import condor.classad.ListExpr;
import condor.classad.RecordExpr;


/**
 * This class provides a Manage job information used to create AJO.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.7 $ $Date: 2005/07/22 03:00:52 $
 * 
 */
public class JobInfo {

	static final String CLUSTER_ID = "ClusterId";

	static final String PROC_ID = "ProcId";

	static final String JOB_HANDLE_ATTR = "GlobusContactString";
    static final String GRID_RESOURCE_ATTR = "GridResource";
    static final String GRID_JOB_ID_ATTR = "GridJobId";

	/**
	 * hash table
	 */
	protected static Hashtable htable;

	private float sendDataSize;

	private float recvDataSize;

	private String condorId = null;

	private JobHandle jobHandle = null;

	/**
	 * retry counter for job create
	 */
	protected int create_retry_cnt;

	/**
	 * retry counter for job consign
	 */
	protected int consign_retry_cnt;

	/**
	 * initial working directory
	 */
	private String iwd;

	/**
	 * command or script file name you want to execute
	 */
	private String cmd;

	/**
	 * command line arguments
	 */
	private String [] args;

	/**
	 * environmental variables
	 */
	private String[] env;

	/**
	 * input files
	 */
	private String in;

	/**
	 * output file
	 */
	private String out;

	/**
	 * error file
	 */
	private String err;

	/**
	 * access target of UNICORE
	 */
	private String unicoreUsite;

	/**
	 * Vsite name defined by UNICORE NJS
	 */
	private String unicoreVsite;

	/**
	 * keystore file for UNICORE Client
	 */
	private String keystoreFile;

	/**
	 * passphrase file described password to unlock keystore file
	 */
	private String passphraseFile;

	/**
	 * alias name in the keystore
	 */
	private String userAlias;

	/**
	 * input files transfered to UNICORE before job execution
	 */
	private String[] transferInput;

	/**
	 * output files transfered from UNICORE after job termination
	 */
	private String[] transferOutput;


	/**
	 *  mapping from    
	 */
	private Map<String, String> transferOutputRemaps = null; 	
	public Map<String, String> getTrasferOutputRemaps (){
		return transferOutputRemaps;
	}
	private File transferOutputRemapsTmpDir = null;
	public  File getTransferOutputRemapsTmpDir(){
		return transferOutputRemapsTmpDir;
	}
	
	/**
	 * password to unlock keystore file
	 */
	private String passwd;

	/**
	 * should transfer cmd or not
	 */
	private boolean transferExecutable;

	/**
	 * should transfer output or not
	 */
	private boolean transferOut;

	/**
	 * should transfer error or not
	 */
	private boolean transferErr;

	/**
	 * should transfer input or not
	 */
	private boolean transferIn;

	/**
	 * bags to pack transfer files into
	 */
	private PortfolioTh pfth;

	/**
	 * Construct a default JobInfo.
	 */
	public JobInfo() {
		create_retry_cnt = 0;
		consign_retry_cnt = 0;
		sendDataSize = 0;
		recvDataSize = 0;
		iwd = "./";
		cmd = null;
		args = null;
		env = null;
		in = null;
		out = null;
		err = null;
		unicoreUsite = null;
		unicoreVsite = null;
		keystoreFile = null;
		passphraseFile = null;
		userAlias = null;
		transferInput = null;
		transferOutput = null;
		transferExecutable = true;
		transferIn = true;
		transferOut = true;
		transferErr = true;
		passwd = null;
	}

	/**
	 * parse classad(xml expression)
	 * 
	 * @param jobClassad
	 *            job classad
	 * @exception NullPointerException
	 */
	public void parse(String jobClassad) throws java.lang.Exception {

		try {
			ClassAdParser parser = new ClassAdParser(jobClassad,
					ClassAdParser.XML);
			RecordExpr rexp = (RecordExpr) parser.parse();

			lookupSetIwd(rexp);

			if (!parseGridJobId(rexp)){
			  if (!parseGridResource(rexp)){
				throw new Exception("no correct GridJobId or "+
									"GridResources defined in the classAd");
			  }
			}
			lookupSetUnicoreKeystoreFile(rexp);
			lookupSetUnicorePassphraseFile(rexp);
			lookupSetUnicoreUserAlias(rexp);
			lookupSetArgs(rexp);
			lookupSetEnv(rexp);

			// executable
			lookupSetTransferExec(rexp);
			lookupSetCmd(rexp);

			// error
			lookupSetTransferErr(rexp);

			if (getTransferErr() == true) {
				lookupSetErr(rexp);
			}

			// input
			lookupSetTransferIn(rexp);
			if (getTransferIn() == true) {
				lookupSetIn(rexp);
				if ((getIn() != null) && (isExist(getIn()) != true)) {
					if (isExist(getIwd(), getIn()) != true) {
						Log.log("not found InputFile");
						throw new java.lang.Exception("not found InputFile");
					} else {
						setIn(getIwd() + "/" + getIn());
					}
				}
			} else {
				lookupSetIn(rexp);
			}

			// output
			Expr exp = rexp.lookup("TransferOutput");
			if (exp != null) {
				if (exp instanceof Constant) {
					String str = (String) ((Constant) exp).value;
					transferOutput = str.split(",");
					if (transferOutput == null) {
						Log.log("not found TransferOutputFile");
						throw new java.lang.Exception(
								"not found TransferOutputFile");
					}
				}
			}

			lookupSetTransferOut(rexp);
			if (getTransferOut() == true) {
				lookupSetOut(rexp);
			}

			readCondorId(rexp);
			lookupSetTransferOutputRemaps(rexp);

			// pre-stagein files
			// check transfer input file and existence
			exp = rexp.lookup("TransferInput");
			if (exp != null) {
				if (exp instanceof Constant) {
					String str = (String) ((Constant) exp).value;
					transferInput = str.split(",");
					if (transferInput != null) {
						for (int i = 0; i < transferInput.length; i++) {
							if (transferInput[i] != null) {
								if (isExist(transferInput[i]) != true) {

									if (isExist(getIwd(), transferInput[i]) == true) {
										transferInput[i] = getIwd() + "/"
												+ transferInput[i];

										if (isDupulicateTransferInput(in,
												transferInput[i])) {
											transferIn = false;
										}else if(isDupulicateTransferInput(cmd,
												transferInput[i])) {
											transferExecutable = false;
										}

									} else {
										Log.log("not found TransferInputFile");
										throw new java.lang.Exception(
												"not found TransferInputFile");
									}
								}else{
									if (isDupulicateTransferInput(in,transferInput[i])) {
										transferIn = false;
									}else if(isDupulicateTransferInput(cmd,
											transferInput[i])) {
										transferExecutable = false;
									}
								}
							}
						}
					}
				}
			}
			// check transfer input file and existence

			// PortfolioTh
			// check standard input file to be transfered
			if ((getIn() != null) && (getTransferIn() == true)) {
				String inp = getIn();

				if (isExist(inp) != true) {
					if (isExist(getIwd(), getIn()) == true) {
						setIn(getIwd() + "/" + getIn());
					} else {
						Log.log("not found InputFile");
						throw new java.lang.Exception("not found InputFile");
					}
				}

				if (getTransferInput() != null) {
					String[] tin = getTransferInput();

					if (getTransferExecutable() == true) {
						if (isExist(getCmd()) != true) {
							if (isExist(getIwd(), getCmd()) == true) {
								cmd = getIwd() + "/" + getCmd();
							}
						} else {
							Log.log("not found executable file");
							throw new java.lang.Exception(
									"not found ExecutableFile");
						}

						String[] str = new String[1 + tin.length + 1];
						for (int i = 0; i < tin.length; i++) {
							str[i] = tin[i];
						}
						str[tin.length] = inp;
						str[tin.length + 1] = getCmd();
						// str includes transferinput ,input ,executable
						setPfth(str);

					} else {
						String[] str = new String[tin.length + 1];
						for (int i = 0; i < tin.length; i++) {
							str[i] = tin[i];
						}
						str[tin.length] = inp;
						// str includes transferinput ,input
						setPfth(str);
					}
				} else if (getTransferExecutable() != true) {
					// str includes input
					setPfth(new String[] { inp });
				} else {
					String[] str = new String[1 + 1];
					str[0] = inp;
					str[1] = getCmd();
					// str includes input, executable
					setPfth(str);
				}
			} else if (getTransferInput() != null) {
				String[] tin = getTransferInput();

				if (getTransferExecutable() == true) {
					if (isExist(getCmd()) != true) {
						if (isExist(getIwd(), getCmd()) != true) {
							throw new java.lang.Exception(
									"not found ExecutableFile");
						} else {
							cmd = getIwd() + "/" + getCmd();
						}
					}
					String[] str = new String[1 + tin.length];
					for (int i = 0; i < tin.length; i++) {
						str[i] = tin[i];
					}
					str[tin.length] = getCmd();
					// str includes transfer input, executable
					setPfth(str);
				} else {
					String[] str = new String[tin.length];
					for (int i = 0; i < tin.length; i++) {
						str[i] = tin[i];
					}
					// str includes transfer input
					setPfth(str);
				}
			} else if (getTransferExecutable() == true) {
				if (isExist(getCmd()) != true) {
					if (isExist(getIwd(), getCmd()) != true) {
						throw new java.lang.Exception(
								"not found ExecutableFile");
					} else {
						cmd = getIwd() + "/" + getCmd();
					}
				}
				String[] str = new String[1];
				str[0] = this.getCmd();
				// str includes executable
				setPfth(str);
			}
		} catch (Exception e) {
			Log.printStackTrace(e);
			throw e;
		}
	} // parse

	
	/**
	 * set input file
	 * 
	 * @param input_file_name
	 */
	public void setIn(String input_file_name) {
		in = input_file_name;
	}

	/**
	 * set initial working directory
	 * 
	 * @param string
	 */
	public void setIwd(String string) {
		iwd = string;
	}

	/**
	 * set keystore file
	 * 
	 * @param string
	 */
	public void setKeystoreFile(String string) {
		keystoreFile = string;
	}

	/**
	 * set output file
	 * 
	 * @param string
	 */
	public void setOut(String string) {
		out = string;
	}

	/**
	 * set passphrase file
	 * 
	 * @param string
	 */
	public void setPassphraseFile(String string) {
		passphraseFile = string;
	}

	/**
	 * set user alias
	 * 
	 * @param string
	 */
	public void setUserAlias(String string) {
		userAlias = string;
	}

	/**
	 * set password
	 * 
	 * @param string
	 */
	public void setPasswd(String string) {
		passwd = string;
	}

	/**
	 * set input file to be transfered
	 * 
	 * @param string
	 */
	public void setTransferInput(String[] string) {
		transferInput = string;
	}

	/**
	 * set output file to be transfered
	 * 
	 * @param string
	 */
	public void setTransferOutput(String[] string) {
		transferOutput = string;
	}

	/**
	 * set transferExecutable
	 * 
	 * @param b
	 *            boolean
	 */
	public void setTransferExecutable(boolean b) {
		transferExecutable = b;
	}

	/**
	 * set UNICORE Gaetway address
	 * 
	 * @param string
	 */
	public void setUnicoreUSite(String string) {
		unicoreUsite = string;
	}


		/**
	 * get command
	 * 
	 * @return String
	 */
	public String getCmd() {
		return cmd;
	}

	/**
	 * get environmental variables
	 * 
	 * @return String[]
	 */
	public String[] getEnv() {
		return env;
	}

	/**
	 * get error files
	 * 
	 * @return String
	 */
	public String getErr() {
		return err;
	}

	/**
	 * get input files
	 * 
	 * @return String[]
	 */
	public String getIn() {
		return in;
	}

	/**
	 * get initial working directory
	 * 
	 * @return String
	 */
	public String getIwd() {
		return iwd;
	}

	/**
	 * get keystore file
	 * 
	 * @return String
	 */
	public String getKeystoreFile() {
		return keystoreFile;
	}

	/**
	 * get output file
	 * 
	 * @return String
	 */
	public String getOut() {
		return out;
	}

	/**
	 * get passphrase file
	 * 
	 * @return String
	 */
	public String getPassphraseFile() {
		return passphraseFile;
	}

	/**
	 * get useralias
	 * 
	 * @return String
	 */
	public String getUserAlias() {
		return userAlias;
	}

	/**
	 * get password
	 * 
	 * @return String
	 * @exception IOException
	 */
	public String getPasswd() throws IOException {
		// Get Password from keystore file
		BufferedReader br = new BufferedReader(new FileReader(
				getPassphraseFile()));
		passwd = br.readLine();
		br.close();

		return passwd;
	}

	/**
	 * getTransferInput
	 * 
	 * @return String[]
	 */
	public String[] getTransferInput() {
		return transferInput;
	}

	/**
	 * get output files to be transfered
	 * 
	 * @return String[]
	 */
	public String[] getTransferOutput() {
		return transferOutput;
	}

	/**
	 * get transferExecutable
	 * 
	 * @return boolean
	 */
	public boolean getTransferExecutable() {
		return transferExecutable;
	}

	/**
	 * get transferIn
	 * 
	 * @return boolean
	 */
	public boolean getTransferIn() {
		return transferIn;
	}

	/**
	 * get transferOut
	 * 
	 * @return boolean
	 */
	public boolean getTransferOut() {
		return transferOut;
	}

	/**
	 * get transferErr
	 * 
	 * @return boolean
	 */
	public boolean getTransferErr() {
		return transferErr;
	}

	/**
	 * get UNICORE Gateway address
	 * 
	 * @return String
	 */
	public String getUnicoreUSite() {
		return unicoreUsite;
	}

	/**
	 * get Vsite name defined by UNICORE NJS
	 * 
	 * @return String
	 */
	public String getUnicoreVSite() {
		return unicoreVsite;
	}

	/**
	 * set bags to package transfering files into
	 * 
	 * @param files
	 */
	protected void setPfth(String [] files) {
		
		MakePortfolio mkpf = new MakePortfolio();
		mkpf.setFiles(files);

		File[] f = new File[files.length];

		// byteSend
		int file_size = 0;

		try {
			for (int i = 0; i < files.length; i++) {
				f[i] = new File(files[i]);
				file_size += f[i].length();
			}
			// set file transfer size
			sendDataSize = file_size;

		} catch (NullPointerException e) {
			Log.log(e);
			Log.printStackTrace(e);
		}

		PortfolioTh pf = new PortfolioTh(mkpf.getPortfolio(), f);
		this.pfth = pf;
	}

	/**
	 * get bags to package transfering files into
	 * 
	 * @return PortfolioTh
	 */
	public PortfolioTh getPfth() {
		return this.pfth;
	}

	/**
	 * make id for signing ajo.
	 * 
	 * @param keystore
	 *            keystore file
	 * @param passwd
	 *            password to unlock keystore
	 * @param userAlias
	 * @return Identity id for signing AJO
	 * @throws com.fujitsu.arcon.servlet.Identity.Exception
	 * @exception Exception
	 * @exception com.fujitsu.arcon.servlet.Identity.Exception
	 */
	public Identity makeId(String keystore, String passwd, String userAlias)
			throws com.fujitsu.arcon.servlet.Identity.Exception {

		Security.addProvider(new Provider());

		File keystorefile = new File(keystore);

		if (keystorefile.exists() == false) {
			Log.log("## Not Found!! Keystore File");
		}

		Identity identity = new Identity(keystorefile, passwd.toCharArray(),
				userAlias);

		return identity;
	}

	/**
	 * get accessible Vsite list
	 * 
	 * @param gateway
	 *            UNICORE Gateway address
	 * @param vsite_name
	 *            Vsite Name
	 * @param identity
	 *            id for signing AJO
	 * @return Vsite
	 * @throws Exception
	 */
	public Vsite getVsiteFromGw(String gateway, String vsite_name,
			Identity identity) {

		Gateway gw = null;
		Vsite vsite = null;
		Iterator it = null;
		Object obj = null;
		String str = null;

		while ((this.consign_retry_cnt++ < 10 && gw == null) && (it == null)) {
			try {
				gw = new Gateway(new Reference.SSL(gateway, identity));
				VsiteManager.addGateway(gw);
				JobManager.listVsites(gw);
				it = VsiteManager.getVsites();

				while (this.consign_retry_cnt++ < 10 && it.hasNext()) {
					obj = it.next();
					str = obj.toString();
					if (str.equals(vsite_name)) {
						vsite = ((VsiteTh) obj).getVsite();
						return vsite;
					}
				}

			} catch (Gateway.Exception e1) {
				if (this.consign_retry_cnt != 1) {
					Log.log(e1);
					Log.log(e1.toString() + " <Retry: "
							+ this.consign_retry_cnt + " times >");
				}
				try {
					Thread.sleep((long) (10000 * Math.random()));
				} catch (InterruptedException e2) {
				}
			} catch (Reference.Exception e1) {
				if (this.consign_retry_cnt != 1) {
					Log.log(e1);
					Log.log(e1.toString() + " <Retry: "
							+ this.consign_retry_cnt + " times >");
				}
				try {
					Thread.sleep((long) (10000 * Math.random()));
				} catch (InterruptedException e2) {
				}
			} catch (Connection.Exception e) {
				if (this.consign_retry_cnt != 1) {
					Log.log(e);
					Log.log(e.toString() + " <Retry: " + this.consign_retry_cnt
							+ " times >");
				}
				try {
					Thread.sleep((long) (10000 * Math.random()));
				} catch (InterruptedException e2) {
				}
			} catch (java.lang.Exception e) {
				Log.log(e);
				if (this.consign_retry_cnt != 1) {
					Log.log(e.toString() + " <Retry: " + this.consign_retry_cnt
							+ " times >");
				}
				try {
					Thread.sleep((long) (10000 * Math.random()));
				} catch (InterruptedException e2) {
				}
			}
		}

		// retry part
		try {
			gw = new Gateway(new Reference.SSL(gateway, identity));
			VsiteManager.addGateway(gw);
			JobManager.listVsites(gw);
		} catch (com.fujitsu.arcon.servlet.Gateway.Exception e) {
		} catch (com.fujitsu.arcon.servlet.Reference.Exception e) {
		} catch (Exception e1) {
		} catch (com.fujitsu.arcon.servlet.Connection.Exception e1) {
		}
		it = VsiteManager.getVsites();

		while (this.consign_retry_cnt++ < 10 && it.hasNext()) {
			obj = it.next();
			str = obj.toString();
			if (str.equals(vsite_name)) {
				vsite = ((VsiteTh) obj).getVsite();
				return vsite;
			} else {
				Log.log("vsite name not matched!");
				Log.log(" <Retry: " + this.consign_retry_cnt + " times >");
			}
		}
		// end retry part

		if (vsite == null) {
			Log.log("vsite obj is null!");
		}
		Log.log("Vsite Name you specified isn't registered");
		// throw new Exception("Vsite Name you specified isn't registered");
		return vsite;
	}

	/**
	 * create VsiteTh object
	 * 
	 * @param ajo
	 *            AJO
	 * @param identity
	 *            id for signing AJO
	 * @return VsiteTh
	 * @exception com.fujitsu.arcon.servlet.Reference.Exception
	 */
	public VsiteTh makeVsiteTh(AbstractJob ajo, Identity identity)
			throws com.fujitsu.arcon.servlet.Reference.Exception {
		VsiteTh vsite_th = new VsiteTh(new Reference.SSL(ajo.getVsite()
				.getAddress(), identity), ajo.getVsite());
		return vsite_th;
	}

	/**
	 * create empty AJO
	 * 
	 * @param jobname
	 *            job name
	 * @return AbstractJob AJO
	 */
	public AbstractJob makeAJO(String jobname) {
		AbstractJob ajo = new AbstractJob(jobname);
		return ajo;
	}

	/**
	 * Create ScriptTask for file transfer
	 * 
	 * @param ajo
	 *            rootAJO
	 * @param script
	 *            script you want to execute
	 * @param export
	 *            file name you want to be ridirected to
	 * @return ActionGroup this action group contains script task
	 * @exception InvalidDependencyException
	 *                invalid workflow dependency
	 */
	public ActionGroup makeExecScriptTask(AbstractJob ajo, String script,
			String export) throws InvalidDependencyException {

		Log.log("creating script for '" + script +"'");
		
		ActionGroup actg_execst = new ActionGroup("SCRIPT");

		IncarnateFiles inf_execst = new IncarnateFiles("SCRIPT-Task-1");
		inf_execst.addFile("script_file", script.getBytes());

		MakePortfolio mkpf_execst = new MakePortfolio("SCRIPT-Task-2");
		mkpf_execst.addFile("script_file");

		ExecuteScriptTask execst = new ExecuteScriptTask("SCRIPT-Task-3");
		execst.setScriptType(ScriptType.SH);
		execst.setExecutable(mkpf_execst.getPortfolio());

		if (export != null) {
			execst.setStdoutFileName(export);
			execst.setRedirectStdout(true);
		}

		// Env
		OptionSet ops = makeEnv(getEnv());
		if (ops != null) {
			execst.setEnvironmentVariables(ops);
		}

		DeletePortfolio delpf_execst = new DeletePortfolio("SCRIPT-Task-5");
		delpf_execst.setPortfolio(mkpf_execst.getPortfolio().getId());

		IncarnateFiles inf_stdin = null;
		MakePortfolio mkpf_stdin = null;
		if (getIn() != null) {
			inf_stdin = new IncarnateFiles("SCRIPT-Task-4");

			if (getIn().indexOf("/") == -1) {
				inf_stdin.addFile("stdin_file", getIn().getBytes());
				mkpf_stdin = new MakePortfolio("SCRIPT-Task-4");
				mkpf_stdin.addFile("stdin_file");
				mkpf_stdin.setFiles(new String[] { this.in });
				execst.setStdin(mkpf_stdin.getPortfolio());
			} else {
				String stdin_org = getIn();
				String stdin = stdin_org.substring(
						stdin_org.lastIndexOf("/") + 1, stdin_org.length());
				inf_stdin.addFile("stdin_file", stdin.getBytes());
				mkpf_stdin = new MakePortfolio("SCRIPT-Task-4");
				mkpf_stdin.addFile("stdin_file");
				mkpf_stdin.setFiles(new String[] { stdin });
				execst.setStdin(mkpf_stdin.getPortfolio());
			}

			// add tasks to action groups
			actg_execst.add(inf_execst);
			actg_execst.add(mkpf_execst);
			actg_execst.add(inf_stdin);
			actg_execst.add(mkpf_stdin);
			actg_execst.add(execst);
			actg_execst.add(delpf_execst);

			// set dependency among action groups
			actg_execst.addDependency(inf_execst, inf_stdin);
			actg_execst.addDependency(mkpf_stdin, mkpf_execst);
			actg_execst.addDependency(mkpf_execst, execst);
			actg_execst.addDependency(execst, delpf_execst);

			return actg_execst;
		}
		// add tasks to action groups
		actg_execst.add(inf_execst);
		actg_execst.add(mkpf_execst);
		actg_execst.add(execst);
		actg_execst.add(delpf_execst);

		// set dependency among action groups
		actg_execst.addDependency(inf_execst, mkpf_execst);
		actg_execst.addDependency(mkpf_execst, execst);
		actg_execst.addDependency(execst, delpf_execst);

		return actg_execst;
	}

	/**
	 * crate export task
	 * 
	 * @param ajo
	 *            rootAJO
	 * @param export
	 *            file you want to export from unicore
	 * @return ActionGroup
	 * @exception InvalidDependencyException
	 *                invalid workflow dependency
	 */
	public ActionGroup makeExportTask(AbstractJob ajo, String export)
			throws InvalidDependencyException {

		// IncarnateFiles->MakePortfolio->PutPortfolio->DeletePortfolio->ExportTask
		ActionGroup actg_expt = new ActionGroup("EXPORT");

		IncarnateFiles inf_expt = new IncarnateFiles("EXPORT-Task-1");
		inf_expt.addFile("export_file", export.getBytes());

		MakePortfolio mkpf_expt = new MakePortfolio("EXPORT-Task-2");
		mkpf_expt.addFile(export);

		DeletePortfolio delpf_expt = new DeletePortfolio("EXPORT-Task-3");
		delpf_expt.setPortfolio(mkpf_expt.getPortfolio().getId());

		// copy PutPortfolio files to Outcome
		ResourceSet rscset = new ResourceSet();
		CopyPortfolioToOutcome cppftout_expt = new CopyPortfolioToOutcome(
				"EXPORT-Task-4", rscset.cloneSet(), mkpf_expt.getPortfolio()
						.getId());

		// add tasks to action groups
		actg_expt.add(inf_expt);
		actg_expt.add(mkpf_expt);
		actg_expt.add(delpf_expt);
		actg_expt.add(cppftout_expt);

		// set dependency among action groups
		actg_expt.addDependency(inf_expt, mkpf_expt);
		actg_expt.addDependency(mkpf_expt, delpf_expt);
		actg_expt.addDependency(delpf_expt, cppftout_expt);

		return actg_expt;
	}

	/**
	 * create export task
	 * 
	 * @param ajo
	 *            rootAJO
	 * @param exports
	 *            file name you want to export from UNICORE
	 * @return ActionGroup action group
	 * @exception InvalidDependencyException
	 *                invalid workflow dependency
	 */
	public ActionGroup makeExportTask(AbstractJob ajo, String[] exports)
			throws InvalidDependencyException {

		// IncarnateFiles->MakePortfolio->PutPortfolio->DeletePortfolio->ExportTask

		ActionGroup actg_expt = new ActionGroup("EXPORT");

		IncarnateFiles inf_expt = new IncarnateFiles("EXPORT-Task-1");

		inf_expt.addFile("export_file", exports[0].getBytes());
		// now export[] -> exports[0]

		MakePortfolio mkpf_expt = new MakePortfolio("EXPORT-Task-2");

		for (int i = 0; i < exports.length; i++) {
			mkpf_expt.addFile(exports[i]);
		}

		// ppf_expt.setOverwrite(true);
		DeletePortfolio delpf_expt = new DeletePortfolio("EXPORT-Task-3");
		delpf_expt.setPortfolio(mkpf_expt.getPortfolio().getId());

		// copy PutPortfolio file to Outcome
		ResourceSet rscset = new ResourceSet();
		CopyPortfolioToOutcome cppftout_expt = new CopyPortfolioToOutcome(
				"EXPORT-Task-4", rscset.cloneSet(), mkpf_expt.getPortfolio()
						.getId());

		// add tasks to action groups
		actg_expt.add(inf_expt);
		actg_expt.add(mkpf_expt);
		actg_expt.add(delpf_expt);
		actg_expt.add(cppftout_expt);

		// set dependency among action groups
		actg_expt.addDependency(inf_expt, mkpf_expt);
		actg_expt.addDependency(mkpf_expt, delpf_expt);
		actg_expt.addDependency(delpf_expt, cppftout_expt);

		return actg_expt;
	}

	/**
	 * create import task
	 * 
	 * @param pf
	 *            portfoli contains import file's information
	 * @return ActionGroup action group
	 * @exception InvalidDependencyException
	 *                invalid workflow dependency
	 */
	public ActionGroup makeImportTask(Portfolio pf)
			throws InvalidDependencyException {

		ActionGroup actg_impt = new ActionGroup("IMPORT");

		CopyFile cpf_impt = new CopyFile("IMPORT-TASK-1");

		// copy portfolio files to upper directory
		cpf_impt.setFrom("." + pf.getUPLDirectoryName() + "/*");
		cpf_impt.setTo("");
		cpf_impt.setOverwrite(true);

		DeclarePortfolio decpf_impt = new DeclarePortfolio("IMPORT-TASK-2");
		decpf_impt.setPortfolio(pf);

		// add tasks to action groups
		actg_impt.add(cpf_impt);
		actg_impt.add(decpf_impt);

		// set dependency among action groups
		actg_impt.addDependency(cpf_impt, decpf_impt);

		return actg_impt;
	}

	/**
	 * merge action groups and create rootAJO
	 * 
	 * @param info
	 *            job info
	 * @return AbstractJob AJO
	 * @exception NullPointerException
	 * @exception ClassCastException
	 * @exception IOException
	 * @exception com.fujitsu.arcon.servlet.Identity.Exception
	 * @exception com.fujitsu.arcon.servlet.Gateway.Exception
	 * @exception com.fujitsu.arcon.servlet.Connection.Exception
	 * @exception InvalidDependencyException
	 *                invalid workflow dependency
	 */
	public AbstractJob createJob(JobInfo info) throws Exception {

		try {
			// set ID
			Identity identity = makeId(getKeystoreFile(), getPasswd(),
					getUserAlias());

			Vsite vsite = getVsiteFromGw(getUnicoreUSite(), getUnicoreVSite(),
					identity);
			if (vsite == null) {
				return null;
			}
			// Create an empty AJO.
			AbstractJob ajo = makeAJO("CondorJob");

			// ImportTask
			ActionGroup impt = null;
			if (pfth != null) {
				impt = makeImportTask(pfth.getPortfolio());
				// now element of array size=1
			}
			StringBuffer strbuf = new StringBuffer();

			// ScriptTask
			if (getCmd()  == null) {
				Log.log("You must set Cmd!! ");
				throw new Exception("You must set Cmd attribute");
			}

			String command = info.getCmd();
			strbuf.append("chmod 755 ./*; ");
			
			if (info.getTransferExecutable() == true) {
				strbuf.append("./");
				strbuf.append(command.substring(
						command.lastIndexOf("/") + 1, command.length()));
			} else {
				strbuf.append(command);
			}

			if (args != null) {
				strbuf.append(" ");
				strbuf.append(escapeForShell(args));
			}
			String script = strbuf.toString();
			
			ActionGroup execst = null; // ExecuteSctriptTask
			ActionGroup expt = null; // ExportTask

			Log.log("JobInfo makeTask");

			/*******************************************************************
			 * post-stage routine
			 ******************************************************************/
			if ((getOut() != null) && (getTransferOut() == true)) {
				String out = getOut();

				if (getTransferOutput() != null) {

					String[] tout = getTransferOutput();

					String[] str = new String[tout.length + 1];
					for (int i = 0; i < tout.length; i++) {
						str[i] = tout[i];
					}
					str[tout.length] = out;
					expt = makeExportTask(ajo, str);
				} else {
					expt = makeExportTask(ajo, out);
				}
				execst = makeExecScriptTask(ajo,  script, out);

			} else if (getOut() == null) {
				if (getTransferOutput() != null) {
					String[] tout = getTransferOutput();
					expt = makeExportTask(ajo, tout);
					execst = makeExecScriptTask(ajo, script, null);
				} else {
					execst = makeExecScriptTask(ajo, script, null);
				}
			}

			// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

			// AJO group and task dependency
			if (pfth != null) {
				ajo.add(impt);
				ajo.add(execst);

				if (((getOut() == null) || (getTransferOut() == false))
						&& (getTransferOutput() == null)) {
					ajo.addDependency(impt, execst);
				} else {
					ajo.add(expt);
					ajo.addDependency(impt, execst);
					ajo.addDependency(execst, expt);
				}
			} else if (((getOut() == null) || (getTransferOut() == false))
					&& getTransferOutput() == null) {
				ajo.add(execst);
			} else {
				ajo.add(execst);
				ajo.add(expt);
				ajo.addDependency(execst, expt);
			}
			// set vsite to the AJO
			ajo.setVsite(vsite);
			return ajo;

		} catch (NullPointerException e) {
			Log.log(e);
			Log.printStackTrace(e);
		} catch (ClassCastException e) {
			Log.log(e);
			Log.printStackTrace(e);
		} catch (IOException e) {
			Log.log(e);
			Log.printStackTrace(e);
		} catch (com.fujitsu.arcon.servlet.Identity.Exception e) {
			Log.log(e);
			Log.printStackTrace(e);
		} catch (InvalidDependencyException e) {
			Log.log(e);
			Log.printStackTrace(e);
		} catch (Exception e) {
			Log.log(e);
			Log.printStackTrace(e);
		}
		return null;
	}

	/**
	 * @param rexp
	 */
	public void lookupSetIwd(RecordExpr rexp) {
		Expr exp = rexp.lookup("Iwd");
		if (exp != null) {
			setIwd((String) ((Constant) exp).value);
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetCmd(RecordExpr rexp) {
		Expr exp = rexp.lookup("Cmd");
		if (exp != null) {
			cmd = (String) ((Constant) exp).value;
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetOut(RecordExpr rexp) {
		Expr exp = rexp.lookup("Out");
		if (exp != null) {
			out =(String) ((Constant) exp).value;
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetErr(RecordExpr rexp) {
		Expr exp = rexp.lookup("Err");
		if (exp != null) {
			err = (String) ((Constant) exp).value;
		}
	}

	/**
	 * 
	 * @param rexp
	 */
	public void lookupSetUnicoreUserAlias(RecordExpr rexp) {
		Expr exp = rexp.lookup("KeystoreAlias");
		if (exp != null) {
			setUserAlias((String) ((Constant) exp).value);
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetUnicorePassphraseFile(RecordExpr rexp) {
		Expr exp = rexp.lookup("KeystorePassphraseFile");
		if (exp != null) {
			String file = (String) ((Constant) exp).value;
			if (isExist(file) == true) {
				setPassphraseFile(file);
			} else if (isExist(getIwd() + "/" + file) == true) {
				setPassphraseFile(getIwd() + "/" + file);
			} else {
				Log.log("not found UnicorePassphraseFile");
			}
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetUnicoreKeystoreFile(RecordExpr rexp) {
		Expr exp = rexp.lookup("KeystoreFile");
		if (exp != null) {
			String file = (String) ((Constant) exp).value;
			if (isExist(file) == true) {
				setKeystoreFile(file);
			} else if (isExist(getIwd() + "/" + file) == true) {
				setKeystoreFile(getIwd() + "/" + file);
			} else {
				Log.log("not found UnicoreKeystoreFile");
			}
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetTransferExec(RecordExpr rexp) {
		Expr exp = rexp.lookup("TransferExecutable");
		if (exp != null) {
			if (exp instanceof Constant) {
				boolean b = ((Constant) exp).booleanValue();
				setTransferExecutable(b);
			} else {
				setTransferExecutable(true);
			}
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetTransferIn(RecordExpr rexp) {
		Expr exp = rexp.lookup("TransferIn");
		if (exp != null) {
			if (exp instanceof Constant) {
				boolean b = ((Constant) exp).booleanValue();
				transferIn = b;
			} else {
				transferIn = true;
			}
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetTransferOut(RecordExpr rexp) {
		Expr exp = rexp.lookup("TransferOut");
		if (exp != null) {
			if (exp instanceof Constant) {
				boolean b = ((Constant) exp).booleanValue();
				transferOut = b;
			} else {
				transferOut = true;
			}
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetTransferErr(RecordExpr rexp) {
		Expr exp = rexp.lookup("TransferErr");
		if (exp != null) {
			if (exp instanceof Constant) {
				boolean b = ((Constant) exp).booleanValue();
				transferErr = b;
			} else {
				transferErr = true;
			}
		}
	}


	/**
	 * @param rexp
	 */
	public void lookupSetArgs(RecordExpr rexp) {
		Expr exp = rexp.lookup("Arguments");
		if (exp != null){
			if (exp instanceof Constant) {
				 String tmp = (String) ((Constant) exp).value;
				this.args = divideNewArgs(tmp);
			} else {
				Log.log("Arguments is not constant" );
			}
			return;
		}
		// if 'Arguments' is not defined in the classAd, try old syntax
		exp = rexp.lookup("Args");
		if (exp != null) {
			if (exp instanceof Constant) {
				 String tmp = (String) ((Constant) exp).value;
				this.args = divideOldArgs(tmp);
			}
		} else {
			Log.log("not found Args attribute");
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetIn(RecordExpr rexp) {
		Expr exp = rexp.lookup("In");

		if (exp != null) {
			if (exp instanceof Constant) {
				String str = (String) ((Constant) exp).value;
				if (str.equals("/dev/null")) {
					setIn(null);
				} else {
					setIn(str);
				}

			}
		} else {
			Log.log("not found In attribute");
		}
	}

	/**
	 * @param rexp
	 */
	public void lookupSetEnv(RecordExpr rexp) {
		Expr exp = rexp.lookup("Environment");
		if (exp != null){
			if (exp instanceof Constant) {
				String str = (String) ((Constant) exp).value;
				this.env = divideNewArgs(str);
			} else {
				Log.log("Arguments is not constant" );
			}
		} else {
			exp = rexp.lookup("Env");
			if (exp != null) {
				if (exp instanceof Constant) {
					String str = (String) ((Constant) exp).value;
					env = str.split(";");
					if (env == null) {
						Log.log("not found Env");
					}
				}
			}
		}
		if (env != null)
			for (String tmpEnv: env)
				Log.log("env: " + tmpEnv);
		
	}

	
	public void lookupSetTransferOutputRemaps(RecordExpr rexp) throws IOException {
		Expr exp = rexp.lookup("TransferOutputRemaps");
		if (exp != null){
			if (exp instanceof Constant) {
				String str = (String) ((Constant) exp).value;
				transferOutputRemaps = createMap(str);
				transferOutputRemapsTmpDir = 
					File.createTempFile("ugahpTmp."+condorId, null);
				transferOutputRemapsTmpDir.delete();
				transferOutputRemapsTmpDir.mkdirs();
			} else {
				Log.log("TransferOutputRemaps is not constant");
			}
		}

	}
	
	private Map<String, String> createMap(String str){
//		Map<String, String> map = new HashMap<String, String>();
//		// should be fixed to support ; and = in the filenamse 
//		String [] pairs =  str.split(";");
//		for (String pair: pairs ){
//			String [] tupple = pair.split("="); 
//			if (tupple.length < 2){
//				Log.log("In createMap: pair does not include '=' " + pair);
//				continue;
//			}
//			map.put(tupple[0], tupple[1]);
//		}
		Map<String, String> map = MapParser.divide(str);
		if (map == null){
			Log.log("failed to parse map String. " + str);
			map = new HashMap<String, String>();
		}
		return map;
	}
	
	/**
	 * @return JobHandle
	 */
	public JobHandle getJobHandle() {
		return jobHandle;
	}

    public void setJobHandle(JobHandle handle){
	  jobHandle = handle;
    }


  //	/**
  //	 * read job handle
  //	 * 
  //	 * @param rexp
  //	 */
  //	public void readJobHandle(RecordExpr rexp) {
// 		// jobHanldeStr
// 		Expr exp = rexp.lookup(JOB_HANDLE_ATTR);
// 		String jobHandleStr = null;
// 		if (exp != null) {
// 			jobHandleStr = ((String) ((Constant) exp).value);
// 			try {
// 				jobHandle = new JobHandle(jobHandleStr);
// 			} catch (JobHandle.Exception e) {
// 				Log.log("unknown format handle :" + jobHandleStr);
// 			}
// 		}
// 	}



	/**
	 * @return String
	 */
	public String getCondorId() {
		return condorId;
	}

	/**
	 * read condor job id
	 * 
	 * @param rexp
	 */
	public void readCondorId(RecordExpr rexp) {
		Expr exp;
		String val = "";
		exp = rexp.lookup(CLUSTER_ID);
		if (exp != null) {
			val = val + ((Integer) ((Constant) exp).value);
		} else {
			val = val + "---";
		}
		val = val + ".";
		exp = rexp.lookup(PROC_ID);
		if (exp != null) {
			val = val + ((Integer) ((Constant) exp).value);
		} else {
			val = val + "---";
		}
		condorId = val;
	}

	/**
	 * @return int Returns the sendDataSize.
	 */
	public float getSendDataSize() {
		return sendDataSize;
	}

	/**
	 * @return int Returns the recvDataSize.
	 */
	public float getRecvDataSize() {
		return recvDataSize;
	}

	/**
	 * @param size
	 *            The recvDataSize to set.
	 */
	public void setRecvDataSize(float size) {
		this.recvDataSize = size;
	}

	/**
	 * @param file_name
	 * @return boolean file exsit or not
	 */
	public boolean isExist(String file_name) {
		if (new File(file_name).exists() == true) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @param base
	 *            base directory name
	 * @param file_name
	 * @return boolean file exsit or not
	 */
	public boolean isExist(String base, String file_name) {
		if ((new File(base + "/" + file_name)).exists() == true) {
			return true;
		} else {
			return false;
		}
	}

//	/**
//	 * @param str
//	 *            String
//	 * @param num
//	 *            length of String array
//	 * @return String[] String array
//	 */
//	public String[] getFiles(String str, int num) {
//		if ((num <= 0) || (str == null)) {
//			return null;
//		}
//
//		String[] f = new String[num];
//
//		StringTokenizer st_files = new StringTokenizer(str, ",");
//		String file = null;
//
//		for (int i = 0; i < num; i++) {
//			file = st_files.nextToken().trim();
//			if (file.length() > 0) {
//				f[i] = file;
//			}
//		}
//		return f;
//	}
//
//	/**
//	 * @param str
//	 *            String
//	 * @return cnt counts of file
//	 */
//	public int getFileCounts(String str) {
//		int cnt = 0;
//		StringTokenizer st_files = new StringTokenizer(str, ",");
//		String file = null;
//
//		while (st_files.hasMoremakeEnvTokens()) {
//			cnt++;
//			file = st_files.nextToken().trim();
//		}
//		return cnt;
//	}

	/**
	 * @param envmakeEnv
	 * @return
	 */
	public OptionSet makeEnv(String[] env) {
		OptionSet ops = new OptionSet();
		Option op = null;
		if (env != null && env.length >= 1) {
			String[] environment = null;
			
			for (int i = 0; i < env.length; i++) {
				
				Log.log("env = " + env[i]);
				environment = env[i].split("=", 2);
				if (environment.length < 2)
					continue;
				op = new Option(environment[0]);
				op.setValue(escapeOneString(environment[1]));
				ops.add(op);
			}
			return ops;
		} else {
			return null;
		}
	}

	/**
	 * @param in
	 * @param transferIn
	 * @return
	 */
	public boolean isDupulicateTransferInput(String in, String transferIn) {
		if (in == null)
			return false;
		if (in.equals(transferIn)) {
			return true;
		} else {
			return false;
		}
	}



  /** 
   *
   */
  private boolean parseGridResource(RecordExpr rexp) throws Exception{
	Expr exp = rexp.lookup(GRID_RESOURCE_ATTR);
	if (exp == null) 
	  return false;
	String resourceString  = (String) ((Constant) exp).value;
	Pattern p = Pattern.compile("unicore\\s+(\\S+:.\\d+)\\s+(\\S+)");
	Matcher m = p.matcher(resourceString);
	boolean b = m.matches();
	if (!b)
	  return false;
	unicoreUsite = m.group(1);
	unicoreVsite = m.group(2);
	return true;
  }

  /** 
   *
   */
  private boolean parseGridJobId(RecordExpr rexp) throws Exception{
	Expr exp = rexp.lookup(GRID_JOB_ID_ATTR);
	if (exp == null) 
	  return false;
	String resourceString  = (String) ((Constant) exp).value;
	Pattern p = Pattern.compile("unicore\\s+(\\S+:.\\d+)\\s+(\\S+)\\s+(\\S+)");
	Matcher m = p.matcher(resourceString);
	boolean b = m.matches();
	if (!b)
	  return false;
	unicoreUsite = m.group(1);
	unicoreVsite = m.group(2);
	try {
	  jobHandle = new JobHandle(m.group(3));
	} catch (JobHandle.Exception e) {
	  Log.log("unknown format handle :" + m.group(3));
	  return false;
	}

	return true;
  }

  static char [] specials = 
	  new char[]{'|', '&', ';', '(', ')', '<', '>', ' ', '\t', '\\', '\'', '\"', '$'} ;

  private String escapeOneString(String arg){
	  StringBuffer sb = new StringBuffer();
	  for (char c: arg.toCharArray()){
		  boolean isIn = false;
		  for (char i: specials){
			  if (c == i){
				  isIn = true;
				  break;
			  }
		  }
		  if (isIn)
			  sb.append('\\');
		  sb.append(c);
	  }

	  return sb.toString();
  }
  
  private String escapeForShell(String [] args){

	  StringBuffer sb = new StringBuffer();
	  for (String arg: args){
		  sb.append(escapeOneString(arg));
		  sb.append(" ");
	  }
		  
	  return sb.toString(); 
  }
 
  private String[] divideNewArgs(String argString){
	  List <String> list = NewArrayStringParser.divide(argString);
	  return list.toArray(new String[0]);
  }
  
  private String[] divideOldArgs(String argString){
	  StringTokenizer st = new StringTokenizer(argString);
	  List <String> list = new ArrayList<String>();
	  while (st.hasMoreTokens()){
		  list.add(st.nextToken());
	  }
	  return list.toArray(new String[0]);
  }
  
}




