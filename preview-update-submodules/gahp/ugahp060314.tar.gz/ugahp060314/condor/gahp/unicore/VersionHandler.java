package condor.gahp.unicore;

import condor.gahp.CommandHandler;
import condor.gahp.CommandHandlerResponse;
import condor.gahp.GahpInterface;
import condor.gahp.IOUtils;

/**
 * This class provides a UNICORE GAHP Server version.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
public class VersionHandler implements CommandHandler {

    private GahpInterface gahp = null;

    /**
     * handle command
     * @param command command line from stdin
     * @return CommandHandlerResponse result
     */
    public CommandHandlerResponse handleCommand(String[] command) {
        return new CommandHandlerResponse(
            CommandHandlerResponse.SUCCESS
                + " $UnicoreGahpVersion: 1.2.0 Mar 22 2006  "
                + IOUtils.escapeWord(UnicoreGahp.getVersion())
                + " $");
    }

    /**
     * set gahp
     * @param g gahp
     */
    public void setGahp(GahpInterface g) {
        this.gahp = g;
    }
}
