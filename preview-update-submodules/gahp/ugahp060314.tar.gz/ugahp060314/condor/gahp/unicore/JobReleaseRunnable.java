package condor.gahp.unicore;

import java.io.File;

import org.unicore.ajo.Control;
import org.unicore.ajo.ControlAction;
import com.fujitsu.arcon.servlet.Identity;
import com.fujitsu.arcon.servlet.OutcomeTh;
import com.fujitsu.arcon.servlet.JobManager;
import com.fujitsu.arcon.servlet.VsiteTh;
import com.fujitsu.arcon.servlet.Reference;

import condor.gahp.GahpInterface;

/**
 * This class provides a Job release thread.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
public class JobReleaseRunnable extends JobRunnable {

	/**
     * Construct a default JobReleaseRunnable.
	 * 
	 * @param reqId
	 * @param jobHandleString
	 * @param gahp
	 */
	public JobReleaseRunnable(int reqId, String jobHandleString,
			GahpInterface gahp) {
		super(reqId, jobHandleString, gahp);
	}

	/**
	 * Thread
	 */
	public void run() {
		if (!setup()) {
			return;
		}

		try {
			OutcomeTh outcome = (OutcomeTh) gahp.getObject(jobHandle.jobId
					+ "outcome");

			ControlAction release = new ControlAction("ReleaseJob", ajo
					.getAJOId(), Control.RESUME);

			JobInfo info = (JobInfo) gahp
					.getObject(jobHandle.jobId + "jobinfo");

			java.security.Security
					.addProvider(new com.sun.net.ssl.internal.ssl.Provider());

			Identity identity = new Identity(new File(info.getKeystoreFile()),
					info.getPasswd().toCharArray(), info.getUserAlias());

			VsiteTh vsiteTh = new VsiteTh(new Reference.SSL(ajo.getVsite()
					.getAddress(), identity), ajo.getVsite());

			JobManager.executeAction(release, vsiteTh);
			Log.log("** SUCCESS Releasing Job");

		} catch (Exception e) {
			Log.log("** ERROR Releasing Job" + e);
			String errMsg = (e.getMessage() == null) ? "unknown" : e
					.getMessage();
			String[] result = { "F", errMsg };
			gahp.addResult(reqId, result);
			return;
		}
		String[] result = { "S", "null" };
		gahp.addResult(reqId, result);
	}
}