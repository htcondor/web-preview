package condor.gahp.unicore;

import condor.gahp.CommandHandler;
import condor.gahp.CommandHandlerResponse;
import condor.gahp.GahpInterface;

/**
 * This class provides a Handle job recover.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:47 $ 
 * 
 */
public class JobRecoverHandler implements CommandHandler {

	private GahpInterface gahp;

	/**
     * Construct a default JobRecoverHandler.
	 */
	public JobRecoverHandler() {
	}

	/**
	 * @see condor.gahp.CommandHandler
	 * @param cmd
	 * @return CommandHandlerResponse
	 */
	public CommandHandlerResponse handleCommand(String[] cmd) {

		try {

			if (cmd.length != 3) {
				Log.log("Args: <reqest-id> <job-classad>");
				return CommandHandlerResponse.SYNTAX_ERROR;
			}
			//        Integer reqId;
			int reqId = new Integer(cmd[1]).intValue();
			//check reqId data format
			if (reqId < 1) {
				Log.log("Args: <reqest-id> must be number > 0");
				return CommandHandlerResponse.SYNTAX_ERROR;
			}
			String job_classAd = cmd[2];

			JobRecoverRunnable toRun = new JobRecoverRunnable(reqId,
					job_classAd, gahp);
			return new CommandHandlerResponse(CommandHandlerResponse.SUCCESS,
					toRun);
		}//try
		catch (NumberFormatException e) {
			Log.log("Args: <reqest-id> must be number (0 < number < "
					+ Integer.MAX_VALUE + ")");
			Log.log(e);
			Log.printStackTrace(e);
			return CommandHandlerResponse.SYNTAX_ERROR;
		} catch (Exception e) {
			Log.log(e);
			Log.printStackTrace(e);
			return CommandHandlerResponse.SYNTAX_ERROR;
		}
	}

	/**
	 * @see condor.gahp.CommandHandler
	 * @param g
	 */
	public void setGahp(GahpInterface g) {
		gahp = g;
	}

} //UnicoreJobRecoverHandler

