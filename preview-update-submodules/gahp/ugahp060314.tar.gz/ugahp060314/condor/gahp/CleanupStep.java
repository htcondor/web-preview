package condor.gahp;

/**
 * An interface for cleaning up GAHP Server.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.6 $ $Date: 2005/07/01 02:26:55 $ 
 * 
 */
public interface CleanupStep {

    /**
     * Cleans up GAHP Server.
     */
    public void doCleanup();    
}
