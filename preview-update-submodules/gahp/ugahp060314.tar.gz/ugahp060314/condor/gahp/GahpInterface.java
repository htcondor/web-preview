package condor.gahp;

/**
 * An Interface to manage object.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:55 $ 
 * 
 */
public interface GahpInterface {

    /**
     * Add the action item to be run when Gahp Server shuts down.
     * @param step cleanup step.
     */
    public void addCleanupStep(CleanupStep step);

    /**
     * Add results into result queue.
     * @param reqId request id.
     * @param result results of GAHP commands.
     */
    public void addResult(int reqId, String[] result);

    /**
     * Generate unique id.
     * @return String unique id.
     */
    public String generateUniqueId();

    /**
     * Get GAHP commands.
     * @return String[] GAHP commands.
     */
    public String[] getCommands();

    /**
     * Get object from the table.
     * @param key key associated with object.
     * @return Object object in the table.
     */
    public Object getObject(String key);

    /**
     * Get GAHP Server version.
     * @return String version.
     */
    public String getVersion();

    /**
     * Remove object from the table.
     * @param key key associated with object.
     * @return Object object in the table.
     */
    public Object removeObject(String key);

    /**
     * Notify the gahp that to exit E.g. the QUIT command handler calls this
	 * request exit.
     */
    public void requestExit();

    /**
     * Store object in the table.
     * @param key Key associated with object.
     * @param object object which you want to store in the table.
     * @return Object object in the table.
     */
    public Object storeObject(String key, Object object);
}
