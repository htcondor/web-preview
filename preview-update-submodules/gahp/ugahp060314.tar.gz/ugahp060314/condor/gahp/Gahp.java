package condor.gahp;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;
import java.util.Properties;
import java.util.Enumeration;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;

/**
 * This class implements GahpInterface that can be used to manage GAHP Server.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:55 $ 
 * 
 */
public class Gahp implements GahpInterface {

	public static final String VERSION = "NAREGI Condor-U";

	protected static int uniqueIdSeed = 0;

	private String printPrefix = "";

	protected Vector cleanupSteps = new Vector();

	protected Hashtable commandDispatchTable = new Hashtable();

	protected Hashtable commonObjectTable = new Hashtable();

	protected boolean hasNewResults = false;

	protected boolean isAsyncMode = false;

	protected boolean quitSignaled = false;

	protected CommandResultQueue resultQueue = new CommandResultQueue();

	protected PrintStream stdout;

	/**
	 * Construct a default Gahp.
	 */
	public Gahp() {
	}

	/**
	 * Construct a default Gahp.
	 * 
	 * @param commandClassMapping
	 */
	public Gahp(Properties commandClassMapping) {
		// Bootstrap commands
		commandDispatchTable.put("RESULTS", new ResultsHandler());
		commandDispatchTable.put("QUIT", new QuitHandler());
		commandDispatchTable.put("COMMANDS", new CommandsHandler());
		commandDispatchTable.put("ASYNC_MODE_ON", new AsyncModeOnHandler());
		commandDispatchTable.put("ASYNC_MODE_OFF", new AsyncModeOnHandler());

		// Other commands
		Enumeration propertyNamesEnum = commandClassMapping.propertyNames();

		while (propertyNamesEnum.hasMoreElements()) {
			String commandName = propertyNamesEnum.nextElement().toString();
			String className = commandClassMapping.getProperty(commandName);
			CommandHandler handler = null;
			try {
				Object instance = Class.forName(className).newInstance();
				if (!(instance instanceof CommandHandler)) {
					throw new ClassCastException("Class " + className
							+ " does not implement " + "required interface "
							+ CommandHandler.class.toString());
				}
				handler = (CommandHandler) instance;
			} catch (Exception e) {
				e.printStackTrace(System.err);
				continue;
			}
			commandDispatchTable.put(commandName, handler);
		}
		// Set pointers to this Gahp server for all handlers
		for (Iterator iter = commandDispatchTable.values().iterator(); iter
				.hasNext();) {
			((CommandHandler) iter.next()).setGahp((GahpInterface) this);
		}
		// If we get shutdown irregular manner (e.g. SIGTERM)
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
			public void run() {
				doCleanupSteps();
			}
		}));
	}

	/**
	 * Main program.
	 * 
	 * @param args
	 * @throws Exception
	 * @exception Exception
	 */
	public static void main(String[] args) throws Exception {
		if (args.length < 1) {
			System.err.println("Usage Gahp <command mapping file>");
			System.exit(1);
		}
		Properties props = null;
		try {
			props = new Properties();
			props.load(ClassLoader.getSystemResourceAsStream(args[0]));

		} catch (Exception e) {
			e.printStackTrace(System.err);
			System.exit(1);
		}
		Gahp gahp = new Gahp(props);
		// GAHP output
		gahp.stdout = System.out;
		System.setOut(System.err);
		// GAHP input
		BufferedReader stdin = new BufferedReader(new InputStreamReader(
				System.in));

		// Print the version
		String[] version = gahp.processCommand("VERSION");
		synchronized (gahp.stdout) {
			gahp.stdout.println(version[0].substring(2));
			// Remove leading "S "
		}
		// This is the main command loop
		while (!gahp.quitSignaled) {
			String prefix = gahp.printPrefix;
			// Read command
			String line = null;

			try {
				line = stdin.readLine();
			} catch (java.io.IOException e) {
				e.printStackTrace(System.err);
				gahp.stdout.println(prefix + CommandHandlerResponse.ERROR);
				continue;
			}
			if (line == null) {
				gahp.requestExit();
				continue;
			}
			// Parse the line

			String[] result = gahp.processCommand(line);
			synchronized (gahp.stdout) {
				for (int i = 0; i < result.length; i++) {
					gahp.stdout.println(prefix + result[i]);
				}
			}
		}
		gahp.shutdown();
	}

	/**
	 * @see GahpInterface
	 */
	public void addCleanupStep(CleanupStep step) {
		cleanupSteps.add(step);
	}

	/**
	 * @see GahpInterface
	 */
	public void addResult(int reqId, String[] result) {
		synchronized (this.resultQueue) {
			if (hasNewResults == false && isAsyncMode == true) {
				// We've just added a new result, signal
				synchronized (stdout) {
					stdout.println(printPrefix + "R");
				}
			}
			hasNewResults = true;
			this.resultQueue.addResult(reqId, result);
		} // synchronized
	}

	/**
	 * clean up.
	 */
	public void doCleanupSteps() {
		synchronized (cleanupSteps) {
			for (int i = 0; i < cleanupSteps.size(); i++) {
				CleanupStep step = (CleanupStep) cleanupSteps.get(i);
				step.doCleanup();
			}
			cleanupSteps.clear();
		}
	}

	/**
	 * @see GahpInterface
	 */
	public String generateUniqueId() {
		String uniqueId;
		synchronized (this) {
			uniqueId = "" + (++uniqueIdSeed);
		}
		return uniqueId;
	}

	/**
	 * @see GahpInterface
	 */
	public String[] getCommands() {
		Vector v = new Vector();
		v.addAll(commandDispatchTable.keySet());
		java.util.Collections.sort(v);
		String[] result = new String[v.size()];
		v.copyInto(result);
		return result;
	}

	/**
	 * @see GahpInterface
	 */
	public Object getObject(String key) {
		synchronized (commonObjectTable) {
			return this.commonObjectTable.get(key);
		}
	}

	/**
	 * @see GahpInterface
	 */
	public String getVersion() {
		return VERSION;
	}

	/**
	 * parse command syntax.
	 * 
	 * @param cmd
	 *            command string which includes GAHP command.
	 * @return String[] result string.
	 */
	protected String[] parseCommand(String cmd) {

		Vector args = new Vector();
		StringBuffer currentArg = new StringBuffer();

		for (int i = 0; i < cmd.length(); i++) {
			char c = cmd.charAt(i);
			if ((c == '\\') // if this char = '\'
					&& (i < cmd.length() - 1) // and there is a next char
					&& ((cmd.charAt(i + 1) == ' ') || // and the next char is a
							// space
							(cmd.charAt(i + 1) == '\n') || (cmd.charAt(i + 1) == '\r')) // or a
			// newline
			) {
				// then it must be an embedded space,
				currentArg.append(cmd.charAt(i + 1));
				// so just it as part of this agrument
				i++; // and skip processing the next char
			} else if (c == ' ' || c == '\t' || c == '\r') { // Found true
				// separator char
				args.add(currentArg.toString()); // so add the current argument
				currentArg.setLength(0); // and reset the buffer
			} else {
				//plain old char
				currentArg.append(c);
			}
		}
		if (currentArg.length() > 0) {
			// Add the last argument (since there usually isn't a termination
			// char after it)
			args.add(currentArg.toString());
			currentArg.setLength(0);
		}
		// Copy into array
		String[] result = new String[args.size()];
		args.copyInto(result);
		return result;
	}

	/**
	 * parse command and dispatch it to each process. Dispatch the command to
	 * the right handler Return the return line
	 * 
	 * @param line
	 * @return String[]
	 */
	protected String[] processCommand(String line) {
		String[] command = parseCommand(line);

		if (command == null || command.length == 0) {
			return CommandHandlerResponse.SYNTAX_ERROR.RETURN_LINE;
		}
		// Figure out handler for this command
		CommandHandler handler = null;
		if (command != null) {
			// Convert command name to uppercase, so that it is case-insensitive
			command[0] = command[0].toUpperCase();
			handler = (CommandHandler) commandDispatchTable.get(command[0]);
		}
		if (handler == null) {
			return CommandHandlerResponse.SYNTAX_ERROR.RETURN_LINE;
		}
		// Invoke the handler (this should return immediately)
		// This gives you back a return line and possibly a Runnable object
		CommandHandlerResponse response = handler.handleCommand(command);

		// If there is a Runnable returned, spawned a new thread with it
		if (response.TO_RUN != null) {
			// QUESTION: Should there be a upper limit on conncurrent threads?
			new Thread(response.TO_RUN).start();
		}
		// Return return line
		return response.RETURN_LINE;
	}

	/**
	 * @see GahpInterface
	 */
	public Object removeObject(String key) {
		synchronized (commonObjectTable) {
			return this.commonObjectTable.remove(key);
		}
	}

	/**
	 * @see GahpInterface
	 */
	public void requestExit() {
		quitSignaled = true;
	}

	/**
	 * set asynchronous mode
	 * 
	 * @param mode
	 */
	protected synchronized void setAsyncMode(boolean mode) {
		synchronized (this.resultQueue) {
			isAsyncMode = mode;
			if (isAsyncMode) {
				hasNewResults = false;
			}
		}
	}

	/**
	 * shutdown
	 */
	private void shutdown() {
		doCleanupSteps();

		if (this.quitSignaled) {
			System.exit(0);
		}
	}

	/**
	 * @see GahpInterface
	 */
	public Object storeObject(String key, Object object) {

		synchronized (commonObjectTable) {
			Object lastObject = this.commonObjectTable.get(key);
			this.commonObjectTable.put(key, object);
			return lastObject;
		}
	}

	/**
	 * @author Yasuyoshi ITOU (Fujitsu Limited)
	 * @version 0.5.1 (06/02/2005)
	 */
	class AsyncModeOffHandler implements CommandHandler {

		/**
		 * handle command
		 * 
		 * @param cmd
		 *            command line from stdin
		 * @return CommandHandlerResponse result
		 */
		public CommandHandlerResponse handleCommand(String[] cmd) {
			setAsyncMode(false);
			return new CommandHandlerResponse(CommandHandlerResponse.SUCCESS);
		} // handleCommand

		/**
		 * set gahp
		 * 
		 * @param g
		 *            gahp
		 */
		public void setGahp(GahpInterface g) {
		}
	}

	/**
	 * @author Yasuyoshi ITOU (Fujitsu Limited)
	 * @version 0.5.1 (06/02/2005)
	 */
	class AsyncModeOnHandler implements CommandHandler {

		/**
		 * handle command
		 * 
		 * @param cmd
		 *            command line from stdin
		 * @return CommandHandlerResponse result
		 */
		public CommandHandlerResponse handleCommand(String[] cmd) {
			setAsyncMode(true);
			return new CommandHandlerResponse(CommandHandlerResponse.SUCCESS);
		} // handleCommand

		/**
		 * set gahp
		 * 
		 * @param g
		 *            gahp
		 */
		public void setGahp(GahpInterface g) {
		}
	}

	/**
	 * @author Yasuyoshi ITOU (Fujitsu Limited)
	 * @version 0.5.1 (06/02/2005)
	 */
	class NoOPHandler implements CommandHandler {

		/**
		 * handle command
		 * 
		 * @param command
		 *            command line from stdin
		 * @return CommandHandlerResponse result
		 */
		public CommandHandlerResponse handleCommand(String[] command) {
			return new CommandHandlerResponse(CommandHandlerResponse.SUCCESS,
					null);
		}

		/**
		 * set gahp
		 * 
		 * @param gahp
		 *            gahp
		 */
		public void setGahp(GahpInterface gahp) {
			// Not needed since we're an inner class
		}
	}

	/**
	 * @author Yasuyoshi ITOU (Fujitsu Limited)
	 * @version 0.5.1 (06/02/2005)
	 */
	class ResultsHandler implements CommandHandler {

		/**
		 * handle command
		 * 
		 * @param command
		 *            command line from stdin
		 * @return CommandHandlerResponse result
		 */
		public CommandHandlerResponse handleCommand(String[] command) {

			if (command.length != 1 && command[0].equals("RESULTS")) {
				return CommandHandlerResponse.SYNTAX_ERROR;
			}
			Vector result = new Vector();
			// This is only possible b/c we're an inner class
			CommandResultQueue.CommandResult[] results = null;
			synchronized (resultQueue) {
				results = resultQueue.flushResultList();
				hasNewResults = false;
			}
			// First line is # of words
			result.add(CommandHandlerResponse.SUCCESS + " " + results.length);
			// Go though each result and escape each word

			for (int i = 0; i < results.length; i++) {
				StringBuffer resultLineBuff = new StringBuffer();
				resultLineBuff.append(results[i].REQ_ID);

				for (int j = 0; j < results[i].RESULT.length; j++) {
					resultLineBuff.append(' ');
					resultLineBuff.append(IOUtils
							.escapeWord(results[i].RESULT[j]));
				}
				result.add(resultLineBuff.toString());
			}
			String[] resultArray = new String[result.size()];
			result.copyInto(resultArray);
			return new CommandHandlerResponse(resultArray, null);
		}

		/**
		 * set gahp
		 * 
		 * @param gahp
		 *            gahp
		 */
		public void setGahp(GahpInterface gahp) {
			// Not needed since we're an inner class
		}
	}
}

