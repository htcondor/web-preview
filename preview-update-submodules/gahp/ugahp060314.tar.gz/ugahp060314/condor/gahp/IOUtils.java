package condor.gahp;

/**
 * This class provides utility to deal with escape words.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:55 $ 
 * 
 */
public class IOUtils {

    /**
     * deal with escape words.
     * @param word
     * @return String
     */
    public static String escapeWord(String word) {
        if (word == null) {
            return null;
        }

        StringBuffer result = new StringBuffer();
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c == ' ') {
                result.append('\\');
            } else if (c == '\r' || c == '\n') {
                result.append('\\');
                c = ' ';
            }
            result.append(c);
        }
        return result.toString();
    }
}
