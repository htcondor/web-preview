package condor.gahp;

/**
 * This class provides a result of GAHP commands.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:55 $ 
 * 
 */
public class CommandHandlerResponse {
    
    public static final String ERROR = "E";
    public static final String FAILURE = "F";
    public static final String SUCCESS = "S";

    public static final CommandHandlerResponse SYNTAX_ERROR =
        new CommandHandlerResponse(ERROR, null);

    public final String[] RETURN_LINE;
    public final Runnable TO_RUN;

    /**
     * constructor
     * @param a return line
     */
    public CommandHandlerResponse(String a) {
        this(a, null);
    }

    /**
     * constructor
     * @param a return line
     * @param b runable object
     */
    public CommandHandlerResponse(String a, Runnable b) {
        this(new String[] { a }, b);
    }

    /**
     * constructor
     * This should be used by commands with more than one return line.
     * At this moment I can only think of "RESULTS".
     * @param rtn return line
     * @param run runable object
     */
    public CommandHandlerResponse(String[] a, Runnable b) {
    	RETURN_LINE = a;
        TO_RUN = b;
    }
}
