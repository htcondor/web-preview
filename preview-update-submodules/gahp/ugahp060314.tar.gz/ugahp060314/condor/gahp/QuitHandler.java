package condor.gahp;

/**
 * This class provides utility to handle QUIT command.
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:55 $ 
 * 
 */
public class QuitHandler implements CommandHandler{
    
    private GahpInterface gahp = null;
    
    /**
     * handle command
     * @param command command line from stdin
     * @return CommandHandlerResponse result
     */
    public CommandHandlerResponse handleCommand (String[] command) {
        gahp.requestExit();
        return new CommandHandlerResponse (CommandHandlerResponse.SUCCESS, null);
    }

    /**
     * set gahp
     * @param gahp gahp
     */
    public void setGahp (GahpInterface gahp) {
        this.gahp = gahp;
    }
}
