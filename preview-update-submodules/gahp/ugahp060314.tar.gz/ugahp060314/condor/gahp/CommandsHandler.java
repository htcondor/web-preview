package condor.gahp;

/**
 * This class implements a handleCommand that can be used to show aavailable commands list. 
 * 
 * @author Yasuyoshi ITOU (Fujitsu Limited)
 * @version $Revision: 1.3 $ $Date: 2005/07/01 02:26:55 $ 
 * 
 */
public class CommandsHandler implements CommandHandler {

    protected GahpInterface gahp;

    /**
     * handle "COMMAND" command.
     * @param cmd command line from standard input.
     * @return CommandHandlerResponse response object.
     */
    public CommandHandlerResponse handleCommand(String[] cmd) {

        if (!(cmd.length == 1 && cmd[0].equals("COMMANDS"))) {
            return CommandHandlerResponse.SYNTAX_ERROR;
        }
        String[] commands = gahp.getCommands();
        StringBuffer buff =
            new StringBuffer().append(CommandHandlerResponse.SUCCESS);

        for (int i = 0; i < commands.length; i++) {
            buff.append(' ').append(commands[i]);
        }
        return new CommandHandlerResponse(
            (String) buff.toString(),
            (Runnable) null);
    }

    /**
     * set gahp.
     * @param g gahp.
     */
    public void setGahp(GahpInterface g) {
        this.gahp = g;
    }
}
