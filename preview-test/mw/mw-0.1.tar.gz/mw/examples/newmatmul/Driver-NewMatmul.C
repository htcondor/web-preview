/***************************Copyright-DO-NOT-REMOVE-THIS-LINE**
  *
  * Condor Software Copyright Notice
  * Copyright (C) 1990-2004, Condor Team, Computer Sciences Department,
  * University of Wisconsin-Madison, WI.
  *
  * This source code is covered by the Condor Public License, which can
  * be found in the accompanying LICENSE.TXT file, or online at
  * www.condorproject.org.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  * AND THE UNIVERSITY OF WISCONSIN-MADISON "AS IS" AND ANY EXPRESS OR
  * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  * WARRANTIES OF MERCHANTABILITY, OF SATISFACTORY QUALITY, AND FITNESS
  * FOR A PARTICULAR PURPOSE OR USE ARE DISCLAIMED. THE COPYRIGHT
  * HOLDERS AND CONTRIBUTORS AND THE UNIVERSITY OF WISCONSIN-MADISON
  * MAKE NO MAKE NO REPRESENTATION THAT THE SOFTWARE, MODIFICATIONS,
  * ENHANCEMENTS OR DERIVATIVE WORKS THEREOF, WILL NOT INFRINGE ANY
  * PATENT, COPYRIGHT, TRADEMARK, TRADE SECRET OR OTHER PROPRIETARY
  * RIGHT.
  *
  ****************************Copyright-DO-NOT-REMOVE-THIS-LINE**/
/* Driver-Matmul.C

These methods specific to the matrix multiplication application

*/

#include "MW.h"
#include "Driver-NewMatmul.h"
#include "Worker-NewMatmul.h"
#include "Task-NewMatmul.h"

extern MWWorkerID *MWcurrentWorker;
extern double RMCOMM_bytes_packed;
extern double RMCOMM_bytes_unpacked;

/*
    int **matrixA;  
    int **matrixB;
*/
void Scanf ( int *m, int i, int j )
{
	*m = j;
}

Driver_Matmul::Driver_Matmul() 
{
	A = B = C = NULL;
	num_rows = 0;
	num_tasks = 0;
	partition_factor = 0;
}

Driver_Matmul::~Driver_Matmul() 
{
	int i;
	if ( A ) 
	{
		for ( i = 0; i < num_rows; i++ )
			delete [] A[i];
		delete [] A;
	}
	if ( B ) 
	{
		for ( i = 0; i < num_rows; i++ )
			delete [] B[i];
		delete [] B;
	}
	if ( C ) 
	{
		for ( i = 0; i < num_rows; i++ )
			delete [] C[i];
		delete [] C;
	}
}

MWReturn Driver_Matmul::get_userinfo( int argc, char *argv[] ) 
{
	int i, j, numarches;
	char exec[_POSIX_PATH_MAX];
	int num_exe;

	/* File format of the input file (which is stdin)
	     # arches worker_executables ...

         num_rowsA num_rowsB num_colsB
	 A B C
	*/

	RMC->set_num_exec_classes ( 1 );

	scanf ( "%d", &numarches );
	RMC->set_num_arch_classes( numarches );
	for ( i=0 ; i<numarches ; i++ ) 
	{
		if ( i == 0 )
			RMC->set_arch_class_attributes ( i, "((Arch==\"INTEL\") && (Opsys==\"LINUX\") && (Machine==\"antipholus.cs.wisc.edu\") )" );
		else
			RMC->set_arch_class_attributes ( i, "((Arch==\"INTEL\") && (Opsys==\"SOLARIS26\") )" );
	} 
	
	scanf ( "%d", &num_exe );
	RMC->set_num_executables( num_exe );
	for ( i = 0; i < num_exe; i++ )
	{
		scanf ( "%s %d", exec, &j );
		MWprintf ( 30, " %s\n", exec );
		RMC->add_executable( 0, j, exec, "");
	}
	
	scanf ( "%d", &num_rows );
	scanf ( "%d", &partition_factor );

/*
	A = new int*[num_rows];
	for ( i = 0; i < num_rows; i++ )
		A[i] = new int[num_rows];

	B = new int*[num_rows];
	for ( i = 0; i < num_rows; i++ )
		B[i] = new int[num_rows];

	matrixA = A;
	matrixB = B;


	C = new int*[num_rows];
	for ( i = 0; i < num_rows; i++ )
	{
		C[i] = new int[num_rows];
		for ( j = 0; j < num_rows; j++ )
			C[i][j] = 0;
	}


	for ( i = 0; i < num_rows; i++ )
		for ( j = 0; j < num_rows; j++ )
			scanf ( "%d ", &A[i][j] );

	for ( i = 0; i < num_rows; i++ )
		for ( j = 0; j < num_rows; j++ )
			scanf ( "%d ", &B[i][j] );
*/

	set_checkpoint_frequency ( 10000 );


	cut_halves = num_rows / partition_factor;
	workClasses_set ( cut_halves * cut_halves );
	num_tasks = cut_halves * cut_halves * cut_halves;
	RMC->set_target_num_workers( 40 );

	return OK;
}

MWReturn Driver_Matmul::setup_initial_tasks(int *n_init , MWTask ***init_tasks) 
{

	int i, j, k;
	int index = 0;

/* Basically we have to tell MW Layer of the number of tasks and what they are */

	*n_init = num_tasks;
	*init_tasks = new MWTask *[num_tasks];

/* And now we make the Task_Matmul instances.  They will basically contain the 
   rows to operate upon.
*/

	for ( i = 0 ; i < cut_halves ; i++ ) 
	{
		for ( j = 0; j < cut_halves; j++ )
		{
			for ( k = 0; k < cut_halves; k++ )
			{
				(*init_tasks)[index] = new Task_Matmul( i, j, k, num_rows, partition_factor );
				(*init_tasks)[index]->addGroup ( i * cut_halves + k );
				index++;
			}
		}
	}
	return OK;
}


MWReturn Driver_Matmul::act_on_completed_task( MWTask *t ) 
{
	int i, j;
	int strtR, strtC;

#ifdef NO_DYN_CAST
	Task_Matmul *tf = (Task_Matmul *) t;
#else
	Task_Matmul *tf = dynamic_cast<Task_Matmul *> ( t );
#endif

/*
	strtR = tf->resultStartR;
	strtC = tf->resultStartC;
	int indexi = 0, indexj = 0;

	for ( i = strtR; i < strtR + partition_factor; i++ )
	{
		indexj = 0;
		for ( j = strtC ; j < strtC + partition_factor; j++ )
		{
			C[i][j] += tf->results[indexi][indexj];
			indexj++;
		}
		indexi++;
	}
*/
	if ( workClasses_gettasks ( tf->grp ) == 1 )
	{
		refreshWorkers ( tf->grp, MW_ALL );
	}
	return OK;
}

MWReturn Driver_Matmul::act_on_starting_worker ( MWWorkerID *w )
{
	return OK;
}

MWReturn Driver_Matmul::pack_worker_init_data( void ) 
{
	// One has to pass the entire A and B matrices to the workers.
	int i;
	int passedint;

	i = GetGroup ( MWcurrentWorker );

	RMC->pack( &partition_factor, 1 );
	int startR = ( i / cut_halves ) * partition_factor;
	int startC = ( i % cut_halves ) * partition_factor;
	for ( int j = startR; j < startR + partition_factor; j++ )
	{
		for ( int k = startC; k < startC + partition_factor; k++ )
		{
			Scanf ( &passedint, j, k );
			RMC->pack ( &passedint, 1 );
		}
	}

	return OK;
}

int Driver_Matmul::GetGroup ( MWWorkerID *w )
{
	double max;
	int retval = 0;
	max = 0.0;
	for ( int i = 0; i < workClasses_get(); i++ )
	{
		if ( workClasses_gettasks ( i ) / ( workClasses_getworkers ( i ) + 1 ) > max )
		{
			max = workClasses_gettasks ( i ) / ( workClasses_getworkers ( i ) + 1 );
			retval = i;
		}
	}
	MWprintf ( 10, "Setting the workerGroup to be %d\n", retval );
	w->addGroup ( retval );
	return retval;
}


void Driver_Matmul::printresults() 
{
	MWprintf ( 10, "The resulting Matrix is as follows\n");
/*
	for ( int i = 0; i < num_rows; i++ )
	{
		for ( int j = 0; j < num_rows; j++ )
			MWprintf ( 10, "%d ", C[i][j] );

		MWprintf ( 10, "\n" );
	}
*/
	MWprintf ( 10, "Bytes Packed %lf\n", RMCOMM_bytes_packed );
	MWprintf ( 10, "Bytes Unpacked %lf\n", RMCOMM_bytes_unpacked );

}

void
Driver_Matmul::write_master_state( FILE *fp ) 
{
	// This is not checkpoint enabled.
}

void 
Driver_Matmul::read_master_state( FILE *fp ) 
{
	// This is not checkpoint enabled.
}

MWTask*
Driver_Matmul::gimme_a_task() 
{
	/* The MWDriver needs this.  Just return a Task_Matmul instance. */
	return new Task_Matmul;
}

MWDriver*
gimme_the_master () 
{
    return new Driver_Matmul;
}
