/***************************Copyright-DO-NOT-REMOVE-THIS-LINE**
  *
  * Condor Software Copyright Notice
  * Copyright (C) 1990-2004, Condor Team, Computer Sciences Department,
  * University of Wisconsin-Madison, WI.
  *
  * This source code is covered by the Condor Public License, which can
  * be found in the accompanying LICENSE.TXT file, or online at
  * www.condorproject.org.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  * AND THE UNIVERSITY OF WISCONSIN-MADISON "AS IS" AND ANY EXPRESS OR
  * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  * WARRANTIES OF MERCHANTABILITY, OF SATISFACTORY QUALITY, AND FITNESS
  * FOR A PARTICULAR PURPOSE OR USE ARE DISCLAIMED. THE COPYRIGHT
  * HOLDERS AND CONTRIBUTORS AND THE UNIVERSITY OF WISCONSIN-MADISON
  * MAKE NO MAKE NO REPRESENTATION THAT THE SOFTWARE, MODIFICATIONS,
  * ENHANCEMENTS OR DERIVATIVE WORKS THEREOF, WILL NOT INFRINGE ANY
  * PATENT, COPYRIGHT, TRADEMARK, TRADE SECRET OR OTHER PROPRIETARY
  * RIGHT.
  *
  ****************************Copyright-DO-NOT-REMOVE-THIS-LINE**/
/* Worker-Matmul.C */

#include "Worker-NewMatmul.h"
#include "Task-NewMatmul.h"

int **matrixA, **matrixB;

extern void Scanf ( int*, int, int);

Worker_Matmul::Worker_Matmul() 
{
	workingTask = new Task_Matmul;
	B = NULL;
	partition_factor = 0;
}

Worker_Matmul::~Worker_Matmul() 
{
	delete workingTask;
	if ( B )
	{
		for ( int i = 0; i < partition_factor; i++ )
			delete [] B[i];
		delete [] B;
	}
	B = NULL;
}

MWReturn Worker_Matmul::unpack_init_data( void ) 
{
	int i;

	RMC->unpack ( &partition_factor, 1, 1 );

	if ( B )
	{
		for ( i = 0; i < partition_factor; i++ )
			delete [] B[i];
		delete [] B;
	}

	B = new int*[partition_factor];
	for ( i = 0; i < partition_factor; i++ )
	{
		B[i] = new int[partition_factor];
		for ( int j = 0; j < partition_factor; j++ )
			RMC->unpack ( &B[i][j], 1, 1 );
	}

	return OK;
}

void Worker_Matmul::execute_task( MWTask *t ) 
{
	int i, j, k;

	Task_Matmul *tf = (Task_Matmul *) t;

	for ( i = 0; i < partition_factor; i++ )
	{
		for ( j = 0; j < partition_factor; j++ )
		{
			for ( k = 0; k < partition_factor; k++ )
			{
				tf->results[i][k] += tf->A[i][j] * B[j][k];
			}
		}
	}
}

MWTask* Worker_Matmul::gimme_a_task ( )
{
	return new Task_Matmul;
}

MWWorker*
gimme_a_worker ()
{
    return new Worker_Matmul;
}
