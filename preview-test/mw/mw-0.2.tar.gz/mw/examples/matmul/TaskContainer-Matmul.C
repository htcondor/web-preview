/* TaskContainer-Matmul.C */

#include "TaskContainer-Matmul.h"
#include "MW.h"

//#include "MWRMComm.h"
#include <string.h>

TaskContainer_Matmul::TaskContainer_Matmul() 
{
	//startRow = endRow = -1;
}

TaskContainer_Matmul::~TaskContainer_Matmul() 
{
  //delete [] answers;
}
/*
void
TaskContainer_Matmul::printself( int level ) 
{
	// Right now nothing
}
*/

void 
TaskContainer_Matmul::pack_work( void ) 
{
/*
    int numtasks = tasks->Number();

    RMC->pack(&numtasks, 1, 1);
    MWTask * t = tasks->First();
    while ( tasks->AfterEnd() == false ) {
        t = tasks->Current();
		int num = t->number;
		RMC->pack(&num,1,1);
//MWprintf(51, "Task container pack work %d\n",num);
        t->pack_work();
        tasks->Next();
    }
*/
}


void 
TaskContainer_Matmul::unpack_work( void ) 
{
/*
    int numtasks;

    RMC->unpack(&numtasks, 1, 1);
    for(int i = 0; i < numtasks; i++)
    {
		int num;
        Task_Matmul *t = new Task_Matmul;
		RMC->unpack(&num,1,1);
//MWprintf(51,"Task container unpack work %d\n",num);
		t->number = num;
        t->unpack_work();
        tasks->Append(t);
    }
*/
}

void
TaskContainer_Matmul::pack_results()
{
/*
    MWTask * t = tasks->First();
    while ( tasks->AfterEnd() == false ) {
        t = tasks->Current();
		int num = t->number;
		RMC->pack(&num,1,1);
        t->pack_results();
        tasks->Next();
    }
*/
}

void
TaskContainer_Matmul::unpack_results()
{
/*
	MWprintf(51,"Task container unpacking results\n");
    MWTask * t = tasks->First();
	int num;
    while ( tasks->AfterEnd() == false ) {
        t = tasks->Current();
		RMC->unpack(&num,1,1);
		t->number = num;
        t->unpack_results();
        tasks->Next();
    }
*/
}

void
TaskContainer_Matmul::pack_subresults(int tasknum)
{
	// do nothing, just let Worker layer tell Master a task was completed
}

void
TaskContainer_Matmul::unpack_subresults(int tasknum)
{
	// do nothing
}










