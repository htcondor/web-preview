// $Id: KnapInstance.h,v 1.4 2005/05/26 20:02:40 wasu Exp $
#ifndef KNAP_INSTANCE_H
#define KNAP_INSTANCE_H

#include <iostream>
#include <vector>

#include "KnapItem.h"

class MWRMComm;

class KnapInstance
{

public:

  typedef std::vector<KnapItem>::const_iterator itemIterator;  

  KnapInstance();
  virtual ~KnapInstance();

  friend std::istream &operator>>(std::istream &stream, KnapInstance &instance);
  friend std::ostream &operator<<(std::ostream &stream, KnapInstance &instance);

  double getCapacity() const { return capacity_; }
  const KnapItem &getItem(int ix) const { return items_[ix]; }
  int getNumItems() const { return items_.size(); }

  bool isIntegerObj() const { return integerObj_; }

  itemIterator itemsBegin() const { return items_.begin(); }
  itemIterator itemsEnd() const { return items_.end(); }

  int MWPack(MWRMComm *r) const;
  int MWUnpack(MWRMComm *r);

  void orderItems();


private:

  std::vector<KnapItem> items_;
  double capacity_;
  bool integerObj_;

};

std::istream &operator>>(std::istream &stream, KnapInstance &instance);
std::ostream &operator<<(std::ostream &stream, KnapInstance &instance);

#endif
// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:

