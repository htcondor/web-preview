// $Id: KnapParam.h,v 1.1 2005/03/01 17:22:17 linderot Exp $

#ifndef KNAP_PARAM_H
#define KNAP_PARAM_H

/** Bound must be at least "this much" better than the current lower bound
    to be considered for evaluation
*/
static const double KnapBetterBy = 1.0e-8; 

/** Number less than this are considered to be <= 0
*/
static const double KnapZeroTolerance = 1.0e-6;

#endif
// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:

