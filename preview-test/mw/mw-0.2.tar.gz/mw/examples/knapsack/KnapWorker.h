/*
 */

// $Id: KnapWorker.h,v 1.3 2005/02/24 11:24:38 linderot Exp $

#ifndef KNAP_WORKER_H
#define KNAP_WORKER_H

#include <MWWorker.h>

#include "KnapInstance.h"

class MWTask;

class KnapWorker : public MWWorker
{

public:

  KnapWorker();
  ~KnapWorker();
      
  void execute_task(MWTask *);	 

  MWReturn unpack_init_data();	 

private:

  KnapInstance instance_;

};

#endif
// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:
