// $Id: KnapTask.h,v 1.4 2005/02/25 02:06:21 linderot Exp $
#ifndef KNAP_TASK_H
#define KNAP_TASK_H

#include <cfloat>
#include <vector>

#include <MWTask.h>

#include "KnapNode.h"
#include "NodeHeap.h"


class KnapTask : public MWTask 
{

public:

  KnapTask(): maxNodes_(INT_MAX), maxTime_(DBL_MAX) {}
  KnapTask(const KnapNode node, int maxNodes, double maxTime): 
    inputNode_(node), maxNodes_(maxNodes), maxTime_(maxTime) {}

  virtual ~KnapTask();

  void addNodesInHeap(NodeHeap &heap) { outputNode_ = heap.nodes_; }
  bool foundImprovedSolution() const { return foundImprovedSolution_; }
  const KnapNode & getInputNode() const { return inputNode_; }
  int getMaxNodes() const { return maxNodes_; }
  double getMaxTime() const { return maxTime_; }
  double getSolutionValue() const { return solutionValue_; }

  std::vector<KnapNode *>::const_iterator constNewNodeBegin() const { return outputNode_.begin(); }
  std::vector<KnapNode *>::const_iterator constNewNodeEnd() const { return outputNode_.end(); }
    
  /// Pack the results from this task into the RMComm buffer
  void pack_results( void );

  /// Pack the work for this task into the RMComm buffer
  void pack_work( void );

  /// Prints himself
  void printself(int level);

  void setBetterSolution(double value);
  void setNumNodesEvaluated(int nn) { numNodesEvaluated_ = nn; }

  /// Unpack the results from this task into the RMComm buffer
  void unpack_results( void );

  /// Unpack the work for this task from the RMComm buffer
  void unpack_work( void );

private:

  // Input stuff
  KnapNode inputNode_;
  
  // Output stuff
  bool foundImprovedSolution_;

  int numNodesEvaluated_;
  std::vector<KnapNode *> outputNode_;

  // Control stuff -- All this should be in "worker" task data
  double solutionValue_;
  int maxNodes_;
  double maxTime_;


};

#endif

// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:
