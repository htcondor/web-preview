// $Id: KnapItem.h,v 1.2 2005/02/24 11:22:46 linderot Exp $ 

#ifndef KNAP_ITEM_H
#define KNAP_ITEM_H

#include <iostream>

class KnapItem
{

public:

  friend std::ostream &operator<<(std::ostream &stream, const KnapItem &item);


  KnapItem(int id, double size, double profit) : id_(id), size_(size), profit_(profit) {}
  virtual ~KnapItem() {}

  int getId() const { return id_; }
  double getSize() const { return size_; }
  double getProfit() const { return profit_; }

private:

  int id_;
  double size_;
  double profit_;

};

std::ostream &operator<<(std::ostream &stream, const KnapItem &item);

#endif

// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:

