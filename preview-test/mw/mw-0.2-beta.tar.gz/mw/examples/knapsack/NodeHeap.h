// $Id: NodeHeap.h,v 1.2 2005/02/25 02:06:21 linderot Exp $

#ifndef NODEHEAP_H
#define NODEHEAP_H

class KnapNode;
class KnapTask;

class NodeHeap {

public:
  enum Type { VALUE, DEPTH };

public:

  friend class KnapTask;  // so i can just "steal" the pointers to the nodes

  NodeHeap(Type type = VALUE) : type_(type) {}
  virtual ~NodeHeap() {}
  
  bool empty() const { return nodes_.empty(); }
  double getBestBound() const;
  int getDeepestLevel() const;
  void pop();
  void print(std::ostream &o) const;
  void push(KnapNode *n);
  void setType(Type type);
  KnapNode *top() const { return (nodes_.front()); }
  unsigned int size() const { return (nodes_.size()); }
  
private:
  std::vector<KnapNode *> nodes_;
  Type type_;
  
};
#endif

// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:
