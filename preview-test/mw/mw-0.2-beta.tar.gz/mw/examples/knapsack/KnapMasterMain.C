/*
 */
// $Id: KnapMasterMain.C,v 1.1 2005/02/15 12:52:17 linderot Exp $

#include "KnapMaster.h"

int 
main(int argc, char *argv[]) 
{

  KnapMaster *km = new KnapMaster();
  km->go( argc, argv );
  delete km;
  return 0;
}

// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:
