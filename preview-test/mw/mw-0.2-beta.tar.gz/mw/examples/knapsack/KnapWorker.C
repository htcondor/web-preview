// $Id: KnapWorker.C,v 1.5 2005/02/25 02:06:21 linderot Exp $

#include <cassert>

#include <MWSystem.h>

#include "KnapNode.h"
#include "KnapTask.h"
#include "KnapParam.h"
#include "KnapWorker.h"
#include "NodeHeap.h"

using namespace std;

//#define DEBUG


MWWorker *
gimme_a_worker()
{
   return new KnapWorker;
}

KnapWorker::KnapWorker()
{
  workingTask = new KnapTask();
}

KnapWorker::~KnapWorker()
{
}

void
KnapWorker::execute_task(MWTask *t)
{
  KnapTask *kt = dynamic_cast<KnapTask *> (t);
  assert(kt);

  kt->printself(1);

  double begTime = MWSystem::gettimeofday();
  double curTime = begTime;
  int numNodes = 0;

  NodeHeap *heap = new NodeHeap();
  heap->push(new KnapNode(kt->getInputNode()));
    
  while(!heap->empty() && (curTime - begTime < kt->getMaxTime()) && 
        (numNodes < kt->getMaxNodes()) ) {

    KnapNode *node = heap->top();
    heap->pop();

    // Cram as many free items as possible into the knapsack.
    //  (The items have already been sorted)
    // ix is the last item you were able to fit

#if defined(DEBUG)
    cout << "Evaluating node: " << (*node) << endl;
#endif

    double remainingSize = instance_.getCapacity() - node->getUsedCapacity();
    double usedValue = node->getUsedValue();

    int ix = 0;
    double ixSize = 0.0;
    double ixProfit = 0.0;
    for (KnapInstance::itemIterator it = instance_.itemsBegin(); 
         it != instance_.itemsEnd(); ++it) {
      if (node->varStatus(ix) == Free) {
        ixSize = (*it).getSize();
        ixProfit = (*it).getProfit();      
        remainingSize -= ixSize;
        usedValue += ixProfit;
#if defined(DEBUG)
        cout << "Putting in item: " << (*it) << endl;
        cout << "Remaining Size: " << remainingSize 
             << " usedValue: " << usedValue << endl;
#endif

      }
      if (remainingSize < KnapZeroTolerance) break;
      ix++;
    }

    // Now check to see if feasible, compute bound, and else take it out
    //  if not feasible

    bool branch = false;
    double nodeUb = DBL_MAX;
    double nodeLb = -DBL_MAX;
    if (remainingSize < -KnapZeroTolerance) {
      usedValue -= ixProfit;
      remainingSize += ixSize;
      nodeUb = usedValue + ixProfit/ixSize * remainingSize;
      nodeLb = usedValue;
      node->setUpperBound(nodeUb);
      if (nodeUb > kt->getSolutionValue() + KnapBetterBy) {
        branch = true;
      }
    }
    else {
      // Solution is feasible.
      nodeLb = usedValue;
      nodeUb = usedValue;
    }

    cout << "LB: " << nodeLb << " UB: " << nodeUb << endl;
    
    if (nodeLb > kt->getSolutionValue()) {
      // Right now we only care about the solution value?
      kt->setBetterSolution(nodeLb);
#if defined(DEBUG)
      cout << "Found better solution of value: " << nodeLb << endl;
      cout << "Before fathoming heap has: " << heap->size() 
           << " nodes." << endl; 
#endif

      // Fathom -- have to do it by hand, since container contains pointers,
      //  (can't use the STL algorithms)
      NodeHeap *newHeap = new NodeHeap();
      while(!heap->empty()) {
        KnapNode *n = heap->top();
        heap->pop();
        if (n->getUpperBound() <= nodeLb) {
          delete n;
        }
        else {
          newHeap->push(n);
        }
      }

      delete heap;
      heap = newHeap;
#if defined(DEBUG)
      cout << "After fathoming heap has: " << heap->size() 
           << " nodes." << endl; 
#endif

    }

    // Branch on ix.
    if (branch) {
#if defined(DEBUG)
      cout << "Branching on: " << ix << endl;
#endif
      heap->push(new KnapNode(*node, ix, FixedToZero, ixSize, ixProfit));
      heap->push(new KnapNode(*node, ix, FixedToOne, ixSize, ixProfit));
    }

    delete node;
    numNodes++;
    curTime = MWSystem::gettimeofday();
  }

  // At this point you are done.  Return the nodes left on the heap.
  kt->setNumNodesEvaluated(numNodes);
  kt->addNodesInHeap(*heap);
  
  return;

}

MWReturn
KnapWorker::unpack_init_data()
{
  MWReturn ustat = OK;
  instance_.MWUnpack(RMC);

#if defined(DEBUG)
  cout << "Unpacked Instance: " << endl << instance_ << endl;
#endif

  return(ustat);
}


// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:

