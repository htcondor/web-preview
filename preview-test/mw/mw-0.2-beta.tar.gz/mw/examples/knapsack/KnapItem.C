// $Id: KnapItem.C,v 1.1 2005/02/24 11:22:46 linderot Exp $

#include "KnapItem.h"

std::ostream &
operator<<(std::ostream &o, const KnapItem &item)
{
  o << "Id: " << item.id_ << " Size: " << item.size_ 
    << " Profit: " << item.profit_;
  return o;
}

// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:

