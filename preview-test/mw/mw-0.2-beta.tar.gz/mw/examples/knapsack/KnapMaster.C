// $Id: KnapMaster.C,v 1.3 2005/02/25 02:06:21 linderot Exp $

#include <cassert>
#include <cfloat>
#include <iostream>
#include <fstream>

#include "KnapMaster.h"
#include "KnapTask.h"

using namespace std;

MWKey best_bound(MWTask *t)
{
  KnapTask *kt = dynamic_cast<KnapTask *> (t);
  assert(kt);
  return ((MWKey) -(kt->getInputNode().getUpperBound()));
}



KnapMaster::KnapMaster()
{
  bestLowerBound_ = -DBL_MAX;
}

KnapMaster::~KnapMaster()
{
}

MWReturn 
KnapMaster::act_on_completed_task(MWTask *t)
{
  MWReturn ustat = OK;
  KnapTask *kt = dynamic_cast<KnapTask *> (t);
  assert(kt);

  // Fathom nodes of the branch and bound tree if possible
  if (kt->foundImprovedSolution()) {
    double blb = kt->getSolutionValue();
    if (blb > bestLowerBound_) {
      MWprintf(10, "Improved Solution Found.  Fathoming all nodes with UB < %f\n", blb);
      bestLowerBound_ = blb;

      //XXX Should put the better_by tolerance here...
      delete_tasks_worse_than(bestLowerBound_);
    }
  }
  
  // Add new nodes/tasks
  for (vector<KnapNode *>::const_iterator it = kt->constNewNodeBegin(); 
       it != kt->constNewNodeEnd(); ++it) {
    addTask(new KnapTask(**it, 10, 10.0));
    delete *it;
  }


  //XXX Check for max time and max nodes and stuff
  MWprintf(10, "Tasks in Master Queue: %d\n", get_number_tasks());

  return(ustat);
}

MWReturn 
KnapMaster::get_userinfo(int argc, char *argv[])
{
  MWReturn ustat = OK;
  if (argc != 2) {
    cerr << "Usage: knap <datafile>" << endl;
    return(ABORT);
  }  
  
  // Read in your knapsack data file
  ifstream data_file(argv[1]);
  if (!data_file) {
    cerr << "Error opening input data file: " << argv[1] 
         << "Aborting" << endl;
    return ABORT;
  }

  try {
    data_file >> instance_;
  }
  catch (...) {
    cerr << "Error in data file: " << argv[1] << "Aborting" << endl;
    return ABORT;
  }
  instance_.orderItems();

  cout << instance_;

  // Set up necessary MW stuff to describe executables.  
  //   (This is horribly kludgy at present).
  RMC->set_num_exec_classes(1);
  RMC->set_num_arch_classes(1);
  RMC->set_arch_class_attributes(0, "\"Arch == INTEL\" && Opsys == \"Linux\"");
  RMC->set_num_executables(1);
  RMC->add_executable(0, 0, "knap-worker", "");

  // Set up handling of the task list...
  set_task_key_function(&best_bound);
  set_task_add_mode(ADD_BY_KEY);
  set_task_retrieve_mode(GET_FROM_BEGIN);

  return(ustat);
}

MWReturn
KnapMaster::pack_worker_init_data()
{
   MWReturn ustat = OK;
   instance_.MWPack(RMC);
   return(ustat);
}

MWTask *
KnapMaster::gimme_a_task()
{
   return (new KnapTask());
}

void 
KnapMaster::printresults()
{
  MWprintf(1, "BEST SOLUTION VALUE: %f\n", bestLowerBound_);
}

void 
KnapMaster::read_master_state(FILE *fp)
{
  return;
}

MWReturn 
KnapMaster::setup_initial_tasks(int *n_init, MWTask ***init_tasks)
{
  MWReturn ustat = OK;

  *n_init = 1;   
  *init_tasks = new MWTask * [*n_init];

#if defined(INDEPENDENT)
  (*init_tasks)[0] = new KnapTask(KnapNode(instance_.getNumItems()), 10, 10.0);
#else
  assert(0);
#endif
   return(ustat);

}

// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:

