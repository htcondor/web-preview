/*
 */

// $Id: KnapMaster.h,v 1.2 2005/02/18 21:05:15 linderot Exp $
#ifndef KNAP_MASTER_H
#define KNAP_MASTER_H

#include <MWDriver.h>

#include "KnapInstance.h"

class KnapMaster : public MWDriver
{
public:

  KnapMaster();
  virtual ~KnapMaster();

  ///
  MWReturn act_on_completed_task(MWTask *);

  ///
  MWReturn get_userinfo(int argc, char *argv[]);
  
  ///
  MWTask *gimme_a_task();

  ///
  MWReturn pack_worker_init_data();
  
  void printresults();
  
  ///
  void read_master_state(FILE *fp);

  ///
  MWReturn setup_initial_tasks(int *, MWTask ***);


private:

  KnapInstance instance_;
  double bestLowerBound_;

};

#endif
// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:
