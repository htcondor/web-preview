// $Id: KnapNode.h,v 1.3 2005/02/24 11:24:38 linderot Exp $

#ifndef KNAP_NODE_H
#define KNAP_NODE_H

#include <iostream>
#include <vector>

class MWRMComm;


enum KnapVarStatus {
  Free,
  FixedToOne,
  FixedToZero,
};

class KnapNode
{

public:

  friend std::ostream &operator<<(std::ostream &stream, KnapNode &node);

  KnapNode();
  KnapNode(int n);
  KnapNode(const KnapNode &rhs);
  KnapNode(const KnapNode &rhs, int ix, KnapVarStatus fv, 
           double ixSize, double ixProfit);

  virtual ~KnapNode() {}
  //KnapNode & operator=(const KnapNode &);

  int getDepth() const { return depth_; }
  double getUpperBound() const { return ub_; }
  double getUsedCapacity() const { return usedCapacity_; }
  double getUsedValue() const { return usedValue_; }

  int MWPack(MWRMComm *r);
  int MWUnpack(MWRMComm *r);

  void setUpperBound(double val) { ub_ = val; }

  KnapVarStatus varStatus(int ix) const { return itemStatus_[ix]; }

private:
  int depth_;
  double ub_;
  double usedCapacity_;
  double usedValue_;
  std::vector<KnapVarStatus> itemStatus_;

};

std::ostream &operator<<(std::ostream &stream, KnapNode &instance);

#endif
// Local Variables:
// mode: c++
// eval: (c-set-style "gnu")
// eval: (setq indent-tabs-mode nil)
// End:

