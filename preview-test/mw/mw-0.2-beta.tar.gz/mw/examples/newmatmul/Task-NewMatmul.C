/***************************Copyright-DO-NOT-REMOVE-THIS-LINE**
  *
  * Condor Software Copyright Notice
  * Copyright (C) 1990-2004, Condor Team, Computer Sciences Department,
  * University of Wisconsin-Madison, WI.
  *
  * This source code is covered by the Condor Public License, which can
  * be found in the accompanying LICENSE.TXT file, or online at
  * www.condorproject.org.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  * AND THE UNIVERSITY OF WISCONSIN-MADISON "AS IS" AND ANY EXPRESS OR
  * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  * WARRANTIES OF MERCHANTABILITY, OF SATISFACTORY QUALITY, AND FITNESS
  * FOR A PARTICULAR PURPOSE OR USE ARE DISCLAIMED. THE COPYRIGHT
  * HOLDERS AND CONTRIBUTORS AND THE UNIVERSITY OF WISCONSIN-MADISON
  * MAKE NO MAKE NO REPRESENTATION THAT THE SOFTWARE, MODIFICATIONS,
  * ENHANCEMENTS OR DERIVATIVE WORKS THEREOF, WILL NOT INFRINGE ANY
  * PATENT, COPYRIGHT, TRADEMARK, TRADE SECRET OR OTHER PROPRIETARY
  * RIGHT.
  *
  ****************************Copyright-DO-NOT-REMOVE-THIS-LINE**/
/* Task-NewMatmul.C */

#include "Task-NewMatmul.h"
#include "MW.h"

#include "MWRMComm.h"
#include <string.h>

extern int **matrixA, **matrixB;

void 
Task_Matmul::Scanf ( int *m, int i, int j )
{
	        *m = j;
}

Task_Matmul::Task_Matmul() 
{
	startRowA = startColA = -1;
	resultStartR = resultStartC = -1;
	partition_factor = 0;
	results = NULL;
}

Task_Matmul::Task_Matmul( int i, int j, int k, int num_rows, int prtn_factor )
{
	startRowA = i * prtn_factor;
	startColA = j * prtn_factor;
	partition_factor = prtn_factor;
	resultStartR = i * prtn_factor;
	resultStartC = k * prtn_factor;
	A = results = NULL;
	grp = i * num_rows / prtn_factor + k;
}

Task_Matmul::~Task_Matmul() 
{
    if ( results )
	{
		for ( int i = 0; i < partition_factor; i++ )
			delete [] results[i];
		delete [] results;
	}
	results = NULL;
}

void
Task_Matmul::printself( int level ) 
{
	// Right now nothing
}


void Task_Matmul::pack_work( void ) 
{
	int i, j;
	int packedint;
	RMC->pack( &partition_factor, 1, 1 );

	for ( i = startRowA; i < startRowA + partition_factor; i++ )
	{
		for ( j = startColA; j < startColA + partition_factor; j++ )
		{
			Scanf ( &packedint, i, j );
			RMC->pack ( &packedint, 1, 1 );
		}
	}
}


void Task_Matmul::unpack_work( void ) 
{
	int i, j;

	RMC->unpack( &partition_factor, 1, 1 );

	A = new int*[partition_factor];
	results = new int*[partition_factor];
	for ( i = 0; i < partition_factor; i++ )
	{
		A[i] = new int[partition_factor];
		results[i] = new int[partition_factor];
		for ( j = 0; j < partition_factor; j++ )
		{
			RMC->unpack ( &A[i][j], 1, 1 );
			results[i][j] = 0;
		}
	}
}


void Task_Matmul::pack_results( void ) 
{
	int i;
	for ( i = 0; i < partition_factor; i++ )
		RMC->pack( results[i], partition_factor, 1 );


	for ( i = 0; i < partition_factor; i++ )
	{
		delete [] A[i];
		delete [] results[i];
	}
	delete [] results;
	delete [] A;
	results = A = NULL;

}


void Task_Matmul::unpack_results( void ) 
{
	results = new int*[partition_factor];
	for ( int i = 0; i < partition_factor; i++ )
	{
		results[i] = new int[partition_factor];
    	RMC->unpack( results[i], partition_factor, 1 );
	}
}

void Task_Matmul::write_ckpt_info( FILE *fp ) 
{
	// Not checkpoint enabled.
}

void Task_Matmul::read_ckpt_info( FILE *fp ) 
{
	// Not checkpoint enabled.
}
