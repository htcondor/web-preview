#ifndef TASKCONTAINER_MATMUL_H
#define TASKCONTAINER_MATMUL_H

#include <stdio.h>
#include "Task-Matmul.h"
#include "MWTaskContainer.h"
//#include "MWRMComm.h"

class TaskContainer_Matmul : public MWTaskContainer {

 public:
    TaskContainer_Matmul();
    ~TaskContainer_Matmul();

	// these are for all tasks in the container
	void pack_work();
	void unpack_work();
	void pack_results();

	// act_on_completed_task(MWTaskContainer*) is called after this
	void unpack_results();

	// these are for only one task in the container
	// after execute_task completes, pack_subresults is called
	void pack_subresults(int tasknum);

	// act_on_completed_task(MWTask*) is called after this
	void unpack_subresults(int tasknum);
};

#endif











