
#ifndef MWFILERCSYMBOL_H
#define MWFILERCSYMBOL_H

// This file lists all the symbols that have been used in the wait files.

#define OK '$'

#define WRONGINITFILE '@'

#define SYNC '^'

#define ESYNC '!'

#endif MWFILERCSYMBOL_H
