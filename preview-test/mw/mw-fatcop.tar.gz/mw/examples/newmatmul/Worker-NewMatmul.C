/* Worker-Matmul.C */

#include "Worker-NewMatmul.h"
#include "Task-NewMatmul.h"

int **matrixA, **matrixB;

extern void Scanf ( int*, int, int);

Worker_Matmul::Worker_Matmul() 
{
	// do this here so that workingtask has type Task_Fib, and not
	// MWTask type.  This class holds info for the task at hand...
	workingTask = new Task_Matmul;
	B = NULL;
	partition_factor = 0;
}

Worker_Matmul::~Worker_Matmul() 
{
	delete workingTask;
	if ( B )
	{
		for ( int i = 0; i < partition_factor; i++ )
			delete [] B[i];
		delete [] B;
	}
	B = NULL;
}

MWReturn Worker_Matmul::unpack_init_data( void ) 
{
	int i;

	RMC->unpack ( &partition_factor, 1, 1 );

	if ( B )
	{
		for ( i = 0; i < partition_factor; i++ )
			delete [] B[i];
		delete [] B;
	}

	B = new int*[partition_factor];
	for ( i = 0; i < partition_factor; i++ )
	{
		B[i] = new int[partition_factor];
		for ( int j = 0; j < partition_factor; j++ )
			RMC->unpack ( &B[i][j], 1, 1 );
	}

	return OK;
}

void Worker_Matmul::execute_task( MWTask *t ) 
{
	int i, j, k;

	Task_Matmul *tf = (Task_Matmul *) t;

	for ( i = 0; i < partition_factor; i++ )
	{
		for ( j = 0; j < partition_factor; j++ )
		{
			for ( k = 0; k < partition_factor; k++ )
			{
				tf->results[i][k] += tf->A[i][j] * B[j][k];
			}
		}
	}
}

MWWorker*
gimme_a_worker ()
{
    return new Worker_Matmul;
}
