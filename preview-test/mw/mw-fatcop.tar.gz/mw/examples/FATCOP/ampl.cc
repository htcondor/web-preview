#if defined( AMPL_INTERFACE )

#include <errno.h>

#include "global.hh"
#include "PRINO.hh"
#include "FATCOP_driver.hh"
#include "FATCOP_task.hh"
#include "cutpool.hh"
#include "pseudocost.hh"

#include "getstub.h"

//#define DEBUG_AMPL
#define print(x,n) {for( int i = 0; i < n; i++) cout<<x[i]<<" "; cout<<endl;}

#define Int(n) (int *)Malloc((n)*sizeof(int))
#define Double(n) (double *)Malloc((n)*sizeof(double))
#define CChar(n) (char *)Malloc((n)*sizeof(char))

extern MWKey dfp(MWTask* t);
extern MWKey bb(MWTask* t);
extern MWKey pc(MWTask* t);
extern MWKey deepest_first(MWTask* t);


//global varaibles
ASL *asl;
static char *optfile = 0;
static double objadj = 0;


typedef struct { char *msg; int code; int wantobj; } Sol_info;

static Sol_info solinfo[] = {
  { "optimal integer solution", 000, 1 },             /* 0 */
  { "infeasible problem", 200, 0 },			/* 1 */
  { "unbounded problem", 300, 0 },                    /* 2 */
  { "optimal integer solution within mipgap or absmipgap", 003, 1 }, /* 3 */
  { "integer infeasible", 220, 0 },			/* 4 */
  { "resource limit with integer solution", 421, 1 },	/* 5 */
  { "resource limit with no integer solution", 410, 0 },/* 6 */
  { "unrecoverable failure", 501, 0 },                /* 7 */
  { "aborted", 521, 1 },                              /* 8 */
  { "out of memory", 512, 1 },           /* 9 */
};
  

static char *
Handle_Optfile(Option_Info *oi, keyword *kw, char *value)
{
  char *rv = C_val(oi, kw, value);
  return rv;
}


//we only provide one option optfile at this momement, 
//shall add more options later
static keyword keywds[] = {
  KW("optfile", Handle_Optfile, &optfile, "name of option file")
};


static char FATCOP_version[] = "FATCOP 2.0";

static Option_Info Oinfo = { "FATCOP", FATCOP_version, "FATCOP_options",
			     keywds, nkeywds };


extern void colmajor_to_rowmajor( int ncols,
				  const int colbeg[], const int colind[],
				  const double colval[],
				  int nrows, int rowbeg[], int rowind[],
				  double rowval[],
				  int rowcnt[], int nvals );
extern void rowmajor_to_colmajor( int nrows,
				  const int rowbeg[],
				  const int rowind[], const double rowval[],
				  int ncols, int colbeg[], int colind[],
				  double colval[], int colcnt[],
				  int nvals );


int handle_range_rows( int& m, int& n, int& nz,
		       int*& matbeg, int*& matind, 
		       int*& matcnt, double*& matval,
		       double*& rhs, char*& senx )
{
  
#ifdef DEBUG_AMPL
  printf( "original column major matrix is:\n" );
  print( matbeg, n+1 );
  print (matind, nz );
  print (matcnt, n);
  print (matval, nz);
#endif
  
  int i;
  
  /* identify range rows */
  int* rangerowidx = Int( nranges );
  int hand = 0; 
  double lr = 0, ur = 0;
  
  for( i = 0; i < m; i++ ){
    lr = LUrhs[i];
    ur = Urhsx[i];
    if( lr < ur && lr > negInfinity && ur < Infinity ){
      rangerowidx[hand++] = i;
    }
  }
  
  if( hand != nranges ){
    MWprintf( 10, " AMPL Interface: sth wrong! %d %d\n", hand, nranges );
    return 1;
  }
  
#ifdef DEBUG_AMPL
  /* print range rows */
  printf("range rows are: \n");
  print( rangerowidx, nranges );
#endif
  
  
  /****************************************** 
  split range rows to two constraints (rows) 
  ********************************************/
  /* convert to row major */
  int* rowbeg = Int( m + 1 ) ;
  int* rowind = Int( nz );
  double* rowval = Double( nz );
  int* rowcnt = Int( m );
  
  colmajor_to_rowmajor( n, matbeg, matind, matval,
			m, rowbeg, rowind, rowval, rowcnt,
			nz );
  
#ifdef DEBUG_AMPL
  printf( "original row major matrix is:\n" );
  print( rowbeg, m );
  print( rowind, nz );
  print( rowcnt, m );
  print( rowval, nz );
#endif
  
  /* count number of new nonzeros */
  int enz = 0;
  
  for( i = 0; i < nranges; i++ ) {
    enz += rowcnt[ rangerowidx[i] ];
  }
  
  nz += enz;
  m += nranges;
  
  rhs = Double( m );
  senx = CChar( m );
  
  
  /* add new rows */
  int* nrowbeg = Int( m + 1 ) ;
  int* nrowind = Int( nz );
  double* nrowval = Double( nz );
  int* nrowcnt = Int( m );
  
  
  int start = 0, nstart = 0;
  int hand1, hand2;

  for( i = 0; i < nranges; i++ ){
    
    hand1 = rowbeg[ rangerowidx[i] ];
    hand2 = hand1 + rowcnt[ rangerowidx[i] ];

    /* copy from start to hand2 */
    memcpy( nrowind+nstart, rowind+start, sizeof(int)*(hand2-start) );
    memcpy( nrowval+nstart, rowval+start, sizeof(double)*(hand2-start) );
    start = hand1;
    nstart += hand2-start;
    
    /* copy from hand1 to hand2 */
    memcpy( nrowind+nstart, rowind+start, sizeof(int)*(hand2-hand1) );
    memcpy( nrowval+nstart, rowval+start, sizeof(double)*(hand2-hand1) );
    
    start = hand2;
    nstart += hand2-hand1;
  }
  
  /* copy the rest */
  if( start < nzc ){
    memcpy( nrowind+nstart, rowind+start, sizeof(int)*(nz-start) );
    memcpy( nrowval+nstart, rowval+start, sizeof(double)*(nz-start) );  
  }
  
  start = 0;
  nstart = 0;
  
  for( i = 0; i < nranges; i++ ){
    
    while( start <= rangerowidx[i] ){
      nrowcnt[ nstart++ ] = rowcnt[ start++ ];
    }
    /* add one more copy */
    nrowcnt[ nstart++ ] = rowcnt[ start - 1 ];
  }
  
  
  /*copy the rest*/
  while( nstart < m ) {
    nrowcnt[ nstart++ ] = rowcnt[ start++ ];
  }
  
  nrowbeg[0] = 0;
  for( i = 1; i <= m; i++ ){
    nrowbeg[i] = nrowbeg[i-1] + nrowcnt[i-1];
  }
  
#ifdef DEBUG_AMPL
  /* print the final row major matrix */
  printf( "modified row major matrix is:\n" );
  printf("nrowval is: \n");
  print( nrowval, nz );
  printf("nrowbeg is: \n");
  print( nrowbeg, m );
  printf("nrowind is: \n");
  print( nrowind, nz );
  printf("nrowcnt is: \n");
  print( nrowcnt, m );
#endif
  
  
  /* now fill senx and rhs */   
  hand1 = 0;
  hand2 = 0;
  for( i = 0; i < m - nranges; i++ ){
    lr = LUrhs[i];
    ur = Urhsx[i];
    
    
    if( lr > negInfinity && ur >= Infinity ){
      senx[hand1++] = 'G';
      rhs[hand2++] = lr;
    }
    else if( lr <= negInfinity && ur  < Infinity ){
      senx[hand1++] = 'L';
      rhs[hand2++] = ur;
    }
    else if( lr > ur - tol && lr > negInfinity && ur < Infinity ){
      senx[hand1++] = 'E';
      rhs[hand2++] = lr;
    }
    else if ( lr < ur && lr > negInfinity && ur < Infinity ){ //range row
      senx[hand1++] = 'G';
      rhs[hand2++] = lr;
      senx[hand1++] = 'L';
      rhs[hand2++] = ur;
    }
    else{
      MWprintf( 10, "AMPL Interface: error with constraints.\n" );
      return 1;
    }
  }
  
  
  /* finally convert rowmajor to column major, watch out memory */
  free( matbeg ); matbeg = 0;
  free( matind ); matind = 0;
  free( matval ); matval = 0;
  
  matbeg = Int( n+1 );
  matind = Int( nz );
  matval = Double( nz );
  
  rowmajor_to_colmajor( m,
			nrowbeg, nrowind, nrowval,
			n, matbeg, matind, matval, matcnt,
			nz );
  
  free( rangerowidx ); rangerowidx = 0;

  free( rowbeg); rowbeg = 0;
  free( rowind); rowind = 0;
  free( rowcnt); rowcnt = 0;
  free( rowval); rowval = 0;
  
  free( nrowbeg); nrowbeg = 0;
  free( nrowind); nrowind = 0;
  free( nrowcnt); nrowcnt = 0;
  free( nrowval); nrowval = 0;
  

#ifdef DEBUG_AMPL
  /* print the final col major matrix */
  printf( "modified colum major matrix is:\n" );
  printf("matval is: \n");
  print( matval, nz );
  printf("matbeg is: \n");
  print( matbeg, n );
  printf("matind is: \n");
  print( matind, nz );
  printf("matcnt is: \n");
  print( matcnt, n );
#endif
  
  return 0;
}


void createFinishFile()
{
  
  cout<<"creating a finish log"<<endl;
  
  FILE *fp;
  char outfile_name[100];
  
  
  sprintf(outfile_name, 
	  "/tmp/finish.ampl");
  fp = fopen(outfile_name, "w"); 
  
  if (fp == NULL) cout<<"Can not open the file"<<endl;
  
  fprintf(fp, "finish!!!!!!\n ");
  
  fclose(fp);
  
  return;  
}
  

//FATCOP_driver method: read stub.nl
MWReturn FATCOP_driver::get_userinfo( int argc, char *argv[] )
{
  
#ifdef DEBUG_AMPL
  cout<<" $$$$ calling FATCOP_driver get_userinfo "<<endl;
#endif
  
  char wd[_POSIX_PATH_MAX];
  if ( getcwd( wd, 100 ) == NULL ) {
    MWprintf ( 10, "getcwd failed!  errno %d.\n", errno );
  }
  
  MWprintf ( 70, "Working directory is %s.\n", wd );
  
  char default_worker_name[128];
  sprintf( default_worker_name, "%s/fatcop-worker", wd );
  
  MWprintf ( 70, "default worker name is %s.\n", default_worker_name );
  
  RMC->set_worker_attributes( t_num_arches, default_worker_name, NULL );
  
  MWprintf( 10, "Setting worker executable %d to %s\n",
	    t_num_arches, default_worker_name );
  

  if (argc < 2) {
    MWprintf( 10, "AMPL Interface:  stub file cann't be found.\n" );
    return ABORT;
  }

  MWReturn status = OK;

  
  // Tell MW about the checkpoint frequency
  if( checkpointType == 1 )
    set_checkpoint_frequency( checkpointFrequency );
  if( checkpointType == 2 )
    set_checkpoint_time( checkpointFrequency );
  
  
  if (optfile) //option file has been specified
    readOption(optfile);
  else
    readOption("fatcop.opt");
  
  
  // Create the LP solver so that you can read the MPS file
  bool created = 0;
#if defined( CPLEXv6 )
  lpsolver = new CCPLEXInterface( cplexLicenseDir, created );
#endif
#if defined( SOPLEXv1 )
  if( ! created )
    {
      MWprintf( 10, "Unable to initialize CPLEX interface -- creating SOPLEX interface\n" );
      lpsolver = new CSOPLEXInterface;
    }
#endif
  
  if( NULL == lpsolver ){
    st = MEMORY_ERROR;
    return ABORT;
  }
  
  char *stub;
  FILE *nl;
  ograd *og;
 
  asl = ASL_alloc(ASL_read_f);
  stub = getstub(&argv, &Oinfo);
  nl = jac0dim(stub, (fint)strlen(stub));
  
  /* set A_vals to get the constraints column-wise */
  LUv = Double(n_var);
  Uvx = Double(n_var);
  LUrhs = Double(n_con);
  Urhsx = Double(n_con);
  A_vals = Double(nzc);
  
  f_read(nl,0);

  
  //need to assign values to the following variables
  // ***************************
  int objsen, n, m, nz;
  int* matbeg, *matind, *matcnt;
  double* matval;
  int* coltype;
  double* c, *lb, *ub;
  double* rhs;
  char* senx;
  // ***************************
  
  int i, nint, ncv;

  m = n_con;
  n = n_var;
  nz = nzc;
  nint = nbv + niv;
  ncv = n - nint;
  
  if( n_obj > 1 ){
    MWprintf( 10 ,"AMPL Interface: there are more than one objectives.\n
we only deal with the first objective.\n" );
  }
  
  
  //objective (assume we only deal with the first objective
  c = Double( n );
  for( i = 0; i < n; i++ ) c[i] = 0;
  
  for(og = Ograd[0]; og; og = og->next){
    c[og->varno] =  og->coef;
  }
  
  objadj = objconst( 0 ); 
  
  
  /* object type: 0 == min, 1 == max */
  /* FATCOP convention 1 == min, -1 == max */
  if( 0 == objtype[0] ){
    objsen = 1; 
  }
  else{
    objsen = -1; 
  }
  
  
  //variable bounds  
  lb = LUv; LUv = 0;
  ub = Uvx; Uvx = 0;
  
  
  //variable types
  //ampl varailbe ordering: continuous, binary, integer
  coltype = Int( n );
  for( i = 0; i < n; i++ ){
    if( i < ncv ){
      coltype[i] = COL_TYPE_CONTINUOUS;
    }
    else if( i >= ncv + nbv ){
      coltype[i] = COL_TYPE_INTEGER;
    }
    else{
      coltype[i] = COL_TYPE_BINARY;
    }
  }
  
  
  //constraint matrix, sign and bounds
  matbeg = A_colstarts; A_colstarts = 0;
  matind = A_rownos; A_rownos = 0;
  matcnt = Int( n );
  matval = A_vals; A_vals = 0;
  
  
  
  //if no range rows, we get easy work!    
  if( nranges <= 0 ){
    rhs = Double( m );
    senx = CChar( m );
    
    double lr = 0, ur = 0;
    for( i = 0; i < m; i++ ){
      lr = LUrhs[i];
      ur = Urhsx[i];
      if( lr > negInfinity && ur >= Infinity ){
	senx[i] = 'G';
	rhs[i] = lr;
      }
      else if( lr <= negInfinity && ur  < Infinity ){
	senx[i] = 'L';
	rhs[i] = ur;
      }
      else if(  lr < ur + tol && lr > negInfinity && ur < Infinity ){
	senx[i] = 'E';
	rhs[i] = lr;
      }
      else{
	MWprintf( 10, "AMPL Interface: error with constraints.\n" );
	return ABORT;
      }
    }
  }
  else{ //there are range rows, headache!
    if( handle_range_rows( m, n, nz,
			   matbeg, matind, matcnt, matval,
			   rhs, senx ) ){
      return ABORT;
    }
  }
  
  
  // priority ???  add it later
 
  
#ifdef DEBUG_AMPL
  printf( "objective sense is: " );
  if( objsen == 1 ) cout << "minimize." << endl;
  else cout << "maximize." << endl;
  cout << "objective constant is "<<objadj<<endl;
  cout << "n: " << n << " m: " << m << " nz: " << nz << endl;
  printf("matval is: \n");
  print( matval, nz );
  printf("matbeg is: \n");
  print( matbeg, n );
  printf("matind is: \n");
  print( matind, nz );
  printf("matcnt is: \n");
  print( matcnt, n );
  cout<<"varialbes type are: "<<endl;
  for( i = 0; i < n; i++ ){
    if( coltype[i] == COL_TYPE_CONTINUOUS ) cout << "c" << " ";
    else if ( coltype[i] == COL_TYPE_INTEGER ) cout << "i" << " ";
    else cout << "b" << " ";
  }
  cout<<endl;
  cout << "Objective row: " << endl;
  print( c, n );
  cout << "lower bounds: " << endl;
  print( lb, n);
  cout << "upper bounds: " << endl;
  print( ub, n );
  printf("rhs is: \n");
  print( rhs, m );
  print( senx, m );
#endif
  
  
  load( objsen, n, m, nz,
	matbeg, matind, matcnt, matval,
	coltype, c, lb, ub, 
	rhs, senx );
  
  
  //make sure the MIP has been read in
  //check whether rootMip has been setup
  if(NULL==formulation){
    cerr<<"No MIP was from GAMS file."<<endl;
    st = UNINITIALIZED;
    return ABORT;
  }
  
  
  // XXX perform heuristics before starting?
  if(preHeuristics){
    // bestUpperBound = performPreHeu();
  }
  
  
  // Set up the cutpool on the master
  if(genKnapCut + genFlowCut + genSKnapCut > 0 && maxCuts>0) {
    cPool = new cutPool(maxCuts);
    if( NULL == cPool ){
      st = MEMORY_ERROR;
      return ABORT;
    }
  }
  
  // Setup the branching strategy
  if( branStrategy == 0 )
    {
      pseudocosts = new PseudoCostManager( formulation );
      if( NULL == pseudocosts ){
	st = MEMORY_ERROR;
	return ABORT;
      }
    }
 
  
  //setup searching rule 
  switch(seleStrategy){
  case 0:  //peudocost estimation
    set_task_key_function(&pc);
    current_seleStrategy = 0;
    break;
  case 1:  //depth first
    set_task_key_function(&dfp);
    current_seleStrategy = 1;
    break;
  case 2: case 4:  //2: best first, 4: hybrid strategy
    set_task_key_function(&bb);
    current_seleStrategy = 2;
    break;
  case 3:  //deepest first
    set_task_key_function(&deepest_first);
    current_seleStrategy = 3;
    break;
  default:
    cerr<<"wrong searching algorithm."<<endl;
    cerr<<"use default searching algorithm: Best bound!."<<endl;
    set_task_key_function(&bb);
    current_seleStrategy = 2;
    break;
  }
  
  sort_task_list();
  
 
  // This copies the formulation into the LPSolver Data Structures
  lpsolver->init( formulation->get_ncols(),
		  formulation->get_nrows(),
		  formulation->get_nnzero(),
		  formulation->get_objsen(),
		  formulation->get_objx(),
		  formulation->get_rhsx(),
		  formulation->get_senx(),
		  formulation->get_colmajor()->get_matbeg(),
		  formulation->get_colmajor()->get_matcnt(),
		  formulation->get_colmajor()->get_matind(),
		  formulation->get_colmajor()->get_matval(),
		  formulation->get_bdl(),
		  formulation->get_bdu(),
		  NULL );				 

  
  
  // This loads the problem into the LPSolver.
  if( ! lpsolver->LPLoad() )
    {      
      xlpRoot = new double [formulation->get_ncols()];
      djRoot = new double [formulation->get_ncols()];
      cstatRoot = new CBasisStatus [formulation->get_ncols()];
      rstatRoot = new CBasisStatus [formulation->get_nrows()];
      
      if( NULL == xlpRoot   || NULL == djRoot || 
	  NULL == cstatRoot || NULL == rstatRoot ){
	st = MEMORY_ERROR;
	return ABORT;
      }
      
      //XXX Could put barrier solve (with crossover) here.
      CLPStatus sol_status = lpsolver->LPSolvePrimal( &zlpRoot, 
						      xlpRoot,
						      NULL, NULL, 
						      djRoot );
      lpsolver->LPGetBasis( cstatRoot, rstatRoot );
      
      if ( sol_status != LP_OPTIMAL )
	{
	  cout << " Oh man!!! Unable to solve root LP.  packing up." 
	       << endl << "Sol status = " << sol_status << endl;
	  
	  if ( sol_status == LP_INFEASIBLE ){
	    cout << "MIP-- is infeasible\n" << flush;
	    st = INFEASIBLE;
	  }
	  else if ( sol_status == LP_UNBOUNDED ){
	    cout << "MIP-- is unbounded\n" << flush;
	    st =  UNBOUNDED;
	  }
	  else{
	    cout << "An error occurred during the call to LP solver" << flush;
	    st =  LPSOLVER_ERROR;
	  }
	  
	  status = ABORT;
	}
      else
	{
#if defined( DEBUGMW )
	  cout << "root LP has value: " << zlpRoot << endl;
#endif
	  lpPivots += lpsolver->LPGetItCount();
	}
    }
  
  MWprintf( 10, "AMPL Interface: FATCOP load problem from AMPL interface\n");
  
  // 9/5/00.  We set this to one initially.  Once we get enough
  //          tasks, 

  maxNodeInSlave = 1;
  MWprintf( 10, "Setting initial number of nodes in slave to %d\n", maxNodeInSlave );
  
  mycplexcopies = 0; 
  
  return status;
  
}

//FATCOP_driver method: write stub.sol
void FATCOP_driver::printresults()
{

  MWprintf( 10, "*** Best solution found is: %.6lf\n", bestUpperBound );
  MWprintf( 10, "*** Nodes: %d  Pivots: %d  Time:  %.2lf\n",
	    nNodes, lpPivots, solutionTime );

  MWprintf( 10, "*****  Cut Stats.  Success: %d  Trials: %d  Time: %.2lf\n",
	    nCutSuccess, nCutTrial, cutTime );
  MWprintf( 10, "*****  Heuristic Stats.  Success: %d  Trials: %d  Time: %.2lf\n",
	    divingHeuristicSuccess, divingHeuristicTrial, divingHeuristicTime );
  MWprintf( 10, "*****  Branching Stats.  Time: %.2lf\n", branTime );

  MWprintf( 10, "\n\n" );

  if( feasibleSolution ){
    for( int i = 0; i < formulation->get_nvars(); i++ )
      if( feasibleSolution[i] > 1.0e-6 || feasibleSolution[i] < -1.0e6 )
	MWprintf( 10, "x[%d] = %.4lf\n", i, feasibleSolution[i] );
  }
  
  // ###qun not sure it is right: check condition program terminates
  // without resource limit
  if ( 0 == get_number_tasks() ){
    if ( bestUpperBound*10 < DBL_MAX ){ //feasible solution found
      st = SOLVED;
    }
    else{
      st  = INT_INFEASIBLE;
    }
  }
  else{
    if ( bestUpperBound*10 < DBL_MAX ){ //feasible solution found
      st = INT_SOLUTION;
    }
    else{
      st  = NO_INT_SOLUTION;
    }
  }
  
  
  //write solution back to ampl
  FATCOP_driver::Status    stat = status() ;
  int mipstate = 0;
  double stoptol = getStopTol();
  double bestval = value() + objadj;
  double* x = getprimal();
  int simplexpivots = pivots();
  int bbnodes = nodes();
  
  char buf[256];
  
  switch( stat )
    {
    case FATCOP_driver::SOLVED:
      if( stoptol <= tol )
	mipstate=0;
      else
	mipstate=3;
      break ;
    case FATCOP_driver::INFEASIBLE:
      mipstate=1;
      break ;
    case FATCOP_driver::UNBOUNDED:
      mipstate=2;
      break ;
    case  FATCOP_driver::INT_INFEASIBLE:
      mipstate=4;
      break ;
    case FATCOP_driver::INT_SOLUTION:
      mipstate=5;
      break ;
    case FATCOP_driver::NO_INT_SOLUTION:
      mipstate=6;
      break ;  
    default:
      MWprintf( 10, "FATCOP solver error.\n" );
      mipstate=7;
      break ;
    }
  
  solve_result_num = solinfo[mipstate].code;
  
  int i = sprintf(buf, "%s: %s", Oinfo.bsname, solinfo[mipstate].msg);
  
  if ( solinfo[mipstate].wantobj )
    i += sprintf(buf+i, ", objective %.*g", obj_prec(), bestval);
  
  i += sprintf(buf+i,"\n%d simplex iterations", simplexpivots);
  
  sprintf(buf+i, "\n%d branch & bound nodes", bbnodes);
  
  
  
  write_sol(buf, x, NULL, &Oinfo);
  
  //ASL_free(&asl);
  //XXX need to free matcnt, matbeg ... if we want to repeatly call 
  //ampl

  //tell condor job is done
  createFinishFile();
  
  return;
}



#endif

