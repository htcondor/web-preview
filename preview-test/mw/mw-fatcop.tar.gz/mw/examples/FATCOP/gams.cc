#if defined( GAMS_INTERFACE )

#include <errno.h>

#include "global.hh"
#include "PRINO.hh"
#include "FATCOP_driver.hh"
#include "FATCOP_task.hh"
#include "cutpool.hh"
#include "pseudocost.hh"

#define ANSI
#define MAXLINELENGTH  200

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "iolib.h" //gams io lib


//#define DEBUG_GAMS
#define print(x,n) {for( int i = 0; i < n; i++) cout<<x[i]<<" "; cout<<endl;}

#define Int(n) (int *)malloc((n)*sizeof(int))
#define Double(n) (double *)malloc((n)*sizeof(double))
#define CChar(n) (char *)malloc((n)*sizeof(char))


extern MWKey dfp(MWTask* t);
extern MWKey bb(MWTask* t);
extern MWKey pc(MWTask* t);
extern MWKey deepest_first(MWTask* t);



//###################################################################
//                  GLOBAL VARIABLES
//###################################################################

int n;                  /* number of columns */
int m;                  /* number of rows */
int nz;                 /* number of nonzeroes */
int objvar; 
int objrow;            /* objective variable */
int itlim;
double reslim;
double ginf, gminf;     /* inf, -inf */
int objsen;		/* 1 : minimize, -1 : maximize */
bool isamip;
double optcRel,optcAct;
int nodlim;
bool priorities;
int nints = 0;     /* number of binary and integer variables */


double *aa = 0;             /* matval */
int *irow = 0;              /* matind - row index */
int *istart = 0;            /* matbeg - start index in aa of col i */
int *icnt = 0;              /* matcnt - count of nz in column i */

double *c = 0;              /* cost row */
double *lb = 0, *ub = 0;    /* bounds */
int* coltype = 0;
double *xpri = 0;           /* priority */              

double *rhs = 0;
char* senx = 0;

bool reformulated;
double  reforma;
double reformb;

double nolb = -inf;  
double noub = inf;   

double input_time = 0.0;
double calc_time = 0.0;

char ch;   /* needed for parsing option file */
int intvarno=0;



/* GAMS Codes:
   
	solver statusi		model status
	
  1.	normal completion	optimal
  2.	iteration interrupt	locally optimal
  3.	resource interrupt	unbounded
  4.	terminated by solver	infeasible
  5.	eval error limit	locally infeasible
  6.	unknown			intermediate infeasible
  7.	n.a.			intermediate nonoptimal
  8.	preproc error		integer solution
  9.	setup failure		intermediate non-integer
  10.	solver failure		integer infeasible
  11.	internal solver error	no solution
  12.	postproc. error		error unknown
  13.	error system failure	error no solution
*/



typedef struct {
	int solverstatus;
	int modelstatus;
	bool infes;
	bool unb;
	bool nopt;
	char *msg;
} STATMAP;



STATMAP mipstatmap[] = {
  
  /*	solsta	modsta	infes	unb	nopt	msg */
  
	1,	1,	false,	false,	false,	"Found proven optimal solution.\n",
	1,	4, 	true,	false,	true,	"Problem is infeasible.\n",	
	1,	3,	false,	true,	true,	"Problem is unbounded.\n",	
	1,      10,     true,   false,  true,   "Problem is integer infeasible.\n",
	2,      8,      false,  false,  true,   "Found integer solution, node limit reaches.\n",
	2,      9,      false,  false,  true,   "intermediate non-integer, node limit reaches.\n",
	1,	1,	false,	false,	true,	"Solution satisfies tolerance.\n"
};





//###################################################################
//                  FUNCTINS
//###################################################################

//define forward
void prIntroInfo(); 
int allocate_memory();

void get_char(char**);

void readat(FILE*, FILE*);
void store_row(int, int, double);
void store_col(int , double, double, int,double);

void reformulate();

void message(char*);
void error(char*);
void mapmipstat(int, int*, int*, bool*, bool*, bool*, double);
void mipmessage(int, double);
void createFinishFile();



//###################################################################
//                  MAIN GAMS Interface Routine
//###################################################################
MWReturn FATCOP_driver::get_userinfo( int argc, char *argv[] )
{
  
#ifdef DEBUG_GAMS
  cout<<" $$$$ calling FATCOP_driver get_userinfo "<<endl;
#endif
  
  MWReturn status = OK;
  
  char wd[_POSIX_PATH_MAX];
/*
  if ( getcwd( wd, 100 ) == NULL ) {
    MWprintf ( 10, "getcwd failed!  errno %d.\n", errno );
  }
  
  MWprintf ( 70, "Working directory is %s.\n", wd );
*/  
  char default_worker_name[128];
  sprintf( default_worker_name, "%s/fatcop-worker", wd );
  
  MWprintf ( 70, "default worker name is %s.\n", default_worker_name );
  
  RMC->set_worker_attributes( t_num_arches, default_worker_name, NULL );
  
  MWprintf( 10, "Setting worker executable %d to %s\n",
	    t_num_arches, default_worker_name );
  
  
  if (argc<2) {
    MWprintf( 10, "GAMS INTERFACE: No command line argument found\n");
    return ABORT;
  }
  
  // Tell MW about the checkpoint frequency
  if( checkpointType == 1 )
    set_checkpoint_frequency( checkpointFrequency );
  if( checkpointType == 2 )
    set_checkpoint_time( checkpointFrequency );

  cntrec cntinfo;

  gfinit();
  
  cout << argv[0] <<"  " << argv[1] << endl;
  
  
  gfrcnt(TRUE,FALSE,&cntinfo,argv[1]);
  
  gfopst(); //open status file
  
  prIntroInfo();
  
  m = cntinfo.kgv[1];
  n = cntinfo.kgv[2];
  nz = cntinfo.kgv[3];
  objvar = cntinfo.kgv[7];
  itlim = cntinfo.kgv[8];
  reslim = cntinfo.xgv[1];
  ginf = cntinfo.xgv[10];
  gminf = cntinfo.xgv[11];
  
  bool useopt = cntinfo.lgv[2];
  if (cntinfo.lgv[3])
    objsen = 1;   /* minimization */
  else
    objsen = -1;  /* maximization */
  
  isamip = cntinfo.lgv[4];
  
  
  if (isamip) {
    optcRel = cntinfo.xgv[8];
    optcAct = cntinfo.xgv[7];
    priorities = (cntinfo.kmv[9]!=0);
    nints = cntinfo.kmv[1]+cntinfo.kmv[2];
    nodlim = cntinfo.kmv[6];
    int nososvars = cntinfo.kmv[4]+cntinfo.kmv[5];
    if(nososvars>0){
      MWprintf( 10, "FATCOP is not able to process SOS type variables.\n 
                    You can either redefine the variables or choose another 
                    mip solver. \n" );
      return ABORT;
    }  
  } 
  
  
  fprintf(gfiosta," \n \n");
  fprintf(gfiosta,"------------------------------------------------------------------------\n");
  fprintf(gfiosta,"CONTROL FILE STATISTICS\n");
  fprintf(gfiosta,"------------------------------------------------------------------------\n");
  fprintf(gfiosta,"Rows : %d, columns  : %d\n",m,n);
  fprintf(gfiosta,"Nonzeros           : %d\n", nz);
  fprintf(gfiosta,"Iteration limit    : %d\n", itlim);
  fprintf(gfiosta,"Resource  limit    : %e\n", reslim);
  fprintf(gfiosta,"Objective variable : %d\n",objvar);
  fprintf(gfiosta,"Objective sense    : %s\n",
	  ((objsen == 1) ? "minimize" : "maximize"));
  
  if (isamip) {
    fprintf(gfiosta,"Binary variables   : %d\n",cntinfo.kmv[1]);
    fprintf(gfiosta,"Integer variables  : %d\n",cntinfo.kmv[2]);
    fprintf(gfiosta,"OPTCA : %e , OPTCR : %e\n",optcAct,optcRel);
    fprintf(gfiosta,"Priorities         : %s\n",
	    (priorities ? "yes" : "no"));
    fprintf(gfiosta,"Node limit         : %d\n",nodlim);
  }
  
  fprintf(gfiosta," \n \n");
  
  
  //1. allocate memory for the matrix
  if( allocate_memory() ){
    st = MEMORY_ERROR;
    return ABORT;
  }
  
  //2. set options
  setR(optcRel);
  setA(optcAct);
  setNodelim(nodlim);
  setReslim(reslim);
  //setItlim(itlim);
  //bestUpperBound = iolib.cutoff;
 
  
  //3. read option file
  //If option file is specified, those options will overide GAMS options
  if (useopt) { 
    char optionfile[80];
    char s[MAXLINELENGTH+1];
    char *tmp;
    
    gfstct("START");
    gfopti(optionfile);

    MWprintf( 60, "use option file: s%.\n", optionfile );

    FILE* f = fopen(optionfile,"r");
    
    if (f != NULL)                  /* file is found */
      {
	
	fprintf(gfiolog,"Reading user supplied option file...\n");
	
	fprintf(gfiosta,"Option file:\n");
	fprintf(gfiosta,"-----------\n");
	
	while(fgets(s,MAXLINELENGTH,f))
	  {
	    //  printf("%s\n",s);
	    
	    fprintf(gfiosta,"> %s",s);  /* s contains \n, otherwise
					   add to %s */
	    fprintf(gfiolog,"> %s",s);
	    
	    tmp = s;
	    get_char(&tmp);         /* read ahead */
	    if (ch!='*' && ch!='\n')
	      //printf("%s\n",tmp);
	      setOption(tmp);
	  }
	
	fclose(f);
	fprintf(gfiosta,"\n\n");    /* status file must end with a newline */
      }
    else
      {
	fprintf(gfiosta,"Option file %s not found.\n",optionfile);
	fprintf(gfiolog,"Option file %s not found.\n",optionfile);
	fprintf(gfiosta,"Using defaults instead.\n");
	fprintf(gfiolog,"Using defaults instead.\n");
      }
    
    gfstct("STOPC");
  }
  else{
    MWprintf( 60, "no option file specified, search current dir.\n" );
    readOption("fatcop.opt");
  }
  

  // Create the LP solver so that you can read the MPS file
  
  bool created = 0;
#if defined( CPLEXv6 )
  lpsolver = new CCPLEXInterface( cplexLicenseDir, created );
#endif
#if defined( SOPLEXv1 )
  if( ! created )
    {
      MWprintf( 10, "Unable to initialize CPLEX interface -- creating SOPLEX interface\n" );
      lpsolver = new CSOPLEXInterface;
    }
#endif
  
  
  //4. read matrix
  readat(gfiolog, gfiosta);
  
  
  //5. reformulate the problem
  reformulate();
  

  istart[n] = istart[n-1] + icnt[n-1];
  
  //6. load the problem to mip solver
  load( objsen, n, m, nz,
	istart, irow, icnt, aa,
	coltype, c, lb, ub, 
	rhs, senx );
  message("Fatcop loaded the problem from GAMS");
  
  
  //make sure the MIP has been read in
  //check whether rootMip has been setup
  if(NULL==formulation){
    MWprintf( 10, "No MIP was from GAMS file.\n" );
    st = UNINITIALIZED;
    return ABORT;
  }
  
  // Set up the cutpool on the master
  if(genKnapCut + genFlowCut + genSKnapCut > 0 && maxCuts>0) {
    cPool = new cutPool(maxCuts);
    if( NULL == cPool ){
      st = MEMORY_ERROR;
      return ABORT;
    }
  }
  
  // Setup the branching strategy
  if( branStrategy == 0 )
    {
      pseudocosts = new PseudoCostManager( formulation );
      if( NULL == pseudocosts ){
	st = MEMORY_ERROR;
	return ABORT;
      }
    }
  
  //setup searching rule 
  switch(seleStrategy){
  case 0:  //peudocost estimation
    set_task_key_function(&pc);
    current_seleStrategy = 0;
    break;
  case 1:  //depth first
    set_task_key_function(&dfp);
    current_seleStrategy = 1;
    break;
  case 2: case 4:  //2: best first, 4: hybrid strategy
    set_task_key_function(&bb);
    current_seleStrategy = 2;
    break;
  case 3:  //deepest first
    set_task_key_function(&deepest_first);
    current_seleStrategy = 3;
    break;
  default:
    cerr<<"wrong searching algorithm."<<endl;
    cerr<<"use default searching algorithm: Best bound!."<<endl;
    set_task_key_function(&bb);
    current_seleStrategy = 2;
    break;
  }
  
  sort_task_list();
  
  
  // This copies the formulation into the LPSolver Data Structures
  lpsolver->init( formulation->get_ncols(),
		  formulation->get_nrows(),
		  formulation->get_nnzero(),
		  formulation->get_objsen(),
		  formulation->get_objx(),
		  formulation->get_rhsx(),
		  formulation->get_senx(),
		  formulation->get_colmajor()->get_matbeg(),
		  formulation->get_colmajor()->get_matcnt(),
		  formulation->get_colmajor()->get_matind(),
		  formulation->get_colmajor()->get_matval(),
		  formulation->get_bdl(),
		  formulation->get_bdu(),
		  NULL );				 
  
  // This loads the problem into the LPSolver.
  if( ! lpsolver->LPLoad() )
    {      
      xlpRoot = new double [formulation->get_ncols()];
      djRoot = new double [formulation->get_ncols()];
      cstatRoot = new CBasisStatus [formulation->get_ncols()];
      rstatRoot = new CBasisStatus [formulation->get_nrows()];
      
      if( NULL == xlpRoot   || NULL == djRoot || 
	  NULL == cstatRoot || NULL == rstatRoot ){
	st = MEMORY_ERROR;
	return ABORT;
      }
      
      //XXX Could put barrier solve (with crossover) here.
      CLPStatus sol_status = lpsolver->LPSolvePrimal( &zlpRoot, 
						      xlpRoot,
						      NULL, NULL, 
						      djRoot );
      lpsolver->LPGetBasis( cstatRoot, rstatRoot );
      
      if ( sol_status != LP_OPTIMAL )
	{
	  cout << " Oh man!!! Unable to solve root LP.  packing up." 
	       << endl << "Sol status = " << sol_status << endl;

	  if ( sol_status == LP_INFEASIBLE ){
	    cout << "MIP-- is infeasible\n" << flush;
	    st = INFEASIBLE;
	  }
	  else if ( sol_status == LP_UNBOUNDED ){
	    cout << "MIP-- is unbounded\n" << flush;
	    st =  UNBOUNDED;
	  }
	  else{
	    cout << "An error occurred during the call to LP solver" << flush;
	    st =  LPSOLVER_ERROR;
	  }
	  
	  status = ABORT;
	}
      else
	{
#if defined( DEBUGMW )
	  cout << "root LP has value: " << zlpRoot << endl;
#endif
	  lpPivots += lpsolver->LPGetItCount();
	}
    }
  
  message("Starting FATCOP...");
  input_time = gfclck();
  
  mycplexcopies = 0; 

  // 9/5/00.  We set this to one initially.  Once we get enough
  //          tasks, 

  maxNodeInSlave = 1;
  message("Setting initial number of nodes in slave to 1\n");
  
  return status;
}




void FATCOP_driver::printresults()
{

  MWprintf( 10, "*** Best solution found is: %.6lf\n", bestUpperBound );
  MWprintf( 10, "*** Nodes: %d  Pivots: %d  Time:  %.2lf\n",
	    nNodes, lpPivots, solutionTime );
  
  MWprintf( 10, "*****  Cut Stats.  Success: %d  Trials: %d  Time: %.2lf\n",
	    nCutSuccess, nCutTrial, cutTime );
  MWprintf( 10, "*****  Heuristic Stats.  Success: %d  Trials: %d  Time: %.2lf\n",
	    divingHeuristicSuccess, divingHeuristicTrial, divingHeuristicTime );
  MWprintf( 10, "*****  Branching Stats.  Time: %.2lf\n", branTime );
  
  MWprintf( 10, "\n\n" );


  if( feasibleSolution ){
    for( int i = 0; i < formulation->get_nvars(); i++ )
      if( feasibleSolution[i] > 1.0e-6 || feasibleSolution[i] < -1.0e6 )
	MWprintf( 10, "x[%d] = %.4lf\n", i, feasibleSolution[i] );
  }
  
  // ###qun not sure it is right: check condition program terminates
  // without resource limit
  if ( 0 == get_number_tasks() ){
    if ( bestUpperBound*10 < DBL_MAX ){ //feasible solution found
      st = SOLVED;
    }
    else{
      st  = INT_INFEASIBLE;
    }
  }
  else{
    if ( bestUpperBound*10 < DBL_MAX ){ //feasible solution found
      st = INT_SOLUTION;
    }
    else{
      st  = NO_INT_SOLUTION;
    }
  }
  
  
  //write solution back to GAMS
  
  calc_time = gfclck() - input_time;
  
  int row,col;
  char line[256];
  
  int solstat, modstat;
  bool infes, unb, nonopt;
  
  int mipstate, itsusd,nodusd;
  double mipobj, bestpos, relgap;
  
  //printf("Write solution\n");
  
  FATCOP_driver::Status    stat = status() ;
  itsusd =  pivots();
  mipobj = value();
  nodusd = nodes();
  bestpos = getBestPos();
  relgap = getFinalGap();
  double* x = getprimal();
 
  switch( stat )
    {
    case FATCOP_driver::SOLVED:
      mipstate=1;
      mapmipstat(mipstate,&solstat,&modstat,&infes,&unb,&nonopt,relgap);
      break ;
    case FATCOP_driver::INFEASIBLE:
      mipstate=2;
      mapmipstat(mipstate,&solstat,&modstat,&infes,&unb,&nonopt,relgap);
      break ;
    case FATCOP_driver::UNBOUNDED:
      mipstate=3;
      mapmipstat(mipstate,&solstat,&modstat,&infes,&unb,&nonopt,relgap);
      break ;
    case  FATCOP_driver::INT_INFEASIBLE:
      mipstate=4;
      mapmipstat(mipstate,&solstat,&modstat,&infes,&unb,&nonopt,relgap);
      break ;
    case FATCOP_driver::INT_SOLUTION:
      mipstate=5;
      mapmipstat(mipstate,&solstat,&modstat,&infes,&unb,&nonopt,relgap);
      break ;
    case FATCOP_driver::NO_INT_SOLUTION:
      mipstate=6;
      mapmipstat(mipstate,&solstat,&modstat,&infes,&unb,&nonopt,relgap);
      break ;  
    default:
      //      mapmipstat(5,&solstat,&modstat,&infes,&unb,&nonopt);
      error("solver error\n");
      break ;
    }
  
  
  fprintf(gfiolog,"\n");
  gfstct("START");
  
  mipmessage(mipstate, relgap);
  
  if (mipstate==1){
    sprintf(line,"MIP Solution  :  %18.6f    (%d iterations, %d nodes)",
	    mipobj,itsusd,nodusd);
    message(line);
    sprintf(line,"Best integer solution possible  :  %18.6f",
	    bestpos);
    message(line);
    sprintf(line,"Relative gap  :  %18.6f",
	    relgap);
    message(line);
  }
  if (mipstate==5){  
    sprintf(line,"Best integer solution possible : %18.6f",mipobj);
    message(line);
  }
  
  if (reformulated) 
    if (reformb != 0.0) {
      fprintf(gfiolog,"After adding constant term, objective is %18.6f\n",mipobj+reformb);
      fprintf(gfiosta,"After adding constant term, objective is %18.6f\n",mipobj+reformb);
    }
  
  
  gfwsta(modstat,solstat,itsusd,gfclck(),mipobj+reformb,0);
  
  
  //  if(FATCOP_driver::INT_SOLUTION == stat || FATCOP_driver::SOLVED == stat){

  //printf("Writing rows\n");    
  message("\n---------------------------------------");
  message("FATCOP does not provide row information.");
  for (row=0;row<m+1;++row)
    {
      if (reformulated) 
	if (row==objrow) {   /* insert objective row here */
	  gfwrow( -reformb/reforma, -reforma, 0, 0 );
	}
      
      if (row>=m) 
	continue;
      
      //some faked values
      gfwrow(0, 0, 2, 0);
      
    }
  
  //printf("Writing cols\n");
  message( "FATCOP only supply primal values. " );
  message("---------------------------------------\n");
  for ( col = 0; col < n+1; ++col )
    {
      if (reformulated)
	if (col==objvar) {
	  gfwcol( mipobj+reformb, 0.0, 2, 0 );
	}
      
      if (col>=n) continue;
      
      //some faked values
      if( x ){
	gfwcol( x[col], 0, 2, 1);
      }
      else{
	gfwcol( 0, 0, 2, 1);
      }
    }
  
  
  double output_time = gfclck()-calc_time-input_time;
  
  gfwrti(input_time);
  gfwcti(calc_time);
  gfwwti(output_time);
  
  
  gfstct("STOPC");
  gfclos();  
  
  createFinishFile();
  
  return;
  
}




//###################################################################
//                  Function Definitions
//###################################################################

void  prIntroInfo()
{
  int iolevel;
  char osname[50];
  char line[80];
  
  gfsysid(osname,&iolevel);
  sprintf(line, "iolevel-%d, %s\n",iolevel, osname);
  
  gfstct("START");
  fprintf(gfiosta,"\n");
  fprintf(gfiosta, "%s", line);
  gfstct("STOPC");
  
}


int allocate_memory()
{
  int i;
  
  //matrix
  irow = Int( nz );
  aa = Double( nz );
  istart = Int( n+1 );
  icnt = Int( n );
  
  if( !( irow && aa && istart && icnt ) ) return 1;
  
  //col vector
  c = Double( n );
  lb = Double( n );
  ub = Double( n );
  coltype = Int( n );
  
  if( !( c && lb && ub && coltype ) ) return 1;
  
  //row vector
  rhs = Double( m );
  senx = CChar( m );
  
  if( !( rhs && senx ) ) return 1;
  
  if ( isamip && nints > 0 ){
    xpri = Double( nints );
    if( !xpri ) return 1;
    for ( i=0;i < nints; ++i ){
      xpri[i] = 0.0;
    }
  }
  
  
  /* initialize some arrays */
  for ( i = 0; i < n; ++i )
    c[i] = 0.0;
  
  
  return 0;
  
}



void get_char(char** s)
  /* get next char, and if not at end, move pointer to next char */
{
  
  ch = **s;
  if (isascii(ch))
    if (isupper(ch))
      ch = (char) tolower(ch);
  
  return;
  
}


void readat(FILE* logfile, FILE* statusfile)
{  
  rowrec row;
  colrec col;
  int nzcol;
  int idummy;
  int nnz;
  int i,j;
  int rowindex;
  
  fprintf(logfile,"Reading data ...\n");
  
  
  // printf("\nReading rowss ...\n");  
  for ( i = 0;i < m; ++i )  {
    gfrrow( &row );
    store_row(i,
	      row.idata[1],     /* sign */
	      row.rdata[2]);    /* rhs */
  }
  
  
  // printf("\nReading columns ...\n");
  nnz = 0;
  for (j=0;j<n;++j) {
    gfrcol(&col);
    store_col(j,
	      col.cdata[1],            /* lb */
	      col.cdata[3],            /* ub */
	      col.idata[3],            /* variable type */ 
	      col.cdata[4]);           /* variable type */       
    
    
    nzcol = col.idata[1];
    icnt[j] = nzcol;
    istart[j] = nnz;
    
    for ( i=0; i < nzcol; ++i,++nnz ) {
      gfrcof( &aa[nnz], &rowindex, &idummy);
      irow[nnz] = rowindex-1;
    }
  }
  
  c[objvar] = 1.0;
  
  printf("\nProblem is loaded\n");
  
  return;
}



void store_row(int row, int type, double b)
{
  if ( (row<0)||(row>=m) ){
    cerr<<"GAMS INTERFACE: Invalid row number in store_row()"<<endl;
    exit(1);
  }
  
  if( type == 0 ){
    senx[row] = 'E';
  }
  else if( type == 1 ){
    senx[row] = 'G';
  }
  else{
    senx[row] = 'L';
  }
  
  rhs[row] = b;
  
  return;
  
}


void store_col(int col, double lo, double up, int ctype, double prior)
{
  if ((col<0)||(col>=n)){
    cerr<<"GAMS INTERFACE: Invalid column number in store_col()."<<endl;
    exit(1);
  }
  
  
  if (lo==gminf)    lb[col] = nolb;
  else    lb[col] = lo;
  
  if (up==ginf)    ub[col] = noub;
  else    ub[col] = up;
  
  
  switch(ctype) {
    
  case 0 : case 3: case 4:/* continuous */
    coltype[col] = COL_TYPE_CONTINUOUS;
    break;      
  case 1 : /* binary */
    if (lb[col] == ub[col])
      coltype[col] = COL_TYPE_CONTINUOUS;
    else {
      coltype[col] = COL_TYPE_BINARY;
      if ( priorities ) {
	assert( intvarno < nints );
	xpri[intvarno] = prior;
	++intvarno;
      }
    }
    break;
  case 2 : /* integer */
    if (lb[col] == ub[col])
      coltype[col] = COL_TYPE_CONTINUOUS;
    else {
      coltype[col] = COL_TYPE_INTEGER;
      if ( priorities ) {
	assert( intvarno < nints );
	xpri[intvarno] = prior;
	++intvarno;
      }  
    }
    break;
  default:
    cerr << "GAMS Interface: invalid column type in store_col()" << endl;
    break;
  }
  
  return;
}


void reformulate()
{
  /* try to do a one step reformulation*/
  
  int k;
  int knew, jnew;
  int i,j;
  int kstart, kend;
  int newcnt;
  
  /* assume we fail */
  reformulated = FALSE;
  
  
  /* objective variable has to be a free variable */
  if ( (lb[objvar]!=nolb) || (ub[objvar]!=noub) )
    return;
  
  
  /* objective column should have length 1 */
  if (icnt[objvar]!=1) 
    return;
  
  /* objective row should be an equality */
  k =  istart[objvar];
  objrow = irow[k];
  
  if ( senx[objrow] != 'E' ) 
    return;
  /* if gams obj row was formulated like
   *     az + c'x =e= b
   * then the new objective will look like:
   *    (b-c'x)/a
   * so objective coefficients are -c[i]/a
   */
  
  /*
   * REFORMA is (-1/a)
   * REFORMB is b/a
   * True value objective variable is REFORMB+OBJ
   * which is in most cases OBJ!
   */
  reforma = -1.0/aa[k];
  reformb = rhs[objrow]/aa[k];
  
  c[objvar] = 0.0;
  
  /* 
   * now loop over the whole matrix, extracting
   * the GAMS objective. We compress at the same time.
   */
  knew = 0;
  for (j=0, jnew=0; j < n; ++j, ++jnew) {
    if (j==objvar)
      --jnew;
    else {
      kstart = istart[j];
      kend = kstart+icnt[j];
      istart[jnew] = knew;
      newcnt=0;
      for (k=kstart;k<kend;++k) {
	i = irow[k];
	if (i==objrow) 
	  c[jnew] = reforma*aa[k];
	else {
	  aa[knew] = aa[k];
	  if (i < objrow)
	    irow[knew] = i;
	  else
	    irow[knew] = i-1;
	  ++knew;++newcnt;
	}
      }
      if (jnew!=j) {
	lb[jnew] = lb[j];
	ub[jnew] = ub[j];
	coltype[jnew] = coltype[j];
      }
      icnt[jnew] = newcnt;
    }
  }
  for (i=objrow+1;i<m;++i) {
    rhs[i-1] = rhs[i];
    senx[i-1] = senx[i];
    //rowstat[i-1] = rowstat[i];
  }
  
  
  --n;
  --m;
  nz = knew;
  reformulated = TRUE;
  
  return;
  
}



void error(char* msg)
{
  printf("\n%s\n",msg);
  fprintf(gfiosta,"\n*** %s\n\n",msg);
  gfstct("SYSOUT");
  exit(1);
}




void mapmipstat(int mipstat, int* solstat, int* modstat, bool* infes, 
		bool* unb, bool* nonopt, double finalgap)
  
{
  if ((mipstat >= 1) && (mipstat <= 6)) {
    if(mipstat==1  &&  finalgap > tol ){
      *solstat = mipstatmap[mipstat+5].solverstatus;
      *modstat = mipstatmap[mipstat+5].modelstatus;
      *infes   = mipstatmap[mipstat+5].infes;
      *unb     = mipstatmap[mipstat+5].unb;
      *nonopt  = mipstatmap[mipstat+5].nopt;
    }
    else{
      *solstat = mipstatmap[mipstat-1].solverstatus;
      *modstat = mipstatmap[mipstat-1].modelstatus;
      *infes   = mipstatmap[mipstat-1].infes;
      *unb     = mipstatmap[mipstat-1].unb;
      *nonopt  = mipstatmap[mipstat-1].nopt;
    }
  }
  
  else error("Illegal MIP status");
}


void mipmessage(int mipstat, double finalgap)
{
  if ((mipstat >= 1) && (mipstat <= 6)) {
    if(mipstat==1  &&  finalgap > tol ){
      message(mipstatmap[mipstat+5].msg);
    }
    else{
      message(mipstatmap[mipstat-1].msg);
    }
  }
  
  else error("Illegal MIP status");
}


void message(char* mess)
{
  fprintf(gfiolog,"%s\n",mess);
  fprintf(gfiosta,"%s\n",mess);
  
  return;
}


void createFinishFile()
{
  cout<<"creating a finish log"<<endl;
  
  FILE *fp;
  char outfile_name[100];
  
  
  sprintf(outfile_name, 
	  "/tmp/finish.gams");
  fp = fopen(outfile_name, "w"); 
  
  if (fp == NULL) cout<<"Can not open the file"<<endl;
  
  fprintf(fp, "finish!!!!!!\n ");
  
  fclose(fp);
  
  return;  
}

  


#endif //GAMS_INTERFACE



















