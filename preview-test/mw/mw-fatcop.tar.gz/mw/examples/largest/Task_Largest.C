#include "Task_Largest.h"
#include "MW.h"

Task_Largest::Task_Largest() {
	size = 0;
	numbers = NULL;
}

Task_Largest::Task_Largest(int size, int *numbers) {
	if (size > 0) {
		this->size = size;
		this->numbers = new int[size];
		for (int i=0; i<size; i++)
			this->numbers[i] = numbers[i];
		printself(30); // MWDEBUG
	} else {
		MWprintf(30, "Task construction: array size <=0\n");
	}
}

Task_Largest::~Task_Largest() {
	if (numbers)
		delete [] numbers;
}

void
Task_Largest::printself( int level ) {
	MWprintf ( level, "size=%d, numbers=\n\t", size);
	for (int i=0; i<size; i++)
		MWprintf(level, "%d ", numbers[i]);
	MWprintf (level, "\n");
}

void Task_Largest::pack_work( void ) {
	// MWprintf(30, "Task_Largest::pack_work\n");
	RMC->pack(&size, 1, 1);
	RMC->pack(numbers, size, 1);
	delete [] numbers;
}

void Task_Largest::unpack_work( void ) {
	// MWprintf(30, "Task_Largest::unpack_work\n");
	RMC->unpack(&size, 1, 1);
	if (numbers != NULL)
		delete [] numbers;
	numbers = new int[size];
	RMC->unpack(numbers, size, 1);
}

void Task_Largest::pack_results( void ) {
	RMC->pack(&largest, 1, 1);
}

void Task_Largest::unpack_results( void ) {
	RMC->unpack(&largest, 1, 1);
}

void Task_Largest::write_ckpt_info( FILE *fp ) {
}

void Task_Largest::read_ckpt_info( FILE *fp ) {
}
