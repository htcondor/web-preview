#ifndef LARGEST_TASK_H
#define LARGEST_TASK_H

#include <stdio.h>
#include "MWTask.h"

class Task_Largest : public MWTask {

 public:
    
    Task_Largest();
    Task_Largest(int size, int *numbers);
    ~Task_Largest();

    void pack_work( void );
    void unpack_work( void );
    void pack_results( void );
    void unpack_results( void );

    void printself( int level = 70 );

    void write_ckpt_info( FILE *fp );
    void read_ckpt_info( FILE *fp );

    int largest;  // The result
    int *numbers; // The array that contains the intergers
    int size;     // How many integers are in the array
};

#endif
