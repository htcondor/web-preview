/* 
  These methods will be specific to your application...
  You may want to search-replace Driver_Largest with a name for your app.
*/

#include "MW.h"
#include "Driver_Largest.h"
#include "Worker_Largest.h"
#include "Task_Largest.h"

extern double RMCOMM_bytes_packed;
extern double RMCOMM_bytes_unpacked;

Driver_Largest::Driver_Largest() {
	num_tasks = 0;
	job = NULL;
}

Driver_Largest::~Driver_Largest() {
	if (job) 
		delete [] job;
}

MWReturn Driver_Largest::get_userinfo( int argc, char *argv[] ) {
	MWprintf(30, "Enter Driver_Largest::get_userinfo\n");
	int i, j;
	for ( i=0; i<argc; i++ ) {
		MWprintf( 70, "arg %d: %s\n", i, argv[i] );
	}

	int ckpt_freq = 0;
	int num_arches = 0;
	int num_exec = 0;
	char exec[_POSIX_PATH_MAX];

	RMC->set_num_exec_classes(1);
	
	scanf("%d", &num_arches);
	RMC->set_num_arch_classes(num_arches);
	MWprintf( 10, "Set the arch class to %d\n", num_arches);
	for ( i=0; i<num_arches; i++) {
		if (i==0 ) {
			RMC->set_arch_class_attributes (i, 
				"((Arch==\"INTEL\")&&(Opsys==\"LINUX\"))");
		} else { 
			RMC->set_arch_class_attributes (i,
				"((Arch==\"INTEL\")&&(Opsys==\"SOLARIS26\"))");
		}
	}
	
	scanf ("%d", &num_exec);
	RMC->set_num_executables(num_exec);
	for ( i=0; i<num_exec; i++) {
		scanf("%s %d", exec, &j);
		MWprintf( 30, " %s\n", exec);
		RMC->add_executable(0, j, exec, ""); //??
	}
	
	scanf( "%d", &job_size);
	scanf( "%d", &task_size);
	if (job_size == 0) {
		MWprintf(10, "The job size is 0, so I quit\n");
		return QUIT;
	}
	job = new int[job_size];
	for ( i=0; i<job_size; i++) {
		scanf( "%d ", &job[i]);
	}

	largest = job[0];

	set_checkpoint_frequency (10);

	remain = job_size % task_size;
	num_tasks = remain ? (job_size/task_size + 1) : job_size/task_size ; 
	RMC->set_target_num_workers(num_tasks);
	MWprintf( 30, "Patitioned into %d tasks\n", num_tasks);
	
	MWprintf(30, "Leave Driver_Largest::get_userinfo\n");
	return OK;
}

MWReturn Driver_Largest::setup_initial_tasks(int *n_init , MWTask ***init_tasks) {
	int i;
	int head_pos;
	
	*n_init = num_tasks;
    	*init_tasks = new MWTask *[num_tasks];

	head_pos = 0;

	for ( i=0; i<num_tasks-1; i++) {
    		(*init_tasks)[i] = new Task_Largest(task_size, &(job[head_pos]));
		head_pos += task_size;
	}

	if (remain) {
		(*init_tasks)[i] = new Task_Largest(remain, &(job[head_pos]));
	} else {
		(*init_tasks)[i] = new Task_Largest(task_size, &(job[head_pos]));
	}

	return OK;
}


MWReturn Driver_Largest::act_on_completed_task( MWTask *t ) {
#ifdef NO_DYN_CAST
	Task_Largest *tf = (Task_Largest*) t;
#else
	Task_Largest *tf = dynamic_cast<Task_Largest *> (t);
#endif
	
	if ( tf->largest > this->largest)
		this->largest = tf->largest;
	
	MWprintf(30, "Driver_Largest::act_on_completed_task: current largest = %d\n", 
				this->largest);
	return OK;
}

MWReturn Driver_Largest::pack_worker_init_data( void ) {
	return OK;
}

void Driver_Largest::printresults() {
	MWprintf ( 10, "The largest number is %d.\n", this->largest);
	MWprintf ( 10, "Bytes Packed %lf\n", RMCOMM_bytes_packed );
	MWprintf ( 10, "Bytes Unpacked %lf\n", RMCOMM_bytes_unpacked );
}

void
Driver_Largest::write_master_state( FILE *fp ) {
}

void 
Driver_Largest::read_master_state( FILE *fp ) {
}

MWTask*
Driver_Largest::gimme_a_task() {
    	return new Task_Largest;
}

MWDriver* gimme_the_master() {
	return new Driver_Largest;
}
