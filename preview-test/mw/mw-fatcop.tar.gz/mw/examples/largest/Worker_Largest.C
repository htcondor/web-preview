#include "Worker_Largest.h"
#include "Task_Largest.h"

Worker_Largest::Worker_Largest() {
    workingTask = new Task_Largest;
}

Worker_Largest::~Worker_Largest() {
    delete workingTask;
}

double
Worker_Largest::benchmark( MWTask *t ) {
        Task_Largest *tl = dynamic_cast<Task_Largest *> ( t );
        tl->printself(30);
        return 3.14159;
}

MWReturn Worker_Largest::unpack_init_data( void ) {
	return OK;
}

void Worker_Largest::execute_task( MWTask *t ) {
	int i;
	MWprintf(30, "Enter Worker_Largest::execute_task\n");
	
#ifdef NO_DYN_CAST
	Task_Largest *tl = (Task_Largest *) t;
#else
    	Task_Largest *tl = dynamic_cast<Task_Largest *> ( t );
#endif
	MWprintf(30, "The task I am working on is:\n\t");
	for (i=0; i<tl->size; i++)
		MWprintf(30, "%d ", tl->numbers[i]);
	MWprintf(30, "\n");
	
	tl->largest = tl->numbers[0];
    	for (i=1; i<tl->size; i++) {
		if (tl->largest < tl->numbers[i]) {
			tl->largest = tl->numbers[i];
		}
	}

	{
		// And then wait for a long time :-)
		int count = 0;
		for (int ii = 0; ii < 1000; ii ++)
			for (int jj = 0; jj < 1000; jj++)
				count ++;
	}		

	MWprintf(30, "Leave Worker_Largest::execute_task, largest = %d\n", tl->largest);
}

MWWorker*
gimme_a_worker ()
{
	    return new Worker_Largest;
}
