#ifndef USER_DRIVER_H
#define USER_DRIVER_H

#include "MWDriver.h"
#include "Task_Largest.h"

/** The driver class derived from the MWDriver class for this application.

*/

class Driver_Largest : public MWDriver {

 public:
    Driver_Largest();
    ~Driver_Largest();

    /// Get the info from the user.  Don't forget to get the 
    /// worker_executable!
    MWReturn get_userinfo( int argc, char *argv[] );

    /// Set up an array of tasks here
    MWReturn setup_initial_tasks( int *, MWTask *** );

    /// What to do when a task finishes:
    MWReturn act_on_completed_task( MWTask * );

    /// Put things in the send buffer here that go to a worker
    MWReturn pack_worker_init_data( void );

    /// OK, this one doesn't *have* to be...but you want to be able to
    /// tell the world the results, don't you? :-)
    void printresults();

        /** Write out the state of the master to an fp. */
    void write_master_state( FILE *fp );

        /** Read the state from an fp.  This is the reverse of 
            write_master_state(). */
    void read_master_state( FILE *fp );

        /** That simple annoying function */
    MWTask* gimme_a_task();

 private:
		/* Basically, whatever private data you need 
		   for your application... */
    int num_tasks;	// how many tasks
    int remain;
    int job_size; 	// total number of integers
    int task_size;	// number of integers for one task
    int *job;		// the int array contains all the numbers
    int largest;	// the finial result
};

#endif
