#ifndef LARGEST_WORKER_H
#define LARGEST_WORKER_H

#include "MWWorker.h"
#include "Task_Largest.h"

class Worker_Largest : public MWWorker {

 public:
    Worker_Largest();
    ~Worker_Largest();
    
    /** Benchmarking. */
    double benchmark( MWTask *t );
	    

    MWReturn unpack_init_data( void );
    void execute_task( MWTask * );
};

#endif
