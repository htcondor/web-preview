// MWList.h 
//	Data structures to manage LISP-like lists.  
//
//      As in LISP, a list can contain any type of data structure
//	as an item on the list: thread control blocks, 
//	pending interrupts, etc.  That is why each item is a "void *",
//	or in other words, a "pointers to anything".
//
// This file taken from the distribution of 'Nachos' OS from Berkeley

#ifndef MWLIST_H
#define MWLIST_H

#include "MW.h"
typedef void (*VoidFunctionPtr)( void *arg, void *arg1 );
typedef int (*IntFunctionPtr)(void *arg1, void *arg2, void *arg3 );
typedef void* (*VoidStarFunctionPtr)(void *arg1, void *arg2, void *arg3 );
typedef double (*DoubleFunctionPtr)(void *arg );

// The following class defines a "list element" -- which is
// used to keep track of one item on a list.  It is equivalent to a
// LISP cell, with a "car" ("next") pointing to the next element on the list,
// and a "cdr" ("item") pointing to the item on the list.
//
// Internal data structures kept public so that List operations can
// access them directly.
class MWListElement 
{
	public:
		MWListElement(void *itemPtr, double sortKey);	
								// initialize a list element
		MWListElement *next;		// next element on list, 
								// NULL if this is the last
		double key;		    	// priority, for a sorted list
		void *item; 	    	// pointer to item on the list
};

// The following class defines a "list" -- a singly linked list of
// list elements, each of which points to a single item on the list.
//
// By using the "Sorted" functions, the list can be kept in sorted
// in increasing order by "key" in ListElement.

class MWList 
{
	public:
		MWList();					// initialize the list
		~MWList();				// de-allocate the list

		void Prepend(void *item);// Put item at the beginning of the list
		void Append(void *item);// Put item at the end of the list
		void *Remove(); 	 	// Take item off the front of the list
		void Remove(void*);		// Take the particular item off the list
		void Print();
		void Mapcar(VoidFunctionPtr func, void *arg);	// Apply "func" to every element 
											// on the list
		int Mapcdr(IntFunctionPtr func, void *arg1, void *arg3 );	// Apply "func" to every element
											// on the list till you get 1.
		void *MapItercdr(VoidStarFunctionPtr func, void *arg1, void *arg3 );
											// Apply "func" to every element
											// on the list till you get non-null.
		void *Mincar(DoubleFunctionPtr func);
											// Apply "func" to every element
											// on the list and return minimum.

		void *MapcdrRemove ( VoidStarFunctionPtr func, void *arg1, void *arg2 );
		bool IsEmpty();			// is the list empty? 
		bool isEmpty();			// is the list empty? 
        

		// Routines to put/get items on/off list in order (sorted by key)
		void SortedInsert(void *item, double sortKey);	// Put item into list
		void *SortedRemove(double *keyPtr); 	  	// Remove first item from list

		int number();

	private:
		int num;
		MWListElement *first;  	// Head of the list, NULL if list is empty
		MWListElement *last;		// Last element of list
};

#endif // MWLIST_H
