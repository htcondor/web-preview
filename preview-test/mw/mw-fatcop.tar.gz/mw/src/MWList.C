// list.cc 
//
//     	Routines to manage a singly-linked list of "things".
//
// 	A "MWListElement" is allocated for each item to be put on the
//	list; it is de-allocated when the item is removed. This means
//      we don't need to keep a "next" pointer in every object we
//      want to put on a list.
// 
//     	NOTE: Mutual exclusion must be provided by the caller.
//  	If you want a synchronized list, you must use the routines 
//	in synchlist.cc.
//
// This file is taken from the distribution of 'Nachos' from Berkeley.

#include "MWList.h"
#include <stdio.h>

//----------------------------------------------------------------------
// MWListElement::MWListElement
// 	Initialize a list element, so it can be added somewhere on a list.
//
//	"itemPtr" is the item to be put on the list.  It can be a pointer
//		to anything.
//	"sortKey" is the priority of the item, if any.
//----------------------------------------------------------------------

MWListElement::MWListElement(void *itemPtr, double sortKey)
{
	item = itemPtr;
	key = sortKey;
	next = NULL;	// assume we'll put it at the end of the list 
}

//----------------------------------------------------------------------
// MWList::MWList
//	Initialize a list, empty to start with.
//	Elements can now be added to the list.
//----------------------------------------------------------------------

MWList::MWList()
{ 
	first = last = NULL; 
	num = 0;
}

//----------------------------------------------------------------------
// MWList::~MWList
//	Prepare a list for deallocation.  If the list still contains any 
//	MWListElements, de-allocate them.  However, note that we do *not*
//	de-allocate the "items" on the list -- this module allocates
//	and de-allocates the MWListElements to keep track of each item,
//	but a given item may be on multiple lists, so we can't
//	de-allocate them here.
//----------------------------------------------------------------------

MWList::~MWList()
{ 
	while (Remove() != NULL);	 // delete all the list elements
}

//----------------------------------------------------------------------
// MWList::Append
//      Append an "item" to the end of the list.
//      
//	Allocate a MWListElement to keep track of the item.
//      If the list is empty, then this will be the only element.
//	Otherwise, put it at the end.
//
//	"item" is the thing to put on the list, it can be a pointer to 
//		anything.
//----------------------------------------------------------------------

void
MWList::Append(void *item)
{
	if (item == NULL)
		MWprintf(30, "MWDEBUG: appending a null pointer\n");
	
	MWListElement *element = new MWListElement(item, 0);

	if (IsEmpty()) 
	{	// list is empty
		first = element;
		last = element;
	} 
	else 
	{	// else put it after last
		last->next = element;
		last = element;
	}
	num++;
}

//----------------------------------------------------------------------
// MWList::Prepend
//      Put an "item" on the front of the list.
//      
//	Allocate a MWListElement to keep track of the item.
//      If the list is empty, then this will be the only element.
//	Otherwise, put it at the beginning.
//
//	"item" is the thing to put on the list, it can be a pointer to 
//		anything.
//----------------------------------------------------------------------

void
MWList::Prepend(void *item)
{
	MWListElement *element = new MWListElement(item, 0);

	if (IsEmpty()) 
	{	// list is empty
		first = element;
		last = element;
	} 
	else 
	{	// else put it before first
		element->next = first;
		first = element;
	}
	num++;
}

//----------------------------------------------------------------------
// MWList::Remove
//      Remove the first "item" from the front of the list.
// 
// Returns:
//	Pointer to removed item, NULL if nothing on the list.
//----------------------------------------------------------------------

void *
MWList::Remove()
{
	return SortedRemove(NULL);  // Same as SortedRemove, but ignore the key
}

void
MWList::Remove ( void *thing )
{
	MWListElement *temp;
	if ( first == NULL )
		return;
	if ( first == last )
	{
		// XXX Is this what we want? Maybe not
		// if ( first->item = thing )
		if ( first->item == thing )
		{
			delete first;
			first = last = NULL;
			num--;
		}
		return;
	}
	if ( first->item == thing )
	{
		temp = first;
		first = first->next;
		num--;
		delete temp;
		return;
	}
	MWListElement *ptr, *prev = first;
	for (ptr = first->next; ptr != NULL; ptr = ptr->next) 
	{
		if ( ptr->item == thing )
		{
			prev->next = ptr->next;
			num--;
			if ( last == ptr )
				last = prev;
			delete ptr;
			return;
		}
		prev = ptr;
    }
}

//----------------------------------------------------------------------
// MWList::Mapcar
//	Apply a function to each item on the list, by walking through  
//	the list, one element at a time.
//
//	Unlike LISP, this mapcar does not return anything!
//
//	"func" is the procedure to apply to each element of the list.
//----------------------------------------------------------------------
void
MWList::Mapcar(VoidFunctionPtr func, void *arg)
{
	for (MWListElement *ptr = first; ptr != NULL; ptr = ptr->next) 
	{
		(*func)(ptr->item, arg);
    }
}

//----------------------------------------------------------------------
// MWList::Mapcdr
//	Apply a function to each item on the list, by walking through  
//	the list, one element at a time till you get a non zero result.
//
//	"func" is the procedure to apply to each element of the list.
//----------------------------------------------------------------------
int
MWList::Mapcdr(IntFunctionPtr func, void *arg1, void *arg3 )
{
	for (MWListElement *ptr = first; ptr != NULL; ptr = ptr->next) 
	{
		if ( (*func)(arg1, ptr->item, arg3) != 0 )
			return 1;
	}
	return 0;
}

//----------------------------------------------------------------------
// MWList::MapItercdr
//	Apply a function to each item on the list, by walking through  
//	the list, one element at a time till you get a non-null result
//
//	"func" is the procedure to apply to each element of the list.
//----------------------------------------------------------------------
void*
MWList::MapItercdr(VoidStarFunctionPtr func, void *arg1, void *arg3 )
{
	void *thing = NULL;
	for (MWListElement *ptr = first; ptr != NULL; ptr = ptr->next) 
	{
		if ( ( thing = (*func)(arg1, ptr->item, arg3) ) != NULL )
			return thing;
    }
	return NULL;
}

//----------------------------------------------------------------------
// MWList::Mincar
//	Apply a function to each item on the list, by walking through  
//	the list, one element at a time and return the minimum.
//
//	"func" is the procedure to apply to each element of the list.
//----------------------------------------------------------------------
void*
MWList::Mincar(DoubleFunctionPtr func)
{
	void *thing = NULL;
	double min, temp;

	if ( first == NULL )
		return NULL;
	min = (*func)(first);
	thing = first;

	for (MWListElement *ptr = first->next; ptr != NULL; ptr = ptr->next) 
	{
		temp = (*func)(ptr);
		if ( temp < min )
		{
			thing = ptr;
			min = temp;
		}
    }
	return thing;
}

void*
MWList::MapcdrRemove ( VoidStarFunctionPtr func, void *arg1, void *arg3 )
{
	MWListElement *ptr, *prev;
	void *thing = NULL;
	if ( isEmpty () )
		return NULL;
	if ( first == last )
	{
		thing = (*func) ( arg1, first->item, arg3 );
		if ( thing != NULL )
		{
			delete first;
			first = last = NULL;
			num--;
		}
		return thing;
	}
	prev = NULL;
	ptr = first;
	while ( ptr )
	{
		thing = (*func) ( arg1, ptr->item, arg3 );
		if ( thing != NULL )
		{
			if ( prev )
				prev->next = ptr->next;
			if ( first == ptr )
				first = ptr->next;
			if ( last == ptr )
				last = prev;
			delete ptr;
			num--;
			return thing;
		}
		prev = ptr;
		ptr = ptr->next;
	}

	return NULL;
}

//----------------------------------------------------------------------
// MWList::IsEmpty
//      Returns TRUE if the list is empty (has no items).
//----------------------------------------------------------------------

bool
MWList::IsEmpty() 
{ 
	if (first == NULL)
		return TRUE;
	else
		return FALSE; 
}

bool
MWList::isEmpty ( )
{
	if (first == NULL)
		return TRUE;
	else
		return FALSE; 
}

int
MWList::number()
{
	return num;
}

//----------------------------------------------------------------------
// MWList::SortedInsert
//      Insert an "item" into a list, so that the list elements are
//	sorted in increasing order by "sortKey".
//      
//	Allocate a MWListElement to keep track of the item.
//      If the list is empty, then this will be the only element.
//	Otherwise, walk through the list, one element at a time,
//	to find where the new item should be placed.
//
//	"item" is the thing to put on the list, it can be a pointer to 
//		anything.
//	"sortKey" is the priority of the item.
//----------------------------------------------------------------------

void
MWList::SortedInsert(void *item, double sortKey)
{
	MWListElement *element = new MWListElement(item, sortKey);
	MWListElement *ptr;		// keep track

	num++;
	if (IsEmpty()) 
	{	// if list is empty, put
		first = element;
		last = element;
	} 
	else if (sortKey < first->key)
	{	
		// item goes on front of list
		element->next = first;
		first = element;
	} 
	else 
	{	// look for first elt in list bigger than item
		for (ptr = first; ptr->next != NULL; ptr = ptr->next) 
		{
			if (sortKey < ptr->next->key) 
			{
				element->next = ptr->next;
				ptr->next = element;
				return;
			}
		}
		last->next = element;		// item goes at end of list
		last = element;
	}
}

//----------------------------------------------------------------------
// MWList::SortedRemove
//      Remove the first "item" from the front of a sorted list.
// 
// Returns:
//	Pointer to removed item, NULL if nothing on the list.
//	Sets *keyPtr to the priority value of the removed item
//	(this is needed by interrupt.cc, for instance).
//
//	"keyPtr" is a pointer to the location in which to store the 
//		priority of the removed item.
//----------------------------------------------------------------------

void *
MWList::SortedRemove(double *keyPtr)
{
	MWListElement *element = first;
	void *thing;

	if (IsEmpty()) 
		return NULL;

	thing = first->item;
	if (first == last) 
	{	// list had one item, now has none 
		first = NULL;
		last = NULL;
	} 
	else 
	{
		first = element->next;
	}
	if (keyPtr != NULL)
		*keyPtr = element->key;
	delete element;
	num--;
	return thing;
}
