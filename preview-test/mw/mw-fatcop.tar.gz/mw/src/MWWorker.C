#include "MW.h"
#include "MWWorker.h"
#include "RMComm/MWRMComm.h"
#include <unistd.h>

#ifdef NWSENABLED
typedef int (*callBackFcnDefn)(void* arg, int status);
extern void setRestartFunction ( callBackFcnDefn cbRestart, void *cbRestartArg, callBackFcnDefn cbCkpt, void *cbCkptArg );

int ckptRestart ( void* arg, int status );
void *specialPtr = NULL;
extern "C" int nws_sensor_main ( int argc, char *argv[] );

extern "C"
{
void FirstUserFunction ( )
{
	setRestartFunction ( ckptRestart, NULL, NULL, NULL );
}
}

#else

extern void NWSControlTask ( MWTask *task );
extern MWTask*	NWSNewTask ( );

#endif


MWWorker::MWWorker() 
{
	master = UNDEFINED;

#ifdef NWSENABLED
	started_nws_sensor = 0;
#endif

#ifdef INDEPENDENT
// 	RMC = GlobalRMComm;
#endif
}

MWWorker::~MWWorker() 
{
}

void MWWorker::go( int argc, char *argv[] ) 
{
	int myid;   //actually never used...
#ifdef INDEPENDENT
//	RMC = GlobalRMComm;
#else
	MWReturn ustat = OK;
#endif

	MWprintf ( 10, "About to call setup\n");
	RMC->setup( argc, argv, &myid, &master );
	MWprintf ( 10, "Worker %x started. \n", myid );
	
#ifndef INDEPENDENT
	if ( (ustat = worker_setup()) != OK ) {
/* We don't do this exit ourself: the master will kill us. */
/*		RMC->exit(1); */
	}
	worker_mainloop();
}

MWReturn MWWorker::worker_setup() {
	int len, tag, tid;

#endif

	gethostname ( mach_name, 64 );

	MWprintf ( 10, "Worker started on machine %s.\npid = %d\n", mach_name, getpid() );
	
		/* Pack and send to the master all these information
		   concerning the host and the worker specificities  */
	RMC->initsend();
	RMC->pack( mach_name );
	pack_worker_initinfo();
	
	int status = RMC->send( master, INIT );
	MWprintf ( 10, "Sent the master %x an INIT message.\n", master );
	
	if ( status < 0 ) {
		MWprintf ( 10, "Had a problem sending my name to master.  Exiting.\n");
		RMC->exit(1);
	}

	
#ifdef INDEPENDENT
}

MWReturn MWWorker::worker_setup() 
{
    return OK;
}

MWReturn MWWorker::ind_benchmark ( )
{
	int status;
	int len, tag, tid;
#endif
	// wait for the setup info from the master 
	int buf_id = RMC->recv( master, -1 );   
	if( buf_id < 0 ) {
		MWprintf ( 10, "Had a problem receiving INIT_REPLY.  Exiting.\n" );
		RMC->exit( INIT_REPLY_FAILURE );
	}
	status = RMC->bufinfo ( buf_id, &len, &tag, &tid );
	MWprintf ( 10, "Got Something from the master in reply to INIT %d\n", tag);
	
	MWReturn ustat = OK;
		// unpack initial data to set up the worker state

	switch ( tag )
	{
		case INIT_REPLY:
		{

			if ( RMC->unpack ( master_mach_name ) != 0 )
			{
				int err = -1;
				MWprintf ( 10, "Error unpacking master hostname. \n");
				RMC->initsend ( );
				RMC->pack ( &err, 1 );
				RMC->send ( master, BENCH_RESULTS );
				return ustat;
			}
#ifdef NWSENABLED
			RMC->unpack ( &nws_nameserver_port, 1, 1 );
			RMC->unpack ( &nws_memory_port, 1, 1 );
			RMC->unpack ( &nws_sensor_port, 1, 1 );
			started_nws_sensor = 1;
			start_nws_sensor ( );
			specialPtr = this;
#endif

			if ( (ustat = unpack_init_data()) != OK ) {
				int err = -1;
				MWprintf ( 10, "Error unpacking initial data.\n" );
				RMC->initsend();
				RMC->pack( &err, 1 );
				RMC->send( master, BENCH_RESULTS );
				return ustat;
			}

			int bench_tf = FALSE;
			RMC->unpack( &bench_tf, 1 );

			if ( bench_tf ) {
				MWprintf ( 10, "Recvd INIT_REPLY, now benchmarking.\n" );
				workingTask->unpack_work();
				double bench_result = benchmark( workingTask );
				MWprintf ( 40, "Benchmark completed....%f\n", bench_result );
				int zero = 0;
				RMC->initsend();
				RMC->pack( &zero, 1 );  // zero means that unpack_init_data is OK.
				RMC->pack( &bench_result, 1 );
			} else {
				MWprintf ( 10, "Recvd INIT_REPLY, no benchmark.\n" );
				double z = 0.0;
				int zero = 0;
				RMC->initsend();
				RMC->pack( &zero, 1 );  // zero means that unpack_init_data is OK.
				RMC->pack( &z, 1 );
			}
			MWprintf ( 10, "Worker Sending BENCH_RESULTS\n");
			RMC->send( master, BENCH_RESULTS );

			return ustat;
			break;
		}

		case CHECKSUM_ERROR:
		{
			MWprintf ( 10, "Got a checksum error\n");
			RMC->exit( CHECKSUM_ERROR_EXIT );
		}
	}
	return OK;
}

#ifndef INDEPENDENT
void MWWorker::worker_mainloop() {
	
		/* sit in a very simple little state machine.  
		   Wait for work; get work; do work; return results.  
		   Repeat until asked to kill self. */
	
	int status = 0, len = 0, tag = 0, tid = 0;
	
	for (;;) {
		
#else
MWReturn MWWorker::worker_mainloop_ind () 
{
	int status = 0, len = 0, tag = 0, tid = 0;

#endif
#ifdef MEASURE
		double _recv_start_time = _measure_cur_wall_time();
		double _recv_start_cpu_time = _measure_cur_cpu_time();
#endif // MEASURE
		
		// wait here for any message from master
		int buf_id = RMC->recv ( master, -1 );
		if( buf_id < 0 ) {
		  MWprintf( 10, "Could not receive message from master.  Exiting\n" );
		  RMC->exit( buf_id );
		}

#ifdef MEASURE
		double _task_recv_time = _measure_cur_wall_time() - _recv_start_time;
		double _task_recv_cpu_time = _measure_cur_cpu_time() - _recv_start_cpu_time;
#endif // MEASURE

		status = -2; len = -2; tag = -2; tid = -2;		
		status = RMC->bufinfo ( buf_id, &len, &tag, &tid );

		switch ( tag ) {
			
		case RE_INIT: {   /* This can happen:  the lower level can tell us 
							 that the master has gone down and come back 
							 up, and we hve to re-initialize ourself. */
			worker_setup();
			break;
		}

		case REFRESH:
		{
			unpack_init_data ( );
			break;
		}

		case DO_THIS_WORK: {
			
			int num = UNDEFINED;
			MWTaskType thisTaskType;
			double wall_time = 0.0;
			double cpu_time = 0.0;
			int tstat;
			int mytemp;

			MWTask *curTask = NULL;
			
			tstat = RMC->unpack ( &mytemp, 1, 1);
			if ( tstat != 0 )
			{
				MWprintf ( 10, "Error: The receive buffer not unpacked on %d\n",
					mach_name );
				fflush ( stdout );
				RMC->exit ( UNPACK_FAILURE );
			}
			thisTaskType = (MWTaskType)mytemp;
			switch ( thisTaskType )
			{
				case MWNORMAL:
					curTask = workingTask;
					break;
				case MWNWS:
#ifndef NWSENABLED
					MWprintf(31, "Got a MWNWS task. \n");
					controlTask = getNWSTask ( );
					curTask = controlTask;
#endif
					break;
					
				default:
					MWprintf(30, "MWWorker::worker_mainloop_ind() - other task type\n");
			}

			curTask->taskType = thisTaskType;

			tstat = RMC->unpack( &num, 1, 1 );
			if( tstat != 0 ) {
			  MWprintf( 10, "Error.  The receive buffer not unpacked on %s\n", 
				    mach_name );
			  fflush( stdout );
			  RMC->exit( UNPACK_FAILURE );
			}

			curTask->number = num;

			
			MWprintf( 40, " Worker %s got task number %d\n", mach_name, num );
			fflush( stdout );
			
			unpack_driver_task_data();

			curTask->unpack_work();
			
			/* Set our stopwatch.  :-) */
			wall_time -= _measure_cur_wall_time();
			cpu_time -= _measure_cur_cpu_time();

				/* do it! */
			switch ( thisTaskType )
			{
				case MWNORMAL:
					execute_task( curTask );
					break;
				case MWNWS:
#ifndef NWSENABLED
					curTask->printself ( 10 );
					execute_nws ( curTask );
					curTask->printself ( 10 );
#endif
					break;
				default:
					MWprintf ( 10, "Unidentified %d \n", thisTaskType);
					exit(1);
			}
				/* Record times for it... */
			wall_time += _measure_cur_wall_time();
			cpu_time += _measure_cur_cpu_time();

				/* Now send... */
			RMC->initsend();
			RMC->pack( &num, 1, 1 );
#ifdef MEASURE
			RMC->pack(&_task_recv_time, 1, 1);
			RMC->pack(&_task_recv_cpu_time, 1, 1);
#endif // END MEASURE
			RMC->pack( &wall_time, 1, 1 );
			RMC->pack( &cpu_time, 1, 1 );
			curTask->pack_results();
			status = RMC->send(master, RESULTS);

			if ( status < 0 ){
			  MWprintf ( 10, "Bummer!  Could not send results of task %d\n", num ); 
			  MWprintf( 10, "Exiting worker!" ); 
			  RMC->exit( FAIL_MASTER_SEND );
			}
                        
		
			MWprintf ( 40, "%s sent results of job %d.\n", 
					   mach_name, curTask->number );

			switch ( thisTaskType )
			{
				case MWNORMAL:
					break;
				case MWNWS:
#ifndef NWSENABLED
					delete curTask;
					controlTask = NULL;
#endif
					break;

				default:
					MWprintf(30, "MWWorker::worker_mainloop_ind() - other task type\n");
			}
			break;
			
		}
		case KILL_YOURSELF: {
			suicide();
		}
		case CHECKSUM_ERROR:
		{
			MWprintf ( 10, "Got a checksum error\n");
			RMC->exit( CHECKSUM_ERROR_EXIT );
		}
		default: {
			MWprintf ( 10, "Received strange command %d.\n", tag );
			RMC->exit( UNKNOWN_COMMAND );
		}
		} // switch
#ifndef INDEPENDENT
	}
#else
	return OK;
#endif

}

/* We've received orders to kill ourself; we're not needed anymore.
   Fall on own sword. */

void MWWorker::suicide () 
{   
	MWprintf ( 10, "\"Goodbye, cruel world...\" says %s\n", mach_name );
	
	RMC->exit(0);
}


#ifndef NWSENABLED
void
MWWorker::execute_nws ( MWTask *task )
{
	NWSControlTask ( task );
}

MWTask*
MWWorker::getNWSTask ( )
{
	return NWSNewTask ( );
}
#endif

#ifdef NWSENABLED
int MWWorker::start_nws_sensor ( )
{
	int bakwas = 1;
	int i = 1;

	if ( started_nws_sensor == 0 )
		return 0;

	i = fork();
	if ( i < 0 )
	{
		MWprintf ( 10, "Could not start nws sensor\n");
		return -1;
	}
	if ( i > 0 )
		return i;
	int argc = 0;
	char *argv[9];
	char temp[_POSIX_PATH_MAX];
	argv[argc] = (char *)malloc ( sizeof(char) * _POSIX_PATH_MAX );
	strcpy ( argv[argc++], "nws_sensor" );
	argv[argc] = (char *)malloc ( sizeof(char) * _POSIX_PATH_MAX );
	strcpy ( argv[argc++], "-c" );
	argv[argc] = (char *)malloc ( sizeof(char) * _POSIX_PATH_MAX );
	strcpy ( argv[argc++], "no" );
	argv[argc] = (char *)malloc ( sizeof(char) * _POSIX_PATH_MAX );
	strcpy ( argv[argc++], "-M" );
	argv[argc] = (char *)malloc ( sizeof(char) * _POSIX_PATH_MAX );
	sprintf ( temp, "%s:%d", master_mach_name, nws_memory_port );
	strcpy ( argv[argc++], temp );
	argv[argc] = (char *)malloc ( sizeof(char) * _POSIX_PATH_MAX );
	strcpy ( argv[argc++], "-N" );
	argv[argc] = (char *)malloc ( sizeof(char) * _POSIX_PATH_MAX );
	sprintf ( temp, "%s:%d", master_mach_name, nws_nameserver_port );
	strcpy ( argv[argc++], temp );
	argv[argc] = (char *)malloc ( sizeof(char) * _POSIX_PATH_MAX );
	strcpy ( argv[argc++], "-p" );
	argv[argc] = (char *)malloc ( sizeof(char) * _POSIX_PATH_MAX );
	sprintf ( temp, "%d", nws_sensor_port );
	strcpy ( argv[argc++], temp );
	nws_sensor_main ( argc, argv );
	::exit(1);
	return 0;
}

int ckptRestart ( void* /*arg*/, int status )
{
	if ( status != 0 )
		return -1;
	if ( specialPtr )
	{
		((MWWorker *)specialPtr)->start_nws_sensor ( );
	}
	return 0;
}
#endif
