/* MWTask.C

   The implementation of the MWTask class

*/

#include "MWTask.h"
#include "MWDriver.h"
#include <stdio.h>

extern int MWworkClasses;
extern int *MWworkClassTasks;

MWTask::MWTask() {
	number = -1;
	worker = NULL;
	taskType = MWNORMAL;
	group = new MWGroup ( MWworkClasses );
}

MWTask::~MWTask() {
  if ( worker )
    if ( worker->runningtask )
      worker->runningtask = NULL;

  delete group;
}

void MWTask::printself( int level ) 
{    
	MWprintf ( level, "  Task %d\n", number);
}

void
MWTask::initGroups ( int num )
{
	group = new MWGroup ( num );
}

void
MWTask::addGroup ( int num )
{
	MWworkClassTasks[num]++;
	return group->join ( num );
}

void
MWTask::deleteGroup ( int num )
{
	MWworkClassTasks[num]--;
	return group->leave ( num );
}

bool
MWTask::doesBelong ( int num )
{
	return group->belong ( num );
}

MWGroup*
MWTask::getGroup ( )
{
	return group;
}

void
MWTask::write_group_info ( FILE *fp )
{
	group->write_checkpoint ( fp );
}

void
MWTask::read_group_info ( FILE *fp )
{
	group = new MWGroup ( MWworkClasses );
	group->read_checkpoint ( fp );
	for ( int i = 0; i < MWworkClasses; i++ )
	{
		if ( doesBelong ( i ) )
			addGroup ( i );
	}
}
